// settings/config.js
// ═══════════════════════════════════════════════════════
//  CONFIG CENTRAL DO MIKU-BOT
//  Tudo que se repete entre vários comandos fica aqui.
//  Edite os valores abaixo e reinicie o bot.
// ═══════════════════════════════════════════════════════

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'config.json');

const DEFAULTS = {
    // ── Identidade do bot ──────────────────────────────
    botName: 'Miku-Bot',
    creatorName: 'ʏǟʍɨӄʊ',

    // ── Dono do bot (só números, sem @s.whatsapp.net) ──
    ownerNumber: '559884736600',
    // LID do dono (Baileys às vezes identifica por LID em vez do número).
    // Pra descobrir a sua: mande qualquer comando no PV do bot e use o
    // comando "debug" — ele mostra o JID/LID de quem mandou.
    ownerLid: '113194584551514@lid',

    // ── Número que o BOT vai usar pra conectar (pairing code) ──
    // Só dígitos, com DDI (ex: '5511999998888'). Se deixar vazio,
    // o bot pergunta o número no console na hora de conectar.
    pairingNumber: '5599999999',

    // ── Prefixo global dos comandos ────────────────────
    prefix: '!',

    // ── Visual do menu ──────────────────────────────────
    imgBanner: 'https://files.catbox.moe/5n7iau.jpg',
    canalLink: 'https://whatsapp.com/channel/0029VbAcIFyGpLHXbAXncN1u',

    // ── Canal usado para "encaminhar via canal" nas mídias ──
    channelJid: '120363420045810596@newsletter',
    channelName: 'Miku-Bot 🤖',

    // ── API keys usadas pelos comandos de download ─────
    // Troque pelas SUAS chaves reais dos provedores.
    apis: {
        zoneApi: 'SUA_APIKEY_AQUI',   // zone.api.br — usada na maioria dos comandos de download
        okarun: 'SUA_APIKEY_AQUI'     // okarun-api.com.br — usada no comando spk (spotify alternativo)
    }
};

function ownerJid() {
    return `${config.ownerNumber}@s.whatsapp.net`;
}

function loadConfig() {
    try {
        if (fs.existsSync(CONFIG_PATH)) {
            const salvo = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
            return { ...DEFAULTS, ...salvo, apis: { ...DEFAULTS.apis, ...(salvo.apis || {}) } };
        }
    } catch (e) {
        console.error('[CONFIG] Erro ao ler config.json, usando padrões:', e.message);
    }
    return { ...DEFAULTS };
}

const config = loadConfig();

function saveConfig() {
    try {
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 4), 'utf-8');
    } catch (e) {
        console.error('[CONFIG] Erro ao salvar config.json:', e.message);
    }
}

module.exports = { config, saveConfig, ownerJid };
