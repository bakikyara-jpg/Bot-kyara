# Miku-Bot

Bot de WhatsApp com handler baseado em pastas — cada comando é um arquivo separado
dentro de `src/commands/<categoria>/`. Todo o bot (menu, avisos, comandos, erros)
usa o mesmo estilo visual de card:

```
╔━᳀『 Tɪ́ᴛᴜʟᴏ 』═᳀
⌬ linha 1
⌬ linha 2
╚═━═━═━═━═━═━═━═━═᳀
```

## Antes de rodar

Edite `settings/config.js` (ou, depois do primeiro boot, `settings/config.json`
que é gerado automaticamente) com:

- `botName`, `creatorName` — nome do bot e créditos
- `ownerNumber` — seu número, só dígitos, sem `@s.whatsapp.net`
- `ownerLid` — seu LID (opcional, mas recomendado — Baileys às vezes identifica o
  dono pelo LID em vez do número; descubra o seu mandando um comando no PV do bot
  e rodando `.debug`)
- `pairingNumber` — número que o BOT vai usar pra conectar (se vazio, usa o
  `ownerNumber` ou pergunta no terminal na hora de rodar)
- `prefix` — prefixo dos comandos
- `imgBanner` — imagem do menu (pode ser trocada em tempo real com `.fotomenu`)
- `canalLink` — link do canal do bot
- `channelJid` / `channelName` — canal usado no "encaminhado via canal" das mídias
- `apis.zoneApi` / `apis.okarun` — chaves das APIs usadas nos comandos de download.
  Vem como `SUA_APIKEY_AQUI` — troque pelas suas antes de rodar.

## Estrutura

```
index.js                          → conexão + dispatcher de comandos
settings/config.js                → config central
src/utils.js                      → isOwner, isUserAdmin, extractNumber
src/handler.js                    → varre src/commands/*/*.js e monta o mapa de comandos
src/console-ui.js                 → log colorido no terminal (mesmo estilo do bot)
src/lib/style.js                  → gerador oficial do card/box usado em TODO o bot
src/lib/so-adm-state/             → grupos com restrição "só admin"
src/lib/so-membro-state/          → grupos com restrição "só membro"
src/lib/so-dono-state/            → grupos com restrição "só dono"
src/lib/mute-state/               → membros mutados por grupo
src/lib/blockcmd-state/           → comandos bloqueados por grupo
src/commands/
  menu/         menu.js            → menu automático (lê as subpastas e monta as abas)
  geral/        ping.js            → utilidades gerais, liberado pra qualquer um
  moderacao/    ban, gp-a, gp-f, so-adm, so-membro, so-dono, mute, desmutar, blockcmd, unblockcmd
  dono/         setprefix, restart, fotomenu → só o dono do bot pode usar
  ia/           miku.js            → chat com IA, funciona COM ou SEM prefixo
  download/     spotify, play, tiktok, instagram, pinterest, etc.
  zoeira/       comandos de zoeira/randomizer
  debug/        debug, bly
```

## Comandos novos nesta versão

- **`ping`** — mostra latência e uptime do bot (categoria `geral`).
- **`restart`** — reinicia o processo do bot (só dono).
- **`fotomenu`** — troca a imagem do banner do menu por link ou por imagem
  respondida (só dono).
- **`mute` / `desmutar`** — muta um membro no grupo; mensagens dele são
  apagadas automaticamente enquanto estiver mutado (admin/dono).
- **`blockcmd` / `unblockcmd`** — bloqueia um comando específico dentro de um
  grupo (admin/dono).
- **`miku`** — chat com IA. Funciona **com ou sem prefixo**
  (`miku oi` ou `!miku oi`), com memória por usuário ou por grupo
  (`miku grupos` liga/desliga a memória compartilhada do grupo).

## Comandos sem prefixo

Qualquer comando pode funcionar sem o prefixo do bot: basta adicionar
`semPrefixo: true` no `module.exports` do arquivo. O `index.js` detecta a
primeira palavra da mensagem e, se bater com um comando marcado assim, executa
mesmo sem o prefixo configurado.

## Adicionar um comando novo

1. Crie o arquivo em `src/commands/<categoria>/nome.js` (crie a pasta se a
   categoria for nova — ela já aparece automaticamente no `.menu`).
2. Exporte usando o estilo visual oficial do bot:

```js
const path = require('path');
const { box, sucesso, erro, aviso, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'nome',
    aliases: ['apelido1', 'apelido2'], // opcional
    semPrefixo: false,                 // true se quiser que funcione sem o prefixo
    async execute(sock, m, options) {
        const { from, sender, args, config } = options;
        await sock.sendMessage(from, {
            text: sucesso('Título do Card', ['linha 1', 'linha 2'])
        }, { quoted: m });
    }
};
```

3. Reinicie o bot — ele é carregado automaticamente e já aparece no `.menu`.

## Observação

Os comandos `gay.js` e `femboy.js` que vieram no pacote original de zoeira não
foram incluídos — eram "medidores" que atribuíam orientação sexual como piada
sobre uma pessoa mencionada no grupo, o que pode virar bullying real. O resto
do pacote de zoeira (zoeiras genéricas, política, etc.) foi mantido.
