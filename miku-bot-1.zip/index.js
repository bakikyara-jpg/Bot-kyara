// index.js — Miku-Bot
// Bot de WhatsApp com handler baseado em pastas (src/commands/<categoria>/*.js)

let makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    isJidBroadcast,
    isJidGroup,
    prepareWAMessageMedia;

const { Boom } = require('@hapi/boom');
const fs = require('fs');
const pino = require('pino');
const readline = require('readline');

const { config } = require('./settings/config.js');
const { isOwner, isUserAdmin } = require('./src/utils.js');
const { carregarComandos } = require('./src/handler.js');
const ui = require('./src/console-ui.js');

const { isSoAdmAtivo } = require('./src/lib/so-adm-state/so-adm-state.js');
const { isSoMembroAtivo } = require('./src/lib/so-membro-state/so-membro-state.js');
const { isSoDonoAtivo } = require('./src/lib/so-dono-state/so-dono-state.js');
const { isMutado } = require('./src/lib/mute-state/mute-state.js');
const { isBloqueado } = require('./src/lib/blockcmd-state/blockcmd-state.js');

// ── Sistema híbrido: comandos "case" (além dos plugins em src/commands) ──
const { handleCase, CASE_COMMANDS } = require('./src/case/index.js');

// ── Bem-vindo e anti-link ──
const { isWelcomeAtivo } = require('./src/lib/welcome-state/welcome-state.js');
const { isWelcome2Ativo } = require('./src/lib/welcome2-state/welcome2-state.js');
const { isAntilinkAtivo, registrarAviso, limparAvisos } = require('./src/lib/antilink-state/antilink-state.js');
const { enviarBemVindo } = require('./src/lib/welcome.js');
const { aviso, erro: erroBox } = require('./src/lib/style.js');

const LINK_REGEX = /(chat\.whatsapp\.com\/[a-zA-Z0-9]+)|(https?:\/\/[^\s]+)/i;

const SESSION_DIR = './auth_info';
const OWNER_JID = `${config.ownerNumber}@s.whatsapp.net`;

let { comandosMap, total, comErro } = carregarComandos();

// ── Conta quantos comandos existem por categoria (pro log bonito) ──
function contarPorCategoria(map) {
    const vistos = new Set();
    const categorias = {};
    for (const cmd of map.values()) {
        if (vistos.has(cmd)) continue;
        vistos.add(cmd);
        const cat = cmd._categoria || 'geral';
        categorias[cat] = (categorias[cat] || 0) + 1;
    }
    return categorias;
}

ui.bannerInicio(config);
ui.box('📦 Comandos Carregados', [
    `Total: ${total} comandos`,
    `Dono: ${config.ownerNumber}`,
    `Prefixo: [ ${config.prefix} ]`,
]);
ui.tabelaCategorias(contarPorCategoria(comandosMap));
ui.erroCarregamento(comErro);

function askPhone() {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => {
        rl.question('📱 Digite o número do bot (com DDI, só números): ', num => {
            rl.close();
            resolve(num.replace(/\D/g, ''));
        });
    });
}

let pairingRequested = false;

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: ['Ubuntu', 'Chrome', '120.0.5481.177'],
        syncFullHistory: false,
        markOnlineOnConnect: true,
    });

    // Shim de compatibilidade usado pelo menu.js (prepareWAMessageMedia da própria lib)
    sock.hzxx = {
        utils: {
            prepareWAMessageMedia,
        },
    };

    sock.ev.on('creds.update', saveCreds);

    if (!state.creds.registered && !pairingRequested) {
        pairingRequested = true;
        const phone = config.pairingNumber || config.ownerNumber || (await askPhone());
        await new Promise(r => setTimeout(r, 1500));
        try {
            const code = await sock.requestPairingCode(phone);
            const formatted = code.match(/.{1,4}/g)?.join('-') || code;
            ui.box('🔑 Código de Pareamento', [
                `Código: ${formatted}`,
                `WhatsApp > Aparelhos conectados > Conectar com número`,
            ]);
        } catch (e) {
            console.error('[MIKU] Erro ao gerar código:', e.message);
        }
    }

    // ─── ENTRADA DE MEMBROS (bem-vindo) ───────────────────────
    sock.ev.on('group-participants.update', async (evt) => {
        try {
            if (evt.action !== 'add') return;
            for (const participantJid of evt.participants || []) {
                enviarBemVindo(sock, evt.id, participantJid).catch(e => console.error('[WELCOME]', e.message));
            }
        } catch (e) {
            console.error('[GROUP-PARTICIPANTS] Erro:', e.message);
        }
    });

    sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
        if (connection === 'open') {
            ui.box(`✅ ${config.botName} Online`, [
                `Comandos: ${comandosMap.size} entradas mapeadas`,
                `Número: ${sock.user?.id?.split(':')[0] || '?'}`,
                `Status: Conectado`,
            ], 'green');
        }
        if (connection === 'close') {
            const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                ui.statusConexao('erro', 'Sessão deslogada. Apague auth_info/ e rode de novo.');
            } else {
                ui.statusConexao('reconectando', 'Reconectando em 5s...');
                pairingRequested = false;
                setTimeout(startBot, 5000);
            }
        }
    });

    // ─── MENSAGENS ─────────────────────────────────────────────
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const m of messages) {
            try {
                if (m.key.fromMe) continue;

                const from = m.key.remoteJid;
                if (!from || isJidBroadcast(from)) continue;

                const isGroup = isJidGroup(from);
                const sender = isGroup ? (m.key.participant || m.participant) : from;
                if (!sender) continue;

                const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);

                // ── Usuário mutado no grupo → apaga a mensagem e ignora ──
                if (isGroup && !senderIsDono && isMutado(from, sender)) {
                    try { await sock.sendMessage(from, { delete: m.key }); } catch (_) {}
                    continue;
                }

                const textoMensagem =
                    m.message?.conversation ||
                    m.message?.extendedTextMessage?.text ||
                    m.message?.imageMessage?.caption ||
                    m.message?.videoMessage?.caption ||
                    '';

                const prefixoAtual = config.prefix;
                const textoTrim = textoMensagem.trim();
                if (!textoTrim) continue;

                // ── Anti-link: apaga mensagem com link e avisa/remove o membro ──
                if (isGroup && !senderIsDono && LINK_REGEX.test(textoTrim) && isAntilinkAtivo(from)) {
                    try {
                        const groupMetadata = await sock.groupMetadata(from);
                        const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);
                        if (!senderIsAdmin) {
                            await sock.sendMessage(from, { delete: m.key }).catch(() => {});
                            const totalAvisos = registrarAviso(from, sender);
                            if (totalAvisos >= 3) {
                                limparAvisos(from, sender);
                                await sock.groupParticipantsUpdate(from, [sender], 'remove').catch(() => {});
                                await sock.sendMessage(from, {
                                    text: erroBox('Anti-Link', [`@${sender.split('@')[0]} foi removido por enviar links repetidamente.`]),
                                    mentions: [sender],
                                });
                            } else {
                                await sock.sendMessage(from, {
                                    text: aviso('Anti-Link', [`@${sender.split('@')[0]}, links não são permitidos aqui! Aviso ${totalAvisos}/3.`]),
                                    mentions: [sender],
                                });
                            }
                            continue;
                        }
                    } catch (e) {
                        console.error('[ANTILINK] Erro:', e.message);
                    }
                }

                let nomeComando, args;

                if (textoTrim.startsWith(prefixoAtual)) {
                    const semPrefixo = textoTrim.slice(prefixoAtual.length).trim();
                    const partes = semPrefixo.split(/\s+/);
                    nomeComando = (partes.shift() || '').toLowerCase();
                    args = partes;
                } else {
                    // ── Comandos que funcionam SEM prefixo (ex: "miku") ──
                    const partes = textoTrim.split(/\s+/);
                    const possivelNome = (partes[0] || '').toLowerCase();
                    const possivelComando = comandosMap.get(possivelNome);
                    if (possivelComando && possivelComando.semPrefixo) {
                        nomeComando = possivelNome;
                        args = partes.slice(1);
                    } else {
                        continue;
                    }
                }

                if (!nomeComando) continue;

                // ── Sistema híbrido: primeiro procura como plugin, depois como "case" ──
                const comando = comandosMap.get(nomeComando);
                const ehCase = !comando && CASE_COMMANDS.has(nomeComando);
                if (!comando && !ehCase) continue;

                const nomeReal = comando ? comando.name : nomeComando;

                // ── Comando bloqueado nesse grupo específico ──
                if (isGroup && !senderIsDono && isBloqueado(from, nomeReal)) continue;

                // ── Restrições de grupo (so-adm / so-membro / so-dono) ──
                if (isGroup && !senderIsDono) {
                    if (isSoDonoAtivo(from)) continue; // só o dono pode usar

                    if (isSoAdmAtivo(from)) {
                        const groupMetadata = await sock.groupMetadata(from);
                        const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);
                        if (!senderIsAdmin) continue;
                    }

                    if (isSoMembroAtivo(from)) {
                        const groupMetadata = await sock.groupMetadata(from);
                        const ehParticipante = groupMetadata.participants.some(p => p.id === sender);
                        if (!ehParticipante) continue;
                    }
                }

                const senderName = m.pushName || sender.split('@')[0];

                const options = {
                    from,
                    sender,
                    args,
                    text: args.join(' ').trim(),
                    prefix: prefixoAtual,
                    prefixoAtual,
                    senderName,
                    config,
                    isGroup,
                };

                if (ehCase) {
                    ui.logComando({ nome: nomeReal, sender, from, categoria: 'case' });
                    await handleCase(sock, m, options, nomeReal);
                } else {
                    ui.logComando({ nome: comando.name, sender, from, categoria: comando._categoria });
                    await comando.execute(sock, m, options);
                }

            } catch (err) {
                console.error('[MIKU] Erro ao processar mensagem:', err.message);
            }
        }
    });
}

(async () => {
    ({
        default: makeWASocket,
        useMultiFileAuthState,
        DisconnectReason,
        fetchLatestBaileysVersion,
        isJidBroadcast,
        isJidGroup,
        prepareWAMessageMedia,
    } = await import('@systemzero/baileys'));

    startBot();
})();
