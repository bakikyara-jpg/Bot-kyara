// src/commands/figurinhas/rbs.js
// Rouba a figurinha marcada e reenvia com o pack/autor no estilo do bot.
// Uso: .rbs                -> usa nome do dono + nome do bot
//      .rbs Pack|Autor     -> define pack e autor customizados
const path = require('path');
const { erro } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'rbs',
    aliases: ['roubar', 'steal', 's2'],
    description: 'Rouba a figurinha marcada e reenvia com pack/autor customizados',
    usage: 'rbs [Pack|Autor] (marcando uma figurinha)',

    async execute(sock, m, options) {
        const { from, args, senderName, config } = options;

        try {
            const quotedRaw = m.message?.extendedTextMessage?.contextInfo?.quotedMessage || {};
            const isSticker = !!quotedRaw?.stickerMessage;
            const isLottie = !!quotedRaw?.lottieStickerMessage;

            if (!isSticker && !isLottie) {
                return sock.sendMessage(from, { text: erro('Marque uma Figurinha', ['Responda a uma figurinha com o comando para roubá-la.']) }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

            const nomebot = config.botName || 'Miku-Bot';
            const texto = (args || []).join(' ').trim();

            let packName, authorName;
            if (texto.includes('|') || texto.includes('/')) {
                const sep = texto.includes('|') ? '|' : '/';
                const [pack, author] = texto.split(sep);
                packName = (pack || '').trim() || `Figurinha de ${senderName}`;
                authorName = (author || '').trim() || nomebot;
            } else if (texto.length > 0) {
                packName = texto;
                authorName = nomebot;
            } else {
                packName = `${senderName} =`;
                authorName = `= ${nomebot}`;
            }
            packName = packName.substring(0, 70);
            authorName = authorName.substring(0, 30);

            const stickerMsg = isLottie
                ? quotedRaw.lottieStickerMessage.message.stickerMessage
                : quotedRaw.stickerMessage;

            const { downloadContentFromMessage } = await import('@systemzero/baileys');
            const stream = await downloadContentFromMessage(stickerMsg, 'sticker');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

            await sock.sendMessage(from, {
                sticker: buffer,
                isAvatar: true,
                stickerPackName: packName,
                stickerAuthor: authorName,
            }, { quoted: m });

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (e) {
            console.error('[RBS ERROR]', e?.message || e);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            await sock.sendMessage(from, { text: erro('Erro ao Roubar Figurinha', [e?.message || 'Tente novamente.']) }, { quoted: m });
        }
    }
};
