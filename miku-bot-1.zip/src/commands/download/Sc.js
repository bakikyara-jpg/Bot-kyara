// src/commands/membros/soundcloud.js
const axios = require('axios');
const { config } = require('../../../settings/config.js');

const API_BASE = 'https://zone.api.br';
const API_KEY = config.apis.zoneApi;
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

if (!global.scCache) global.scCache = {};

function isPV(jid) { return !jid.endsWith('@g.us'); }

async function fetchImage(url) {
    if (!url) return null;
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        return Buffer.from(res.data);
    } catch { return null; }
}

module.exports = {
    name: 'soundcloud',
    aliases: ['sc', 'scdl'],
    description: 'Busca e baixa músicas do SoundCloud',

    async execute(sock, m, options) {
        const { from, args, sender } = options;

        if (!args?.length) {
            return sock.sendMessage(from, {
                text: `╔━᳀『 SoundCloud DL 』═᳀\n` +
                      `⌬ Use: *.sc nome da música*\n` +
                      `⌬ Ex: *.sc Slash Inferno*\n` +
                      `⌬ Link: *.sc https://soundcloud.com/...*\n` +
                      `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        const input = args.join(' ');
        const isLink = /soundcloud\.com\//.test(input);
        const isNum  = /^\d+$/.test(input.trim());

        try {
            // ── Seleção por número ──
            if (isNum) {
                const cache = global.scCache?.[from];

                if (!cache?.results) {
                    return sock.sendMessage(from, {
                        text: '❌ Nenhuma busca ativa!\n_Faça uma busca primeiro com_ *.sc nome*'
                    }, { quoted: m });
                }
                if (cache.owner !== sender) {
                    return sock.sendMessage(from, {
                        text: '❌ Essa lista pertence a outra pessoa!\n_Faça sua própria busca com_ *.sc nome*'
                    }, { quoted: m });
                }

                const idx = parseInt(input.trim()) - 1;
                if (idx < 0 || idx >= cache.results.length) {
                    return sock.sendMessage(from, {
                        text: `❌ Número inválido. Escolha entre *1* e *${cache.results.length}*`
                    }, { quoted: m });
                }

                const track = cache.results[idx];
                await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });
                await baixarEEnviar(sock, from, m, track.sc_url, track, isPV(from));
                return;
            }

            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            // ── Link direto ──
            if (isLink) {
                await baixarEEnviar(sock, from, m, input, null, isPV(from));
                return;
            }

            // ── Busca por nome ──
            const { data } = await axios.get(`${API_BASE}/api/soundcloud/search`, {
                params: { q: input, apikey: API_KEY },
                timeout: 30000
            });

            if (!data?.status || !data?.result?.length) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: '❌ Nenhum resultado encontrado.'
                }, { quoted: m });
            }

            const results = data.result.slice(0, 10);
            global.scCache[from] = { owner: sender, results };

            const coverBuf = await fetchImage(results[0]?.thumbnail);

            const lista = results.map((t, i) =>
                `*[ ${i + 1} ]* ${t.title || '—'}\n` +
                `    ┖ 👤 ${t.author?.name || '—'} • ⏱️ ${t.duration || '—'}`
            ).join('\n');

            const textoLista =
                `╔━᳀『 SoundCloud Search 』═᳀\n` +
                `⌬ *Busca:* ${input}\n` +
                `⌬ *Resultados:* ${results.length}\n` +
                `╠━᳀\n` +
                lista + '\n' +
                `╠━᳀\n` +
                `⌬ _Envie o ID para baixar (Ex: .sc 1)_\n` +
                `╚═━═━═━═━═━═━═━═━═᳀`;

            if (coverBuf && !isPV(from)) {
                await sock.sendMessage(from, {
                    image: coverBuf,
                    caption: textoLista,
                    mimetype: 'image/jpeg',
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: Math.floor(Math.random() * 999999)
                        }
                    }
                }, { quoted: m });
            } else {
                await sock.sendMessage(from, { text: textoLista }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (error) {
            console.error('[SC ERROR]', error.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, { text: `⚠️ Erro: ${error.message}` }, { quoted: m });
        }
    }
};

async function baixarEEnviar(sock, from, m, scUrl, trackInfo, emPV) {
    try {
        const { data } = await axios.get(`${API_BASE}/api/soundcloud`, {
            params: { text: scUrl, apikey: API_KEY },
            timeout: 30000
        });

        if (data?.status !== 'sucesso' || !data?.download_url) {
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(from, { text: '❌ Falha ao baixar a música.' }, { quoted: m });
        }

        const title    = data.title    || trackInfo?.title          || 'soundcloud';
        const artist   = trackInfo?.author?.name                    || '—';
        const duration = data.duration || trackInfo?.duration       || '—';
        const coverBuf = await fetchImage(trackInfo?.thumbnail      || null);

        const textoCard =
            `╔━᳀『 SoundCloud DL 』═᳀\n` +
            `⌬ *Música:* ${title}\n` +
            `⌬ *Autor:* ${artist}\n` +
            `⌬ *Duração:* ${duration}\n` +
            `⌬ *Status:* Enviando áudio...\n` +
            `╚═━═━═━═━═━═━═━═━═᳀`;

        // Card com capa (só grupo)
        if (!emPV) {
            if (coverBuf) {
                await sock.sendMessage(from, {
                    image: coverBuf,
                    caption: textoCard,
                    mimetype: 'image/jpeg',
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: Math.floor(Math.random() * 999999)
                        }
                    }
                }, { quoted: m });
            } else {
                await sock.sendMessage(from, { text: textoCard }, { quoted: m });
            }
        }

        await sock.sendMessage(from, { react: { text: '⬇️', key: m.key } });

        if (emPV) {
            await sock.sendMessage(from, {
                audio: { url: data.download_url },
                mimetype: 'audio/mpeg',
                fileName: `${title}.mp3`,
                ptt: false
            }, { quoted: m });
        } else {
            await sock.sendMessage(from, {
                audio: { url: data.download_url },
                mimetype: 'audio/mpeg',
                fileName: `${title}.mp3`,
                ptt: false,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: CHANNEL_JID,
                        newsletterName: CHANNEL_NAME,
                        serverMessageId: 1
                    }
                }
            }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('[SC DL ERROR]', err.message);
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        sock.sendMessage(from, { text: `⚠️ Erro: ${err.message}` }, { quoted: m });
    }
}