// src/commands/membros/lista.js
const fs = require('fs');
const path = require('path');

const baseDir = path.join(process.cwd(), 'src', 'database');
const cacheInfoPath = path.join(baseDir, 'yuka-cache.json');

function lerCache() {
    try {
        if (!fs.existsSync(cacheInfoPath)) return {};
        return JSON.parse(fs.readFileSync(cacheInfoPath, 'utf-8'));
    } catch (e) {
        console.error('[LISTA ERROR]', e.message);
        return {};
    }
}

function normalize(str) {
    if (!str) return '';
    return str.toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9 ]/g, '');
}

module.exports = {
    name: 'lista',
    aliases: ['list', 'músicas'],
    description: 'Lista músicas salvas no cache',

    async execute(sock, m, options) {
        const { from, args } = options;

        // Lê sempre fresco do disco
        const cache  = lerCache();
        const titulos = [...new Set(
            Object.values(cache)
                .map(v => v.title)
                .filter(Boolean)
        )].sort((a, b) => a.localeCompare(b));

        if (!titulos.length) {
            return sock.sendMessage(from, {
                text: '📭 Nenhuma música salva no cache ainda.'
            }, { quoted: m });
        }

        // ── Com args → filtra ──
        if (args?.length) {
            const busca     = normalize(args.join(' '));
            const filtrados = titulos.filter(t => normalize(t).includes(busca));

            if (!filtrados.length) {
                return sock.sendMessage(from, {
                    text: `🔎 Nenhuma música encontrada para *"${args.join(' ')}"*.`
                }, { quoted: m });
            }

            const linhas = filtrados.map((t, i) => `  ${i + 1}. ${t}`).join('\n');

            return sock.sendMessage(from, {
                text: `╔━᳀『 Resultado da Busca 』═᳀\n` +
                      `⌬ *Busca :* ${args.join(' ')}\n` +
                      `⌬ *Encontradas :* ${filtrados.length}\n` +
                      `╠═━═━═━═━═━═━═━═━═━═᳀\n` +
                      `${linhas}\n` +
                      `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        // ── Sem args → todas ──
        const linhas = titulos.map((t, i) => `  ${i + 1}. ${t}`).join('\n');

        return sock.sendMessage(from, {
            text: `╔━᳀『 Músicas no Cache 』═᳀\n` +
                  `⌬ *Total :* ${titulos.length} música${titulos.length !== 1 ? 's' : ''}\n` +
                  `╠═━═━═━═━═━═━═━═━═━═᳀\n` +
                  `${linhas}\n` +
                  `╚═━═━═━═━═━═━═━═━═᳀`
        }, { quoted: m });
    }
};
