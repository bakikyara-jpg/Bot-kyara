// src/commands/Download/pinterest.js
const axios = require('axios');
const { config } = require('../../../settings/config.js');

const API_BASE     = 'https://zone.api.br';
const API_KEY = config.apis.zoneApi;
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

if (!global.pinCache) global.pinCache = {};

function isPV(jid) { return !jid.endsWith('@g.us'); }

async function fetchImage(url) {
    if (!url) return null;
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                'Referer': 'https://www.pinterest.com/'
            }
        });
        return Buffer.from(res.data);
    } catch { return null; }
}

function getBaileys() {
    const paths = [
        '../../lib/baileys',
        '../../../node_modules/@whiskeysockets/baileys',
        '@adiwajshing/baileys',
        'baileys'
    ];
    for (const p of paths) {
        try { return require(p); } catch {}
    }
    return null;
}

module.exports = {
    name: 'pinterest',
    aliases: ['pin', 'pint'],
    description: 'Busca e baixa imagens do Pinterest',

    async execute(sock, m, options) {
        const { from, args, sender } = options;

        if (!args?.length) {
            return sock.sendMessage(from, {
                text: `╔━᳀『 𝗣𝗶𝗻𝘁𝗲𝗿𝗲𝘀𝘁 𝗗𝗟 』═᳀\n` +
                      `⌬ *Busca:*  .pin carros elétricos\n` +
                      `⌬ *Qtd:*    .pin carros elétricos 20\n` +
                      `⌬ *Baixar:* .pin 3 (após buscar)\n` +
                      `⌬ *Máx:*    50 imagens por busca\n` +
                      `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        const input = args.join(' ').trim();
        const isNum = /^\d+$/.test(input);
        const cache = global.pinCache?.[from];
        const isDownload = isNum && cache?.results?.length && cache?.owner === sender;

        try {
            // ── Download por número ──
            if (isDownload) {
                const idx = parseInt(input) - 1;
                if (idx < 0 || idx >= cache.results.length) {
                    return sock.sendMessage(from, {
                        text: `❌ Número inválido. Escolha entre *1* e *${cache.results.length}*`
                    }, { quoted: m });
                }
                const item = cache.results[idx];
                await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });
                await baixarEEnviar(sock, from, m, item, isPV(from));
                return;
            }

            // ── Busca por termo ──
            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            const argArr = input.split(/\s+/);
            let limit = 9;
            if (/^\d+$/.test(argArr[argArr.length - 1]) && argArr.length > 1) {
                limit = Math.max(1, Math.min(50, parseInt(argArr.pop(), 10)));
            }
            const query = argArr.join(' ');

            const { data } = await axios.get(`${API_BASE}/api/pinterest`, {
                params: { q: query, limit: 50, apikey: API_KEY },
                timeout: 30000
            });

            const results = Array.isArray(data?.results) ? data.results : [];

            if (!results.length) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, { text: '❌ Nenhum resultado encontrado.' }, { quoted: m });
            }

            const sliced = results.slice(0, limit);
            global.pinCache[from] = { owner: sender, results: sliced };

            // ── Tenta carrossel ──
            const baileys = getBaileys();
            const generateWAMessageFromContent = baileys?.generateWAMessageFromContent;
            const prepareWAMessageMedia        = baileys?.prepareWAMessageMedia;

            if (!generateWAMessageFromContent || !prepareWAMessageMedia) {
                return await enviarAlbum(sock, from, m, sliced, query);
            }

            const cards = [];

            for (let i = 0; i < sliced.length; i++) {
                const imgUrl = sliced[i]?.image_url;
                if (!imgUrl) continue;

                try {
                    const media = await prepareWAMessageMedia(
                        { image: { url: imgUrl } },
                        { upload: sock.waUploadToServer }
                    );

                    const num = String(i + 1).padStart(2, '0');

                    cards.push({
                        header: {
                            title: `${num}  ✦  ${query}`,
                            hasMediaAttachment: true,
                            imageMessage: media.imageMessage
                        },
                        body: {
                            text: sliced[i]?.title
                                ? `❝ ${sliced[i].title} ❞`
                                : `📌 Imagem ${i + 1} de ${sliced.length}`
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'cta_copy',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `⬇️  𝗕𝗔𝗜𝗫𝗔𝗥  ·  ${num}`,
                                        copy_code: `.pin ${i + 1}`
                                    })
                                },
                                {
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '🌐  𝗔𝗕𝗥𝗜𝗥 𝗡𝗢 𝗕𝗥𝗢𝗪𝗦𝗘𝗥',
                                        url: imgUrl
                                    })
                                }
                            ]
                        }
                    });
                } catch (e) {
                    console.warn(`[PIN CARD ${i + 1}]`, e.message);
                }
            }

            if (!cards.length) {
                return await enviarAlbum(sock, from, m, sliced, query);
            }

            const msg = generateWAMessageFromContent(from, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: { title: '📌  𝗣𝗜𝗡𝗧𝗘𝗥𝗘𝗦𝗧' },
                            body: {
                                text: `🔎 *Busca:* ${query}\n🖼️ *Encontradas:* ${cards.length} imagens\n\n_Deslize os cards e toque em_ *⬇️ Baixar* _para salvar_`
                            },
                            footer: {
                                text: `✦ Miku-Bot 🤖  ·  .pin <nº> para baixar`
                            },
                            carouselMessage: { cards }
                        }
                    }
                }
            }, { userJid: sock.user.id, quoted: m });

            await sock.relayMessage(from, msg.message, { messageId: msg.key.id });
            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (error) {
            console.error('[PIN ERROR]', error.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, { text: `⚠️ Erro: ${error.message}` }, { quoted: m });
        }
    }
};

// ── Fallback: álbum simples ──
async function enviarAlbum(sock, from, m, sliced, query) {
    const albumMessage = [];
    for (let i = 0; i < sliced.length; i++) {
        const buf = await fetchImage(sliced[i]?.image_url);
        if (buf) albumMessage.push({
            image: buf,
            caption: `┏━᳀『 📌 Pinterest 』═᳀\n┖ ${sliced[i]?.title || query} · ${i + 1}/${sliced.length}`
        });
    }
    if (!albumMessage.length) {
        return sock.sendMessage(from, { text: '❌ Não foi possível carregar as imagens.' }, { quoted: m });
    }
    if (albumMessage.length === 1) {
        await sock.sendMessage(from, albumMessage[0], { quoted: m });
    } else {
        await sock.sendMessage(from, { albumMessage }, { quoted: m });
    }
    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
}

// ── Download via /api/v2/pinterest ──
async function baixarEEnviar(sock, from, m, item, emPV) {
    try {
        const { data } = await axios.get(`${API_BASE}/api/v2/pinterest`, {
            params: { url: item.image_url, apikey: API_KEY },
            timeout: 30000
        });

        const title    = data?.title        || item?.title || 'Pinterest';
        const mediaUrl = data?.download_url || data?.url   || data?.image_url || item?.image_url;

        if (!mediaUrl) {
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(from, { text: '❌ Falha ao obter URL de download.' }, { quoted: m });
        }

        const imgBuf = await fetchImage(mediaUrl);

        if (!imgBuf) {
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(from, { text: '❌ Falha ao baixar a imagem.' }, { quoted: m });
        }

        if (!emPV) {
            await sock.sendMessage(from, {
                text: `╔━᳀『 𝗣𝗶𝗻𝘁𝗲𝗿𝗲𝘀𝘁 𝗗𝗟 』═᳀\n` +
                      `⌬ *Título:* ${title}\n` +
                      `⌬ *Qualidade:* Original\n` +
                      `⌬ *Status:* ⬇️ Baixando...\n` +
                      `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: '⬇️', key: m.key } });

        const caption = `┏━᳀『 📌 𝗣𝗶𝗻𝘁𝗲𝗿𝗲𝘀𝘁 』═᳀\n┖ ${title}`;

        if (emPV) {
            await sock.sendMessage(from, {
                image: imgBuf,
                caption,
                mimetype: 'image/jpeg'
            }, { quoted: m });
        } else {
            await sock.sendMessage(from, {
                image: imgBuf,
                caption,
                mimetype: 'image/jpeg',
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: CHANNEL_JID,
                        newsletterName: CHANNEL_NAME,
                        serverMessageId: 1
                    }
                }
            }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error('[PIN DL ERROR]', err.message);
        await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
        sock.sendMessage(from, { text: `⚠️ Erro: ${err.message}` }, { quoted: m });
    }
}
