// src/commands/membros/tiktok.js
// TikTok Downloader - Miku Bot v2 (versão simplificada, sem Baileys)
// API: systemzone.store/api/downloads/tiktokv3?apikey=${config.apis.zoneApi}

const axios = require('axios');
const { config } = require('../../../settings/config.js');

const safe = async fn => { try { return await fn(); } catch { return null; } };

function formatNum(n) {
    const num = Number(n);
    if (!n && n !== 0) return '0';
    if (isNaN(num)) return String(n);
    if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1).replace('.', ',')}M`;
    if (num >= 1_000) return `${(num / 1_000).toFixed(1).replace('.', ',')}K`;
    return num.toLocaleString('pt-BR');
}

function extractUrl(text) {
    // Remove qualquer coisa antes de http:// ou https://
    const match = text.match(/https?:\/\/([^\s]+)/i);
    return match ? match[0] : null;
}

function isValidTikTokUrl(url) {
    const patterns = [/tiktok\.com/i, /vm\.tiktok/i, /vt\.tiktok/i];
    return patterns.some(p => p.test(url));
}

async function fetchTikTok(url) {
    const endpoint = `https://zone.api.br/api/downloads/tiktokv3?apikey=${config.apis.zoneApi}&url=${encodeURIComponent(url)}`;
    console.log('[TT] Chamando API:', endpoint);
    const res = await axios.get(endpoint, { timeout: 30000 });
    return res.data;
}

function gerarLayout(dados) {
    const autor = dados.autor || {};
    const stats = dados.stats || {};
    const musica = dados.musica || {};

    return (
        `╔━᳀『 Tɪᴋᴛᴏᴋ 』═᳀\n` +
        `⌬ *Título:* ${(dados.titulo || 'Sem título').slice(0, 80)}\n` +
        `⌬ *Duração:* ${dados.duracao || '?'}\n` +
        `⌬ *Região:* ${dados.regiao || 'Global'}\n` +
        `⌬ *Autor:* ${autor.nickname || '?'} (@${autor.username || '?'})\n` +
        `⌬ *Seguidores:* ${formatNum(autor.followers || 0)}\n` +
        `⌬ *Verificado:* ${autor.verified ? '✅ Sim' : '❌ Não'}\n` +
        `⌬ *Likes:* ${formatNum(stats.like || 0)}\n` +
        `⌬ *Views:* ${formatNum(stats.views || 0)}\n` +
        `⌬ *Comentários:* ${formatNum(stats.comment || 0)}\n` +
        `⌬ *Compartilhamentos:* ${formatNum(stats.share || 0)}\n` +
        `⌬ *Música:* ${musica.title || '?'} - ${musica.author || '?'}\n` +
        `╚═━═━═━═━═━═━═━═━═᳀`
    );
}

module.exports = {
    name: 'tiktok',
    aliases: ['ttk', 'tt', 'tiktokdl'],
    description: 'Baixa vídeo/álbum do TikTok com informações.',
    usage: 'tiktok <link>',

    async execute(sock, m, options) {
        const { from, args } = options;

        let rawText = (args || []).join(' ').trim();

        // Se veio por resposta, tenta pegar o texto da mensagem citada
        if (!rawText && m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage;
            rawText = quoted.conversation || quoted.extendedTextMessage?.text || '';
        }

        if (!rawText) {
            return sock.sendMessage(from, {
                text: `⚠️ *Comando Inválido!*\nEnvie ou responda a um link do TikTok.\nExemplo: \`!tt https://vm.tiktok.com/...\``
            }, { quoted: m });
        }

        // Extrai a URL de dentro do texto (remove qualquer texto extra)
        let link = extractUrl(rawText);
        if (!link) {
            return sock.sendMessage(from, { text: `❌ Nenhum link válido encontrado.` }, { quoted: m });
        }

        if (!isValidTikTokUrl(link)) {
            return sock.sendMessage(from, { text: `❌ Link inválido. Envie um link do TikTok.` }, { quoted: m });
        }

        await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

        try {
            const res = await fetchTikTok(link);
            if (!res || !res.status) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, { text: `❌ Conteúdo não encontrado (privado ou link quebrado).` }, { quoted: m });
            }

            const caption = gerarLayout(res);

            if (res.is_video && res.download_url) {
                await sock.sendMessage(from, { react: { text: '📥', key: m.key } });
                await sock.sendMessage(from, {
                    video: { url: res.download_url },
                    caption: caption,
                    mimetype: 'video/mp4'
                }, { quoted: m });
            } 
            else if (res.imagens && res.imagens.length > 0) {
                await sock.sendMessage(from, { react: { text: '📸', key: m.key } });
                // Envia primeira imagem com legenda, as demais sem legenda
                for (let i = 0; i < res.imagens.length; i++) {
                    await sock.sendMessage(from, {
                        image: { url: res.imagens[i] },
                        caption: i === 0 ? caption : `🖼️ Item ${i+1}/${res.imagens.length}`
                    }, { quoted: m });
                    await new Promise(r => setTimeout(r, 500));
                }
            }
            else {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, { text: `❌ Nenhuma mídia encontrada.` }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
        } catch (err) {
            console.error('[TT] Erro:', err.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, { text: `❌ Erro ao processar o TikTok. Tente novamente.` }, { quoted: m });
        }
    }
};