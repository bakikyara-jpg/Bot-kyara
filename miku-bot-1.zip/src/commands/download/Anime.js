// src/commands/membros/anime.js
const axios = require('axios');
const { config } = require('../../../settings/config.js');

const API_BASE     = 'https://zone.api.br'; // ajuste se necessário
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

if (!global.animeCache) global.animeCache = {};

function isPV(jid) { return !jid.endsWith('@g.us'); }

async function fetchImage(url) {
    if (!url) return null;
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 10000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        return Buffer.from(res.data);
    } catch { return null; }
}

module.exports = {
    name: 'anime',
    aliases: ['anime2', 'animeep'],
    description: 'Busca animes e lista episódios dublados',

    async execute(sock, m, options) {
        const { from, args, sender } = options;

        if (!args?.length) {
            return sock.sendMessage(from, {
                text: `╔━᳀『 Aɴɪᴍᴇ Sᴇᴀʀᴄʜ 』═᳀\n` +
                      `⌬ Use: *.anime <nome do anime>*\n` +
                      `⌬ Ex: *.anime Naruto*\n` +
                      `⌬ EP:  *.anime 3* (após buscar)\n` +
                      `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        const input = args.join(' ');
        const isNum = /^\d+$/.test(input.trim());

        try {
            // ── Seleção de episódio por número ──
            if (isNum) {
                const cache = global.animeCache?.[from];

                if (!cache?.episodios?.length) {
                    return sock.sendMessage(from, {
                        text: `❌ Nenhuma busca ativa!\n_Faça uma busca primeiro com_ *.anime nome*`
                    }, { quoted: m });
                }
                if (cache.owner !== sender) {
                    return sock.sendMessage(from, {
                        text: '❌ Essa lista pertence a outra pessoa!\n_Faça sua própria busca com_ *.anime nome*'
                    }, { quoted: m });
                }

                const userIndex = parseInt(input.trim());
                if (userIndex < 1 || userIndex > cache.episodios.length) {
                    return sock.sendMessage(from, {
                        text: `❌ Episódio inválido. Escolha entre *1* e *${cache.episodios.length}*`
                    }, { quoted: m });
                }

                const ep = cache.episodios[userIndex - 1];
                if (!ep) return sock.sendMessage(from, { text: '❌ Episódio não encontrado.' }, { quoted: m });

                const link = ep.players?.[0] || ep.url || '—';

                await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

                const textoEp =
                    `╔━᳀『 Aɴɪᴍᴇ Eᴘɪsᴏ́ᴅɪᴏ 』═᳀\n` +
                    `⌬ *Título:* ${cache.anime}\n` +
                    `⌬ *Episódio:* ${userIndex}\n` +
                    `⌬ *Idioma:* Dublado\n` +
                    `╚═━═━═━═━═━═━═━═━═᳀\n\n` +
                    `*Link para assistir:*\n${link}`;

                await sock.sendMessage(from, { text: textoEp }, { quoted: m });
                await sock.sendMessage(from, { react: { text: '🐦‍🔥', key: m.key } });
                return;
            }

            // ── Busca por nome ──
            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            const { data } = await axios.get(`${API_BASE}/api/anime/search`, {
                params: { q: input },
                timeout: 30000
            });

            // Ajuste os campos conforme o retorno real da sua API
            const anime    = data?.title  || data?.name  || input;
            const episodios = data?.episodes || data?.episodios || [];
            const capa      = data?.thumbnail || data?.cover || null;

            if (!episodios.length) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: '❌ Nenhum episódio encontrado para esse anime.'
                }, { quoted: m });
            }

            global.animeCache[from] = { owner: sender, anime, episodios };

            const coverBuf = await fetchImage(capa);

            const lista = episodios.map((ep, i) =>
                `*[ ${i + 1} ]* EP ${ep.numero || ep.number || i + 1}` +
                `${ep.titulo || ep.title ? ` — ${ep.titulo || ep.title}` : ''}`
            ).join('\n');

            const textoLista =
                `╔━᳀『 Aɴɪᴍᴇ Sᴇᴀʀᴄʜ 』═᳀\n` +
                `⌬ *Anime:* ${anime}\n` +
                `⌬ *Episódios:* ${episodios.length}\n` +
                `⌬ *Idioma:* Dublado\n` +
                `╠━᳀\n` +
                lista + '\n' +
                `╠━᳀\n` +
                `⌬ _Envie o número do episódio (Ex: .anime 1)_\n` +
                `╚═━═━═━═━═━═━═━═━═᳀`;

            if (coverBuf && !isPV(from)) {
                await sock.sendMessage(from, {
                    image: coverBuf,
                    caption: textoLista,
                    mimetype: 'image/jpeg',
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: Math.floor(Math.random() * 999999)
                        }
                    }
                }, { quoted: m });
            } else {
                await sock.sendMessage(from, { text: textoLista }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (error) {
            console.error('[ANIME ERROR]', error.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, { text: `⚠️ Erro: ${error.message}` }, { quoted: m });
        }
    }
};
