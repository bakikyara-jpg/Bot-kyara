// src/commands/membros/playvid.js
const axios = require('axios');
const { config } = require('../../../settings/config.js');

const API_URL      = 'https://zone.api.br/api/ytmp4';
const API_KEY = config.apis.zoneApi;
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

const QUALIDADES = [2160, 1440, 1080, 720, 480, 360, 240, 144];

function resolverQualidade(pedido) {
    const p = parseInt(pedido);
    if (isNaN(p)) return null;
    return QUALIDADES.find(q => q <= p) || QUALIDADES[QUALIDADES.length - 1];
}

function isPV(jid) { return !jid.endsWith('@g.us'); }

function getThumbUrl(ytUrl) {
    const match = ytUrl?.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    return match ? `https://i.ytimg.com/vi/${match[1]}/maxresdefault.jpg` : null;
}

module.exports = {
    name: 'playvid',
    aliases: ['playvideo', 'ytmp4'],
    description: 'Baixa e envia vídeo do YouTube com escolha de qualidade',

    async execute(sock, m, options) {
        const { from, args } = options;

        if (!args?.length) {
            return sock.sendMessage(from, {
                text:
                    `╔━᳀『 Play Vídeo 』═᳀\n` +
                    `⌬ Use: *.playvid <nome ou link>*\n` +
                    `⌬ Qualidade: *.playvid KLYN | 720*\n` +
                    `⌬ Qualidades: 144 · 240 · 360 · 480 · 720 · 1080\n` +
                    `⌬ Se a qual. não existir, usa a mais próxima\n` +
                    `╚═━═━═━═━═━═━═━═━═᳀`
            }, { quoted: m });
        }

        const fullInput = args.join(' ');
        const [inputRaw, qualRaw] = fullInput.split('|').map(s => s.trim());
        const qualidade = resolverQualidade(qualRaw);

        try {
            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            const params = { text: inputRaw, apikey: API_KEY };
            if (qualidade) params.quality = qualidade;

            const { data } = await axios.get(API_URL, { params, timeout: 60000 });

            if (!data?.status || !data?.result?.download) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, { text: '❌ Vídeo não encontrado.' }, { quoted: m });
            }

            const { title = 'Desconhecido', duration = '??:??', download: dlUrl, youtube_url: ytUrl } = data.result;
            const quality = data.result.quality || (qualidade ? `${qualidade}p` : 'HD');

            // Thumb
            let thumbBuf = null;
            const thumbUrl = getThumbUrl(ytUrl || inputRaw);
            if (thumbUrl) {
                const r = await axios.get(thumbUrl, { responseType: 'arraybuffer', timeout: 10000, headers: { 'User-Agent': 'Mozilla/5.0' } }).catch(() => null);
                if (r?.data) thumbBuf = Buffer.from(r.data);
            }

            const legenda =
                `╔━᳀『 Play Downloader 』═᳀\n` +
                `⌬ *Título :* ${title}\n` +
                `⌬ *Duração :* ${duration}\n` +
                `⌬ *Qualidade :* ${quality}\n` +
                `⌬ *Status :* Enviando vídeo...\n` +
                `╚═━═━═━═━═━═━═━═━═᳀`;

            // Baixa o vídeo em buffer antes de enviar
            await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });
            const vidRes = await axios.get(dlUrl, {
                responseType: 'arraybuffer',
                timeout: 180000,
                headers: { 'User-Agent': 'Mozilla/5.0' },
                maxContentLength: 200 * 1024 * 1024
            });
            const vidBuf = Buffer.from(vidRes.data);

            await sock.sendMessage(from, { react: { text: '⬇️', key: m.key } });

            if (isPV(from)) {
                await sock.sendMessage(from, {
                    video: vidBuf,
                    caption: legenda,
                    mimetype: 'video/mp4'
                }, { quoted: m });
            } else {
                await sock.sendMessage(from, {
                    ...(thumbBuf ? { image: thumbBuf, mimetype: 'image/jpeg' } : { text: legenda }),
                    caption: thumbBuf ? legenda : undefined,
                    contextInfo: {
                        forwardingScore: 999, isForwarded: true,
                        forwardedNewsletterMessageInfo: { newsletterJid: CHANNEL_JID, newsletterName: CHANNEL_NAME, serverMessageId: Math.floor(Math.random() * 999999) }
                    }
                }, { quoted: m });

                await sock.sendMessage(from, {
                    video: vidBuf,
                    mimetype: 'video/mp4',
                    contextInfo: {
                        forwardingScore: 999, isForwarded: true,
                        forwardedNewsletterMessageInfo: { newsletterJid: CHANNEL_JID, newsletterName: CHANNEL_NAME, serverMessageId: Math.floor(Math.random() * 999999) }
                    }
                });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[PLAYVID ERROR]', err.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, { text: `⚠️ Erro: ${err.response?.data?.message || err.message}` }, { quoted: m });
        }
    }
};