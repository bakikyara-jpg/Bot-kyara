// src/commands/membros/dlp.js
// Download de áudio e vídeo — SystemZone API (apikey: Yamiku)

const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const http  = require('http');
const https = require('https');
const { config } = require('../../../settings/config.js');

// ══════════════════════════════════════════
//  CONFIG
// ══════════════════════════════════════════

const API_KEY = config.apis.zoneApi;
const API_V1  = 'https://zone.api.br/v1/dlp';
const API_V2  = 'https://zone.api.br/v2/dlp';

const TMP = path.resolve('./tmp');
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

const agentHttps = new https.Agent({ keepAlive: true, maxSockets: 16 });
const agentHttp  = new http.Agent({  keepAlive: true, maxSockets: 16 });

// ══════════════════════════════════════════
//  UTILITÁRIOS
// ══════════════════════════════════════════

function tmpFile(ext) {
    return path.join(TMP, `dlp_${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`);
}

function cleanFiles(...paths) {
    for (const p of paths) {
        try { if (p && fs.existsSync(p)) fs.unlinkSync(p); } catch {}
    }
}

function formatDuration(sec) {
    if (!sec) return null;
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${h}h${String(m).padStart(2,'0')}m${String(s).padStart(2,'0')}s`;
    return `${m}m${String(s).padStart(2,'0')}s`;
}

function sanitizeTitle(title) {
    return (title || 'arquivo')
        .replace(/&#039;/g, "'")
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/[<>:"/\\|?*]/g, '')
        .trim()
        .slice(0, 80);
}

// ══════════════════════════════════════════
//  DOWNLOAD EM BUFFER (RAM) COM CHUNKS
// ══════════════════════════════════════════

async function streamToBuffer(url) {
    const res = await axios({
        url, method: 'GET', responseType: 'arraybuffer',
        timeout: 300000,
        headers: { 'User-Agent': 'Mozilla/5.0', 'Connection': 'keep-alive', 'Accept-Encoding': 'identity' },
        httpsAgent: agentHttps, httpAgent: agentHttp, maxRedirects: 10
    });
    return Buffer.from(res.data);
}

async function streamToBufferFast(url) {
    // HEAD para verificar Range e tamanho
    let totalSize = 0, supportsRange = false;
    try {
        const head = await axios.head(url, {
            timeout: 8000,
            headers: { 'User-Agent': 'Mozilla/5.0' },
            httpsAgent: agentHttps, maxRedirects: 10
        });
        totalSize     = parseInt(head.headers['content-length'] || 0);
        supportsRange = (head.headers['accept-ranges'] || '').includes('bytes');
    } catch {}

    // Sem suporte a Range ou pequeno — baixa direto
    if (!supportsRange || totalSize < 15 * 1024 * 1024) {
        return streamToBuffer(url);
    }

    // 8 chunks paralelos
    const CHUNKS    = 8;
    const chunkSize = Math.ceil(totalSize / CHUNKS);
    const buffers   = new Array(CHUNKS);

    await Promise.all(Array.from({ length: CHUNKS }, async (_, i) => {
        const start = i * chunkSize;
        const end   = Math.min(start + chunkSize - 1, totalSize - 1);
        const res   = await axios({
            url, method: 'GET', responseType: 'arraybuffer',
            timeout: 300000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Range': `bytes=${start}-${end}`,
                'Connection': 'keep-alive',
                'Accept-Encoding': 'identity'
            },
            httpsAgent: new https.Agent({ keepAlive: true, maxSockets: 16 }),
            maxRedirects: 10
        });
        buffers[i] = Buffer.from(res.data);
    }));

    return Buffer.concat(buffers);
}

async function streamToDisk(url, destPath) {
    const res = await axios({
        url, method: 'GET', responseType: 'stream',
        timeout: 300000,
        headers: { 'User-Agent': 'Mozilla/5.0', 'Connection': 'keep-alive', 'Accept-Encoding': 'identity' },
        httpsAgent: agentHttps, httpAgent: agentHttp, maxRedirects: 10
    });
    const writer = fs.createWriteStream(destPath);
    res.data.pipe(writer);
    await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
        res.data.on('error', reject);
    });
    return fs.statSync(destPath).size;
}

// ══════════════════════════════════════════
//  BUSCA NA API SYSTEMZONE
// ══════════════════════════════════════════

async function fetchFromAPI(url, isVideo, quality) {
    const formato = isVideo ? 'mp4' : 'opus';

    // V2 com qualidade
    if (isVideo && quality) {
        try {
            const { data } = await axios.get(API_V2, {
                params: { apikey: API_KEY, url, format: formato, quality: String(quality) },
                timeout: 30000
            });
            if (data?.status && data?.download_url) {
                return {
                    title:       sanitizeTitle(data.title),
                    downloadUrl: data.download_url.replace(/^http:\/\//i, 'https://'),
                    size:        data.size      || null,
                    duration:    data.duration  || null,
                    thumbnail:   data.thumbnail || null,
                    quality:     data.quality   || `${quality}p`,
                    ext:         data.download_url.split('?')[0].split('.').pop().toLowerCase() || 'mp4'
                };
            }
        } catch (e) {
            console.warn('[DLP] V2 falhou, tentando V1:', e.message);
        }
    }

    // V1 automático
    const { data } = await axios.get(API_V1, {
        params: { apikey: API_KEY, url, format: formato },
        timeout: 30000
    });

    if (!data?.status || !data?.download_url) {
        throw new Error(data?.message || 'API não retornou resultado');
    }

    return {
        title:       sanitizeTitle(data.title),
        downloadUrl: data.download_url.replace(/^http:\/\//i, 'https://'),
        size:        data.size      || null,
        duration:    data.duration  || null,
        thumbnail:   data.thumbnail || null,
        quality:     data.quality   || null,
        ext:         data.download_url.split('?')[0].split('.').pop().toLowerCase() || formato
    };
}

// ══════════════════════════════════════════
//  ENVIO DE VÍDEO (6 estratégias em cascata)
// ══════════════════════════════════════════

async function sendVideo(sock, chat, m, info, uQual) {
    const { title, downloadUrl, size, duration, ext } = info;
    const files = [];

    const sizeStr = String(size || '').toUpperCase();
    const sizeMB  = sizeStr.includes('GB')
        ? parseFloat(sizeStr) * 1024
        : sizeStr.includes('MB') ? parseFloat(sizeStr) : 0;

    const caption = [
        `🎬 *${title}*`,
        duration ? `⏱️ ${formatDuration(duration)}` : '',
        uQual    ? `📐 ${uQual}p`                   : '',
        sizeMB   ? `📦 ~${sizeMB.toFixed(0)} MB`    : '',
        `\n_by YUKA_`
    ].filter(Boolean).join(' • ');

    try {

        // 1. URL direta (rápido, arquivos leves)
        const forceDownload = uQual >= 1080 || sizeMB > 50 || sizeStr.includes('GB');
        if (!forceDownload) {
            try {
                await sock.sendMessage(chat, { video: { url: downloadUrl }, caption, gifPlayback: false }, { quoted: m });
                return;
            } catch (e) { console.warn('[DLP] Estratégia 1 falhou:', e.message); }
        }

        // 2. Buffer com chunks paralelos (4K acelerado)
        try {
            const buffer    = await streamToBufferFast(downloadUrl);
            const bufSizeMB = buffer.length / 1024 / 1024;

            if (bufSizeMB <= 95) {
                await sock.sendMessage(chat, { video: buffer, mimetype: 'video/mp4', caption, gifPlayback: false }, { quoted: m });
                return;
            }
            if (bufSizeMB <= 1900) {
                await sock.sendMessage(chat, { document: buffer, mimetype: 'video/mp4', fileName: `${title}.${ext || 'mp4'}`, caption }, { quoted: m });
                return;
            }
        } catch (e) { console.warn('[DLP] Estratégia 2 falhou:', e.message); }

        // 3. Download em disco
        const filePath = tmpFile(ext || 'mp4');
        files.push(filePath);
        const fileSize   = await streamToDisk(downloadUrl, filePath);
        const fileSizeMB = fileSize / 1024 / 1024;

        if (fileSizeMB <= 95) {
            await sock.sendMessage(chat, { video: fs.readFileSync(filePath), mimetype: 'video/mp4', caption, gifPlayback: false }, { quoted: m });
            return;
        }

        if (fileSizeMB <= 1900) {
            await sock.sendMessage(chat, { document: fs.readFileSync(filePath), mimetype: 'video/mp4', fileName: `${title}.${ext || 'mp4'}`, caption }, { quoted: m });
            return;
        }

        // 4. ZIP (4K gigante)
        const AdmZip  = require('adm-zip');
        const zipPath = tmpFile('zip');
        files.push(zipPath);
        const zip = new AdmZip();
        zip.addLocalFile(filePath, '', `${title}.${ext || 'mp4'}`);
        zip.writeZip(zipPath);
        await sock.sendMessage(chat, {
            document: fs.readFileSync(zipPath), mimetype: 'application/zip',
            fileName: `${title}.zip`, caption: `${caption}\n\n_📦 ZIP — extraia após baixar_`
        }, { quoted: m });

    } catch (e) {

        // 5. Documento via URL
        try {
            await sock.sendMessage(chat, { document: { url: downloadUrl }, mimetype: 'video/mp4', fileName: `${title}.${ext || 'mp4'}`, caption }, { quoted: m });
            return;
        } catch {}

        // 6. Só o link
        await sock.sendMessage(chat, {
            text: [`🎬 *${title}*`, uQual ? `📐 ${uQual}p` : '', ``, `⚠️ _Arquivo grande demais para enviar._`, `🔗 *Link direto:*`, downloadUrl, `\n_by YUKA_`].filter(Boolean).join('\n')
        }, { quoted: m });

    } finally {
        cleanFiles(...files);
    }
}

// ══════════════════════════════════════════
//  ENVIO DE ÁUDIO (3 estratégias)
// ══════════════════════════════════════════

async function sendAudio(sock, chat, m, info) {
    const { title, downloadUrl, duration, ext } = info;
    const files = [];

    const captionText = [`🎵 *${title}*`, duration ? `⏱️ ${formatDuration(duration)}` : '', `\n_by YUKA_`].filter(Boolean).join(' • ');

    try {
        // 1. URL direta
        try {
            await sock.sendMessage(chat, { audio: { url: downloadUrl }, mimetype: 'audio/mp4', ptt: false }, { quoted: m });
            await sock.sendMessage(chat, { text: captionText }, { quoted: m });
            return;
        } catch (e) { console.warn('[DLP] Áudio URL falhou:', e.message); }

        // 2. Buffer RAM
        try {
            const buffer = await streamToBuffer(downloadUrl);
            await sock.sendMessage(chat, { audio: buffer, mimetype: 'audio/mp4', ptt: false }, { quoted: m });
            await sock.sendMessage(chat, { text: captionText }, { quoted: m });
            return;
        } catch (e) { console.warn('[DLP] Áudio buffer falhou:', e.message); }

        // 3. Disco + documento
        const filePath = tmpFile(ext || 'opus');
        files.push(filePath);
        await streamToDisk(downloadUrl, filePath);
        await sock.sendMessage(chat, {
            document: fs.readFileSync(filePath), mimetype: 'audio/mpeg',
            fileName: `${title}.${ext || 'mp3'}`, caption: captionText
        }, { quoted: m });

    } finally {
        cleanFiles(...files);
    }
}

// ══════════════════════════════════════════
//  MÓDULO PRINCIPAL
// ══════════════════════════════════════════

module.exports = {
    name: 'dlp',
    aliases: ['dlpv', 'ytmp3', 'ytmp4', 'baixar'],
    description: 'Baixa vídeo ou áudio de qualquer plataforma',
    usage: 'dlp <link> | dlpv <link> | dlpv <link> | 1080',

    async execute(sock, m, options) {
        // ── Extrai variáveis no padrão do seu bot ───
        const command = options?.command  || options?.cmd || '';
        const prefix  = options?.prefix   || '.';
        const text    = options?.args?.join(' ') || options?.text || '';
        const chat    = options?.from     || m?.chat || m?.key?.remoteJid;

        const isVideo = command === 'dlpv' || command === 'ytmp4' || command === 'baixar';

        // ── Help ────────────────────────────────────
        if (!text.trim()) {
            await sock.sendMessage(chat, {
                text: [
                    `╔━᳀『 *⬇️ YUKA DLP* 』═᳀`,
                    `━━━━━━━━━━━━━━━━━━`,
                    ``,
                    `🎵 *Áudio:*`,
                    `\`${prefix}dlp <link>\``,
                    ``,
                    `🎬 *Vídeo:*`,
                    `\`${prefix}dlpv <link>\``,
                    `\`${prefix}dlpv <link> | 720\``,
                    `\`${prefix}dlpv <link> | 1080\``,
                    `\`${prefix}dlpv <link> | 1440\` _(2K)_`,
                    `\`${prefix}dlpv <link> | 2160\` _(4K)_`,
                    ``,
                    `🌐 *Suporta:* YouTube • TikTok • Instagram`,
                    `Twitter/X • Facebook • Vimeo • SoundCloud e +`,
                    ``,
                    `━━━━━━━━━━━━━━━━━━`,
                    `╚═━═━═━═━═━═━═━═━═᳀`
                ].join('\n')
            }, { quoted: m });
            return;
        }

        // ── Parse URL e qualidade ───────────────────
        const [rawUrl, rawQual = ''] = text.split('|').map(s => s.trim());
        const uQual = parseInt(rawQual) || 0;

        let url = rawUrl;
        if (!url.startsWith('http://') && !url.startsWith('https://')) url = 'https://' + url;

        try { new URL(url); } catch {
            await sock.sendMessage(chat, { text: '❌ URL inválida.' }, { quoted: m });
            return;
        }

        // ── React loading ───────────────────────────
        await sock.sendMessage(chat, { react: { text: '⏳', key: m.key } });

        // ── Mensagem de status ──────────────────────
        const plataforma =
            /youtu/.test(url)              ? 'YouTube'    :
            /tiktok/.test(url)             ? 'TikTok'     :
            /instagram/.test(url)          ? 'Instagram'  :
            /twitter|x\.com/.test(url)     ? 'Twitter/X'  :
            /facebook|fb\.watch/.test(url) ? 'Facebook'   :
            /vimeo/.test(url)              ? 'Vimeo'      :
            /soundcloud/.test(url)         ? 'SoundCloud' :
            /twitch/.test(url)             ? 'Twitch'     :
            /pinterest/.test(url)          ? 'Pinterest'  :
            /reddit\.com/.test(url)        ? 'Reddit'     : '🌐 Link';

        await sock.sendMessage(chat, {
            text: [
                `⬇️ *Baixando de ${plataforma}...*`,
                uQual ? `📐 Qualidade: ${uQual}p` : `📐 Qualidade: automática`,
                `📁 Formato: ${isVideo ? 'Vídeo (MP4)' : 'Áudio'}`,
                `_Aguarde..._`
            ].join('\n')
        }, { quoted: m });

        try {
            // ── Busca na API ────────────────────────
            const info = await fetchFromAPI(url, isVideo, uQual);

            // ── Thumbnail ───────────────────────────
            if (info.thumbnail && isVideo) {
                try {
                    await sock.sendMessage(chat, {
                        image:   { url: info.thumbnail },
                        caption: [
                            `🎬 *${info.title}*`,
                            info.duration ? `⏱️ ${formatDuration(info.duration)}` : '',
                            info.quality  ? `📐 ${info.quality}` : '',
                            info.size     ? `📦 ${info.size}`    : '',
                        ].filter(Boolean).join(' • ')
                    }, { quoted: m });
                } catch {}
            }

            // ── Envia arquivo ───────────────────────
            if (isVideo) {
                await sendVideo(sock, chat, m, info, uQual);
            } else {
                await sendAudio(sock, chat, m, info);
            }

            await sock.sendMessage(chat, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[DLP] Erro:', err?.message);
            await sock.sendMessage(chat, { react: { text: '❌', key: m.key } });
            await sock.sendMessage(chat, {
                text: [
                    `❌ *Erro ao baixar.*`,
                    `_${err?.message?.slice(0, 120) || 'Erro desconhecido'}_`,
                    `Verifique se o link é válido e tente novamente.`
                ].join('\n')
            }, { quoted: m });
        }
    }
};
