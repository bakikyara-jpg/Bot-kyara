const axios = require('axios');

const { config } = require('../../../settings/config.js');

let proto, generateWAMessageFromContent, prepareWAMessageMedia;
try {
    const baileys = require('@whiskeysockets/baileys');
    proto                        = baileys.proto;
    generateWAMessageFromContent = baileys.generateWAMessageFromContent;
    prepareWAMessageMedia        = baileys.prepareWAMessageMedia;
} catch (e) {
    console.error('[IG] Erro ao importar baileys:', e.message);
}

// ══════════════════════════════════════
//  CANAL
// ══════════════════════════════════════
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

// ══════════════════════════════════════
//  UTILITÁRIOS & FORMATAÇÃO
// ══════════════════════════════════════

const safe = async fn => { try { return await fn(); } catch { return null; } };

function formatNum(n) {
    const num = Number(n);
    if (!n && n !== 0) return '0';
    if (isNaN(num)) return String(n);
    if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1).replace('.', ',')}M`;
    if (num >= 1_000)     return `${(num / 1_000).toFixed(1).replace('.', ',')}K`;
    return num.toLocaleString('pt-BR');
}

function emojiLikes(likes) {
    const n = Number(likes) || 0;
    if (n >= 1_000_000) return '💥💥💥';
    if (n >= 100_000)   return '🔥 Formidável';
    if (n >= 10_000)    return '⚡ Popular';
    if (n >= 1_000)     return '❤️ Engajado';
    return '👍 Regular';
}

function tipoLabel(type, qtd) {
    if (type === 'video')    return '🎬 Vídeo / Reels';
    if (type === 'carousel') return `🖼️ Carrossel (${qtd} itens)`;
    return '📸 Foto Estática';
}

function calcularEngajamento(likes, followers) {
    if (!likes || !followers) return null;
    const taxa = ((likes / followers) * 100).toFixed(2);
    if (taxa > 10) return `${taxa}% (Altíssimo) 🚀`;
    if (taxa > 5)  return `${taxa}% (Ótimo) ✨`;
    return `${taxa}% (Padrão) 📉`;
}

// ══════════════════════════════════════
//  EXTRAI LINK DO CONTEXTO (FIX #1)
// ══════════════════════════════════════

function extrairLinkDoContexto(m) {
    const ctx = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!ctx) return '';

    // texto direto
    const texto =
        ctx.extendedTextMessage?.text ||
        ctx.conversation ||
        ctx.imageMessage?.caption ||
        ctx.videoMessage?.caption ||
        '';

    // procura URL do instagram no texto
    const match = texto.match(/https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\/[^\s]+/i);
    return match ? match[0] : '';
}

// ══════════════════════════════════════
//  FETCH API
// ══════════════════════════════════════

async function fetchIG(url) {
    // Remove prefixo "-ig " caso venha junto
    const cleanUrl = url.replace(/^-ig\s+/i, '').trim();
    const endpoint = `https://zone.api.br/api/V2/instagram?apikey=${config.apis.zoneApi}&url=${encodeURIComponent(cleanUrl)}`;
    console.log('[IG] Chamando API:', endpoint);
    const res = await axios.get(endpoint, {
        timeout: 25000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    console.log('[IG] Resposta status:', res.status);
    return res.data;
}

// ══════════════════════════════════════
//  LAYOUT TEXTO
// ══════════════════════════════════════

function gerarLayoutTexto(dados) {
    const autor       = dados.author?.name      || dados.author    || 'Não Informado';
    const username    = dados.author?.username  || dados.username  || 'desconhecido';
    const followers   = dados.author?.followers;
    const likes       = dados.stats?.likes      || dados.likes     || 0;
    const views       = dados.stats?.views      || dados.views     || null;
    const comments    = dados.stats?.comments   || dados.comments  || null;
    const caption     = dados.caption || '';
    const tipo        = tipoLabel(dados.type, dados.media?.length);
    const engajamento = followers && likes ? calcularEngajamento(likes, followers) : null;

    const linhas = [
        `╔━᳀『 Iɴsᴛᴀɢʀᴀᴍ Dᴏᴡɴʟᴏᴀᴅ 』═᳀`,
        `⌬ *Autor:* ${autor}`,
        `⌬ *Usuário:* @${username}`
    ];

    if (followers) linhas.push(`⌬ *Seguidores:* ${formatNum(followers)}`);
    linhas.push(`⌬ *Formato:* ${tipo}`);
    linhas.push(`⌬ *Curtidas:* ${formatNum(likes)} (${emojiLikes(likes)})`);
    if (views    != null) linhas.push(`⌬ *Visualizações:* ${formatNum(views)}`);
    if (comments != null) linhas.push(`⌬ *Comentários:* ${formatNum(comments)}`);
    if (engajamento)      linhas.push(`⌬ *Engajamento:* ${engajamento}`);

    const captionTrim = caption ? caption.slice(0, 200) : '_Sem legenda_';
    linhas.push(`⌬ *Legenda:* ${captionTrim}`);
    if (caption && caption.length > 200) linhas.push(`⌬ [Legenda truncada...]`);
    linhas.push(`╚═━═━═━═━═━═━═━═━═᳀`);

    return linhas.join('\n');
}

// ══════════════════════════════════════
//  contextInfo com canal (FIX #2 e #3)
// ══════════════════════════════════════

function ctxCanal(titulo, subtitulo) {
    return {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: CHANNEL_JID,
            newsletterName: CHANNEL_NAME,
            serverMessageId: Math.floor(Math.random() * 999999)
        },
        externalAdReply: {
            title: titulo || 'Instagram Download',
            body: subtitulo || 'Baixado pelo Miku-Bot',
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
        }
    };
}

// ══════════════════════════════════════
//  ENVIA COM INTERACTIVE (proto)
// ══════════════════════════════════════

async function enviarComInteractive(sock, jid, m, dados, link, urlMidia, isVideo) {
    const texto = gerarLayoutTexto(dados);
    const autor = dados.author?.name || dados.author || 'Instagram';

    console.log('[IG] Preparando upload da mídia:', urlMidia);
    const configMedia = isVideo ? { video: { url: urlMidia } } : { image: { url: urlMidia } };
    const mediaUpload = await prepareWAMessageMedia(configMedia, { upload: sock.waUploadToServer });
    console.log('[IG] Upload concluído.');

    const botoes = [
        {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
                display_text: '📱 Acessar Post no Instagram',
                url: link,
                merchant_url: link
            })
        }
    ];

    if (dados.type === 'carousel' && dados.media?.length > 1) {
        botoes.push({
            name: 'cta_copy',
            buttonParamsJson: JSON.stringify({
                display_text: '📋 Copiar Links do Carrossel',
                id: 'copy_links',
                copy_code: dados.media.join('\n')
            })
        });
    }

    const payload = {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: texto }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `✦ ${CHANNEL_NAME} • Instagram Downloader`
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: true,
                        ...(isVideo
                            ? { videoMessage: mediaUpload.videoMessage }
                            : { imageMessage: mediaUpload.imageMessage })
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: botoes
                    }),
                    // FIX #2: canal no interactive
                    contextInfo: proto.ContextInfo.create(ctxCanal(autor, `@${dados.author?.username || 'instagram'}`))
                })
            }
        }
    };

    const msgFinal = generateWAMessageFromContent(jid, payload, { quoted: m });
    await sock.relayMessage(jid, msgFinal.message, { messageId: msgFinal.key.id });
}

// ══════════════════════════════════════
//  ENVIA SIMPLES (fallback sem proto)
// ══════════════════════════════════════

async function enviarSimples(sock, jid, m, dados, link, urlMidia, isVideo) {
    const legenda = gerarLayoutTexto(dados);
    const autor   = dados.author?.name || 'Instagram';
    const user    = dados.author?.username || 'instagram';

    const msgBase = {
        caption: legenda,
        contextInfo: ctxCanal(autor, `@${user}`)
    };

    if (isVideo) {
        await sock.sendMessage(jid, { video: { url: urlMidia }, ...msgBase }, { quoted: m });
    } else {
        await sock.sendMessage(jid, { image: { url: urlMidia }, ...msgBase }, { quoted: m });
    }
}

// ══════════════════════════════════════
//  COMANDO PRINCIPAL
// ══════════════════════════════════════

module.exports = {
    name: 'instagram',
    aliases: ['ig', 'insta', 'igdl', 'instadl'],
    description: 'Baixa fotos, vídeos e carrosséis do Instagram com dados detalhados.',
    usage: 'ig <link do post>',

    async execute(sock, m, options) {
        const { from, args } = options;

        try {
            // FIX #1: extrai link de args OU do quoted (texto, imagem legendada, vídeo legendado)
            let link = (args || []).join(' ').trim();

            if (!link || !link.includes('instagram')) {
                link = extrairLinkDoContexto(m);
            }

            if (!link) {
                return await sock.sendMessage(from, {
                    text: `⚠️ *Comando Inválido!*\n\nEnvie ou responda a um link válido do Instagram.\nExemplo: \`!ig https://www.instagram.com/p/...\``
                }, { quoted: m });
            }

            if (!link.includes('instagram.com') && !link.includes('instagr.am')) {
                return await sock.sendMessage(from, {
                    text: `❌ *Link Inválido!* Certifique-se de que é um link do Instagram.`
                }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

            let dados;
            try {
                dados = await fetchIG(link);
            } catch (apiErr) {
                console.error('[IG] Erro na API:', apiErr.message);
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, {
                    text: `❌ *Falha de Conexão:*\nO servidor da API não respondeu a tempo.`
                }, { quoted: m });
            }

            if (!dados || !dados.status) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, {
                    text: `❌ *Post Indisponível!*\n\nA API não conseguiu extrair os dados. O post pode ser de uma *conta privada* ou o link está quebrado.`
                }, { quoted: m });
            }

            const medias = Array.isArray(dados.media) ? dados.media : (dados.media ? [dados.media] : []);
            if (!medias.length) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return await sock.sendMessage(from, {
                    text: `❌ *Mídia não encontrada na resposta do servidor.*`
                }, { quoted: m });
            }

            const urlMidia = medias[0];
            const isVideo  = dados.type === 'video';

            await sock.sendMessage(from, { react: { text: '📥', key: m.key } });

            let enviou = false;

            if (proto && generateWAMessageFromContent && prepareWAMessageMedia) {
                try {
                    await enviarComInteractive(sock, from, m, dados, link, urlMidia, isVideo);
                    enviou = true;
                } catch (interErr) {
                    console.error('[IG] Interactive falhou, usando fallback:', interErr.message);
                }
            }

            if (!enviou) {
                await enviarSimples(sock, from, m, dados, link, urlMidia, isVideo);
            }

            // Itens adicionais do carrossel
            if (dados.type === 'carousel' && medias.length > 1) {
                for (let i = 1; i < medias.length; i++) {
                    await safe(() => sock.sendMessage(from, {
                        image: { url: medias[i] },
                        caption: `🖼️ *Item Adicional [${i + 1}/${medias.length}]*`,
                        contextInfo: ctxCanal('Carrossel', `Item ${i + 1} de ${medias.length}`)
                    }));
                }
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[IG-CMD] Erro Crítico:', err.message);
            await safe(() => sock.sendMessage(from, { react: { text: '❌', key: m.key } }));
            await safe(() => sock.sendMessage(from, {
                text: `❌ *Ocorreu um erro interno ao processar seu pedido.*`
            }, { quoted: m }));
        }
    }
};