// src/commands/membros/play.js
const axios = require('axios');
const { config } = require('../../../settings/config.js');

const API_URL      = 'https://zone.api.br/v2/player';
const API_KEY = config.apis.zoneApi;
const CHANNEL_JID = config.channelJid;
const CHANNEL_NAME = config.channelName;

function isPV(jid) { return !jid.endsWith('@g.us'); }

function getThumbUrl(youtubeUrl) {
    if (!youtubeUrl) return null;
    const match = youtubeUrl.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    return match ? `https://i.ytimg.com/vi/${match[1]}/hqdefault.jpg` : null;
}

module.exports = {
    name: 'play',
    aliases: ['ptb', 'playtb'],
    description: 'Baixa e envia música do YouTube',

    async execute(sock, m, options) {
        const { from, args } = options;

        if (!args?.length) {
            return sock.sendMessage(from, {
                text: '🎵 Informe o nome da música ou link.'
            }, { quoted: m });
        }

        const userInput = args.join(' ');

        try {
            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            const { data } = await axios.get(API_URL, {
                params: { apikey: API_KEY, text: userInput },
                timeout: 30000
            });

            if (!data?.status || !data?.download_url) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: '❌ Música não encontrada.'
                }, { quoted: m });
            }

            const title    = data.title    || 'Desconhecido';
            const duration = data.duration || '??:??';
            const ytUrl    = data.youtube_url || userInput;
            const dlUrl    = data.download_url;

            // Thumb
            let thumbBuf = null;
            const thumbUrl = getThumbUrl(ytUrl);
            if (thumbUrl) {
                const r = await axios.get(thumbUrl, {
                    responseType: 'arraybuffer',
                    timeout: 10000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                }).catch(() => null);
                if (r?.data) thumbBuf = Buffer.from(r.data);
            }

            const textoCard =
                `╔━᳀『 Play Downloader 』═᳀\n` +
                `⌬ *Título :* ${title}\n` +
                `⌬ *Duração :* ${duration}\n` +
                `⌬ *Status :* Enviando áudio...\n` +
                `╚═━═━═━═━═━═━═━═━═᳀`;

            const emPV = isPV(from);

            if (!emPV) {
                if (thumbBuf) {
                    await sock.sendMessage(from, {
                        image: thumbBuf,
                        caption: textoCard,
                        mimetype: 'image/jpeg',
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: CHANNEL_JID,
                                newsletterName: CHANNEL_NAME,
                                serverMessageId: Math.floor(Math.random() * 999999)
                            }
                        }
                    }, { quoted: m });
                } else {
                    await sock.sendMessage(from, {
                        text: textoCard,
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: CHANNEL_JID,
                                newsletterName: CHANNEL_NAME,
                                serverMessageId: Math.floor(Math.random() * 999999)
                            }
                        }
                    }, { quoted: m });
                }
            }

            await sock.sendMessage(from, { react: { text: '⬇️', key: m.key } });

            if (emPV) {
                await sock.sendMessage(from, {
                    audio: { url: dlUrl },
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    ptt: false
                }, { quoted: m });
            } else {
                await sock.sendMessage(from, {
                    audio: { url: dlUrl },
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    ptt: false,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: 1
                        }
                    }
                }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[PLAY ERROR]', err.message);
            await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
            sock.sendMessage(from, {
                text: `⚠️ Erro: ${err.message}`
            }, { quoted: m });
        }
    }
};