const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "socar",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica quem vai levar o murro (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot avisa
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Você precisa marcar ou responder a alguém para dar um soco!" 
                }, { quoted: m });
            }

            // Impede de se auto-espancar
            if (targetJid === sender) {
                return await sock.sendMessage(from, { text: "❌ Bater em si mesmo? Vai se tratar, doido!" }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Gera a força do soco
            const forcaSoco = Math.floor(Math.random() * 101);

            // Frases de impacto (Zueira)
            const frases = [
                "O soco passou tão longe que você quase deslocou o ombro sozinho. 💨",
                "Foi um soco ou um carinho? O alvo nem sentiu. 😏",
                "Acertou em cheio! O barulho foi seco, o alvo deu uma balançada. 🥴",
                "MURRO CRÍTICO! Um dente voou direto no meio do grupo. 🦷",
                "NAKAUT! O cara tá vendo a Miku girando e estrelinhas no teto. 💫",
                "DESTRUIÇÃO TOTAL! O soco foi tão forte que a alma dele saiu pra dar uma volta. 💀"
            ];

            let status;
            if (forcaSoco <= 15) status = frases[0];
            else if (forcaSoco <= 35) status = frases[1];
            else if (forcaSoco <= 55) status = frases[2];
            else if (forcaSoco <= 75) status = frases[3];
            else if (forcaSoco <= 90) status = frases[4];
            else status = frases[5];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Aᴛᴛᴀᴄᴋ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Força:* " + forcaSoco + "%\n" +
                "⌬ *Resultado:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777555869/trindade-1777555868691.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[SOCAR-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar dar um soco." });
        }
    }
};