const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "ovo",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica a vítima (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot barra
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Você precisa marcar ou responder alguém pra levar essa ovada!" 
                }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Medidor de sujeira
            const nivelSujeira = Math.floor(Math.random() * 101);

            // Frases da zueira
            const frases = [
                "Errou o alvo e o ovo acertou a parede. Péssima mira! 🧱",
                "O ovo só raspou, a vítima saiu quase ilesa. 💨",
                "Acertou no ombro! Já tá começando a feder. 🤢",
                "NA CARA! O estrago foi grande, parece um omelete ambulante. 🍳",
                "NA NUCA! A gema escorreu pelas costas todinha, que nojo! 🤮",
                "OVADA CRÍTICA! O ovo tava podre e o cheiro desmaiou metade do grupo. 💀"
            ];

            let status;
            if (nivelSujeira <= 15) status = frases[0];
            else if (nivelSujeira <= 35) status = frases[1];
            else if (nivelSujeira <= 55) status = frases[2];
            else if (nivelSujeira <= 75) status = frases[3];
            else if (nivelSujeira <= 90) status = frases[4];
            else status = frases[5];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Aᴛᴛᴀᴄᴋ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Sujeira:* " + nivelSujeira + "%\n" +
                "⌬ *Dano:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777554962/trindade-1777554960774.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[OVO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar jogar o ovo." });
        }
    }
};