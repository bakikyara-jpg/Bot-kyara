module.exports = {
    name: "radar",
    aliases: ["solteira", "mulher", "namorada"],
    async execute(sock, m, options) {
        const { from } = options;

        try {
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);
            const distancia = (Math.random() * 9.9 + 0.1).toFixed(1);
            const minutos = Math.floor(Math.random() * 55 + 5);

            const nomes = ["Larissa", "Fernanda", "Amanda", "Juliana", "Gabriela", "Camila", "Bruna", "Letícia"];
            const nomeAlvo = nomes[Math.floor(Math.random() * nomes.length)];

            const fotosFeinhas = [
                "https://files.catbox.moe/zps1do.jpg",
                "https://files.catbox.moe/8gtbu2.webp",
                "https://files.catbox.moe/p9avqn.jpg",
                "https://files.catbox.moe/itnqpu.jpg"
            ];

            const fotosBonitas = [
                "https://files.catbox.moe/zz05so.jpg",
                "https://files.catbox.moe/icpz7q.jpg",
                "https://files.catbox.moe/pzkloh.jpg",
                "https://files.catbox.moe/6a64xu.jpg"
            ];

            const frases = [
                "Solteira há 7 anos e sem perspectiva. 💀",
                "O radar pediu desculpa por isso. 😭",
                "Disponível, mas o motivo é óbvio... 👀",
                "Amor é cego, dizem. Confia. 🤡",
                "Personalidade nota 10, confie no processo! 🙏",
                "Dá pro gasto em dia de tédio. 🤷‍♂️",
                "Opa, o radar detectou alguém interessante! ✨",
                "Bonita demais, vai chamar atenção na rua! 👀",
                "Eita, que espetáculo de achado! 🔥",
                "Gata demais, corre antes que outra pessoa encontre! 👑"
            ];

            let comentario = frases[Math.floor(porcentagem / 11)] || frases[frases.length - 1];
            let fotoEscolhida = porcentagem <= 50 
                ? fotosFeinhas[Math.floor(Math.random() * fotosFeinhas.length)]
                : fotosBonitas[Math.floor(Math.random() * fotosBonitas.length)];

            const texto = 
                "╔━᳀『 Yᴜᴋᴀ Rᴀᴅᴀʀ 』═᳀\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "⌬ *Encontrada:* " + nomeAlvo + "\n" +
                "⌬ *Distância:* " + distancia + " km\n" +
                "⌬ *Chegada em:* " + minutos + " min\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                image: { url: fotoEscolhida },
                caption: texto
            }, { quoted: m });

        } catch (error) {
            console.error("[RADAR-COMMAND] Erro:", error.message);
        }
    }
};
