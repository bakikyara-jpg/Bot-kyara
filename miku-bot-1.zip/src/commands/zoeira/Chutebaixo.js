const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "chutebaixo",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica a vítima (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Você precisa marcar o alvo para realizar essa atrocidade!" 
                }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            const dorNivel = Math.floor(Math.random() * 101);

            // Frases de "solidariedade" masculina e zueira
            const frases = [
                "Passou raspando! O vento gelou a alma, mas não quebrou nada. 💨",
                "Pegou de leve. Aquela dorzinha chata que faz a pessoa perder o fôlego por 10 segundos. 🥴",
                "Acerto crítico! A vítima caiu de joelhos e viu o Windows reiniciando. 🌀",
                "ESTALOU! O barulho foi ouvido em três grupos vizinhos. F total. 🥚🔨",
                "LUTO! Um minuto de silêncio pelos herdeiros que nunca nascerão. 💀",
                "EXTINÇÃO TOTAL! A alma saiu do corpo e foi pedir abrigo no céu dos ovos. 👼"
            ];

            let status;
            if (dorNivel <= 15) status = frases[0];
            else if (dorNivel <= 35) status = frases[1];
            else if (dorNivel <= 55) status = frases[2];
            else if (dorNivel <= 75) status = frases[3];
            else if (dorNivel <= 90) status = frases[4];
            else status = frases[5];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Cʀɪᴛɪᴄᴀʟ Hɪᴛ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Nível da Dor:* " + dorNivel + "%\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777554972/trindade-1777554971969.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[CHUTEBAIXO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao processar o golpe." });
        }
    }
};