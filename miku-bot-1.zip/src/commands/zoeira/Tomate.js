const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "tomate",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot barra
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Precisas de marcar ou responder a alguém para lhe atirares um tomate!" 
                }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Medidor de precisão
            const precisao = Math.floor(Math.random() * 101);

            // Frases da zueira
            const frases = [
                "Falhaste miseravelmente e o tomate acertou num poste. 💩",
                "O tomate passou de raspão, só sujou a orelha. 💨",
                "Acertaste na t-shirt! Já parece uma mancha de ketchup. 👕",
                "NA BOCA! Agora já não precisa de jantar, mas o gosto é horrível. 🍅",
                "DIRETO NO OLHO! A vítima ficou cega de um lado por 5 minutos. 👁️",
                "TOMATADA LENDÁRIA! O tomate estava tão podre que o grupo todo começou a vomitar. 🤮"
            ];

            let status;
            if (precisao <= 15) status = frases[0];
            else if (precisao <= 35) status = frases[1];
            else if (precisao <= 55) status = frases[2];
            else if (precisao <= 75) status = frases[3];
            else if (precisao <= 90) status = frases[4];
            else status = frases[5];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Aᴛᴛᴀᴄᴋ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Precisão:* " + precisao + "%\n" +
                "⌬ *Dano:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777555431/trindade-1777555429937.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[TOMATE-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar atirar o tomate." });
        }
    }
};