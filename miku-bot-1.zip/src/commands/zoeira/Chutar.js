const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "chutar",
    aliases: ["chute"],
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica quem vai levar o chute (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot avisa
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Você precisa marcar ou responder a alguém para dar um chute!" 
                }, { quoted: m });
            }

            // Impede de chutar a si mesmo
            if (targetJid === sender) {
                return await sock.sendMessage(from, { text: "❌ Você não pode se chutar... tente marcar outra pessoa!" }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Gera a força do impacto
            const forcaChute = Math.floor(Math.random() * 101);

            // Frases baseadas na força do chute
            let status = "";
            if (forcaChute < 25) status = "Foi só um totó, nem doeu! 🤏";
            else if (forcaChute < 50) status = "Um chute certeiro pra aprender! 🦵";
            else if (forcaChute < 80) status = "Eita! Esse chute deixou a marca do pé. 💢";
            else status = "BIÔNICO! Mandou o alvo pro espaço sem volta. 🚀";

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Cʜᴜᴛᴇ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Força:* " + forcaChute + "%\n" +
                "⌬ *Dano:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777466084/trindade-1777466083871.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[CHUTAR-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar chutar." });
        }
    }
};