const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "petista",
    aliases: ["pt", "petismo"],
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Lista de frases atualizada com o seu pedido
            const frases = [
                "Longe do perigo. Esse aqui ainda come picanha de verdade. 🥩",
                "O sensor nem mexeu, capitalista safado! 💸",
                "Meio em cima do muro, mas não faz o L. 🧱",
                "Já tá começando a olhar pra abóbora com carinho. 🎃",
                "O sensor detectou cheiro de mortadela! 🥖",
                "Foi votar no PT em troca de picanha e recebeu abóbora. 🤡",
                "Já pode começar a caçar largatixa pro jantar! 🦎",
                "Militante de carteirinha, faz o L com força! 🚩",
                "Amante da picanha metafórica e do imposto alto. 📉",
                "100% Petista! O estoque de abóbora e largatixa tá garantido. 🚩🦎"
            ];

            let comentario;
            if (porcentagem <= 10) comentario = frases[0];
            else if (porcentagem <= 20) comentario = frases[1];
            else if (porcentagem <= 30) comentario = frases[2];
            else if (porcentagem <= 40) comentario = frases[3];
            else if (porcentagem <= 50) comentario = frases[4];
            else if (porcentagem <= 60) comentario = frases[5];
            else if (porcentagem <= 70) comentario = frases[6];
            else if (porcentagem <= 80) comentario = frases[7];
            else if (porcentagem <= 90) comentario = frases[8];
            else comentario = frases[9];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Resultado:* " + porcentagem + "% Petista\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777464852/trindade-1777464851306.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[PETISTA-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao processar o scanner." });
        }
    }
};