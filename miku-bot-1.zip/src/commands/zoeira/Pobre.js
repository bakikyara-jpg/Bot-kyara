const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "pobre",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Frases para humilhar por nível de pobreza
            const frases = [
                "Nível herdeiro. O sensor nem detectou cheiro de boleto. 💸",
                "Tem dinheiro pra um lanche, mas se comprar o refri o cartão recusa. 🍔",
                "O CPF tá tão sujo que se você passar na frente do banco o alarme toca. 💳",
                "Já começou a colocar água no shampoo pra render mais uma semana? 🧴",
                "O sensor detectou que você almoça vento e janta esperança. 🌬️",
                "Nível Crítico! O seu cartão de crédito é de papelão e o limite é um abraço. 📦",
                "Miserável detectado! Você tá devendo até pro agiota que ainda nem nasceu. 📉",
                "100% POBREZA EXTREMA! Você é tão pobre que se for assaltado o ladrão te dá uma moeda por pena. 💀"
            ];

            let comentario;
            if (porcentagem <= 10) comentario = frases[0];
            else if (porcentagem <= 25) comentario = frases[1];
            else if (porcentagem <= 40) comentario = frases[2];
            else if (porcentagem <= 55) comentario = frases[3];
            else if (porcentagem <= 70) comentario = frases[4];
            else if (porcentagem <= 85) comentario = frases[5];
            else if (porcentagem <= 99) comentario = frases[6];
            else comentario = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Nível:* " + porcentagem + "% Pobre\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777557086/trindade-1777557085300.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[POBRE-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao escanear a conta bancária do infeliz." });
        }
    }
};