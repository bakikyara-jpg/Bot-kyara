const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "tapa",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica quem vai levar a bofetada (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot barra
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Precisas de marcar ou responder a alguém para lhe dares um tapa!" 
                }, { quoted: m });
            }

            // Impede de se bater a si mesmo
            if (targetJid === sender) {
                return await sock.sendMessage(from, { text: "❌ Queres dar um tapa em ti próprio? Procura ajuda, doido!" }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Medidor de estalo
            const forcaTapa = Math.floor(Math.random() * 101);

            // Frases de impacto (Zueira)
            const frases = [
                "O tapa nem encostou, só serviu para passar vergonha. 💨",
                "Foi um tapinha de amor? Mal deixou a bochecha rosa. 😏",
                "O estalo foi seco! Ficou a marca dos cinco dedos na cara. 🥴",
                "TAPA CRÍTICO! O barulho foi tão alto que acordou os vizinhos. 💥",
                "NA ORELHA! O alvo está a ouvir um apito até agora. 😵‍💫",
                "ESTALO LENDÁRIO! A cabeça do alvo girou 360 graus igual ao Exorcista. 💀"
            ];

            let status;
            if (forcaTapa <= 15) status = frases[0];
            else if (forcaTapa <= 35) status = frases[1];
            else if (forcaTapa <= 55) status = frases[2];
            else if (forcaTapa <= 75) status = frases[3];
            else if (forcaTapa <= 90) status = frases[4];
            else status = frases[5];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Aᴛᴛᴀᴄᴋ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Impacto:* " + forcaTapa + "%\n" +
                "⌬ *Resultado:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777556347/trindade-1777556346534.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[TAPA-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar dar um tapa." });
        }
    }
};