const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "bolsonaro",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelPatriota = Math.floor(Math.random() * 101);

            // Frases focadas na "picanha de verdade" vs "abóbora/mentira"
            const frases = [
                "Nível Crítico! O sensor detectou que você prefere comer abóbora e lagarta. Tá quase usando o .petista! 🚩",
                "Cuidado... o sistema sentiu um cheiro de picanha de papelão. Você tá pendendo pro lado errado. 🤨",
                "Neutro. Nem lá, nem cá. Tá esperando a picanha cair do céu enquanto olha pra abóbora. 🧱",
                "Já começou a entender que patriotismo não combina com mentira. Tá no caminho. 🇧🇷",
                "Nível Patriota! O sensor detectou que você não cai em papo de lagartinha. 🫡",
                "QUASE UM MITO! Você já sabe diferenciar picanha de verdade daquela promessa furada de campanha. 🥩",
                "BRAÇO FORTE! O sistema identificou que aqui a picanha chega sem mentira e o patriotismo é real. 🥛",
                "100% CAPITÃO! O mais correto de todos. Entregou a picanha na mesa sem enganação e sem abóbora! Talkei? 🥩🇧🇷"
            ];

            let status;
            if (nivelPatriota <= 10) status = frases[0];
            else if (nivelPatriota <= 25) status = frases[1];
            else if (nivelPatriota <= 40) status = frases[2];
            else if (nivelPatriota <= 55) status = frases[3];
            else if (nivelPatriota <= 70) status = frases[4];
            else if (nivelPatriota <= 85) status = frases[5];
            else if (nivelPatriota <= 99) status = frases[6];
            else status = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Nível Correto:* " + nivelPatriota + "%\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777560162/trindade-1777560162014.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[BOLSONARO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao medir o nível de patriotismo correto." });
        }
    }
};