const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "virgem",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelCabaço = Math.floor(Math.random() * 101);

            // Frases para esculachar o nível de "pureza" do indivíduo
            const frases = [
                "O sensor detectou alguém que conhece os prazeres da vida. Raro por aqui. ✨",
                "Tem cara de quem já deu um beijo... mas foi no espelho treinando. 🪞",
                "Nível Iniciante. O máximo de contato que teve foi esbarrar em alguém no metrô. 🚆",
                "O sensor detectou que você pede licença até pra entrar no próprio quarto. 🚪",
                "Nível Mago Aprendiz! Se continuar assim, vai ganhar um cajado e uma túnica de brinde. 🧙‍♂️",
                "VIRGEM SUPREMO! Você é tão puro que os anjos descem pra te pedir conselhos de castidade. 👼",
                "Misericórdia! O seu histórico de busca é o único lugar onde você vê ação. F total. 💻💀",
                "100% INTOCÁVEL! O sistema identificou uma aura de proteção permanente. Você vai morrer virgem e levar o segredo pro túmulo! ⚰️🔥"
            ];

            let status;
            if (nivelCabaço <= 10) status = frases[0];
            else if (nivelCabaço <= 25) status = frases[1];
            else if (nivelCabaço <= 40) status = frases[2];
            else if (nivelCabaço <= 55) status = frases[3];
            else if (nivelCabaço <= 70) status = frases[4];
            else if (nivelCabaço <= 85) status = frases[5];
            else if (nivelCabaço <= 99) status = frases[6];
            else status = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Pureza:* " + nivelCabaço + "%\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777559866/trindade-1777559865436.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[VIRGEM-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar medir o nível de cabacismo do alvo." });
        }
    }
};