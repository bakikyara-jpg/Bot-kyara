const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "bafo",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelToxico = Math.floor(Math.random() * 101);

            // Frases pesadas sobre o hálito de esgoto do alvo
            const frases = [
                "O sensor nem apitou. Parece que a higiene bucal está em dia (por milagre). ✨",
                "Um cheiro leve de quem esqueceu de escovar os dentes depois do café. Aceitável. ☕",
                "Já dá para sentir um aroma de cemitério quando abres a boca. Cuidado. ⚰️",
                "Nível bueiro aberto! O cheiro atravessou o ecrã do meu telemóvel agora mesmo. 🤢",
                "O sensor detectou que tu jantas urubu morto e nem passas fio dental. Que nojo! 🦅",
                "ARMA QUÍMICA! Um 'bom dia' teu é capaz de derrubar um batalhão inteiro. ☢️",
                "Misericórdia! O teu hálito é tão forte que as moscas caem mortas antes de chegarem perto. 🪰💀",
                "100% ESGOTO HUMANO! É um crime federal estares no grupo sem uma máscara de gás. O teu bafo derrete aço! 🏥🔥"
            ];

            let comentario;
            if (nivelToxico <= 10) comentario = frases[0];
            else if (nivelToxico <= 25) comentario = frases[1];
            else if (nivelToxico <= 40) comentario = frases[2];
            else if (nivelToxico <= 55) comentario = frases[3];
            else if (nivelToxico <= 70) comentario = frases[4];
            else if (nivelToxico <= 85) comentario = frases[5];
            else if (nivelToxico <= 99) comentario = frases[6];
            else comentario = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Toxicidade:* " + nivelToxico + "%\n" +
                "⌬ *Estado:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777559274/trindade-1777559273535.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[BAFO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar medir o nível de esgoto bucal." });
        }
    }
};