const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "muriçoca",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelZumbido = Math.floor(Math.random() * 101);

            // Frases para humilhar o chato do grupo
            const frases = [
                "Tá silencioso... até estranhei. A bateria dessa muriçoca deve ter acabado. 🔋",
                "Um zumbido leve, dá pra ignorar com um tapa ou um block. 🦟",
                "Já tá começando a irritar. Alguém traz o repelente antes que essa praga comece a picar. 🧴",
                "Nível chato de galocha! Você não fala, você zumba no ouvido da gente até dar dor de cabeça. 🔊",
                "O sensor detectou que sua única função no grupo é sugar a paciência dos outros. 🩸",
                "Muriçoca mutante! Nem veneno de rato mata essa insistência de querer ser o centro das atenções. ☢️",
                "Insuportável! O barulho que você faz é proporcional à falta de utilidade da sua existência aqui. 💀",
                "100% MURIÇOCA SUPREMA! Chamem o fumacê! Esse ser é um surto de chatice ambulante, ninguém aguenta mais! 🏥"
            ];

            let status;
            if (nivelZumbido <= 10) status = frases[0];
            else if (nivelZumbido <= 25) status = frases[1];
            else if (nivelZumbido <= 40) status = frases[2];
            else if (nivelZumbido <= 55) status = frases[3];
            else if (nivelZumbido <= 70) status = frases[4];
            else if (nivelZumbido <= 85) status = frases[5];
            else if (nivelZumbido <= 99) status = frases[6];
            else status = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Zumbido:* " + nivelZumbido + "%\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777558916/trindade-1777558914995.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[MURIÇOCA-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar caçar essa muriçoca." });
        }
    }
};