const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "matar",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você mesmo)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;

            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Alguém";
            const porcentagem = Math.floor(Math.random() * 101);

            // Frases humilhantes - "Fulano matou você de [forma zoada]"
            const frases = [
                "com um simples 'oi' e depois ignorou pra sempre 💀",
                "com um 'ksksksk' depois de você mandar áudio de 2 minutos",
                "olhando pro stories dela com outro e te deixando no vácuo",
                "te tratando como opção B e você ainda agradeceu",
                "te bloqueando logo após você mandar 'bom dia princesa'",
                "te usando de motorista particular e depois sumindo",
                "mandando você comprar iFood e nem te convidando pra comer",
                "te chamando de 'amigo' enquanto você tá apaixonado",
                "dando like nas fotos dela com o novo crush na sua frente",
                "te fazendo de capacho e ainda limpando os pés em você",
                "te ghostando depois de você declarar amor em áudio",
                "com um 'não tô afim de nada agora' depois de meses de papo",
                "te fazendo implorar por atenção como um cachorrinho",
                "te substituindo em menos de 24 horas e postando com o novo",
                "simplesmente existindo e já te destruindo emocionalmente"
            ];

            let comentario = frases[Math.floor(Math.random() * frases.length)];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Mᴀᴛᴀᴅᴏʀᴀ 』═᳀\n" +
                "⌬ *Assassino:* " + nomeSolicitante + "\n" +
                "⌬ *Vítima:* @" + numeroTarget + "\n" +
                "⌬ *Nível de Humilhação:* " + porcentagem + "%\n" +
                "⌬ *Causa da Morte:* Foi morto " + comentario + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀\n\n" +
                "🪦 *Descansa em paz, otário...*";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777557920/trindade-1777557918951.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[MATAR-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao executar o comando matar." });
        }
    }
};