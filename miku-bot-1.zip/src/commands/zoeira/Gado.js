const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "gado",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Frases atualizadas (mais variadas + humilhantes)
            const frases = [
                "Livre de perigo! O coração está blindado e não muge pra ninguém. 🧊",
                "Tem um leve sintoma de 'curtir todos os stories', cuidado hein! 🧐",
                "O sensor detectou que você já respondeu em menos de 1 minuto hoje. 🤔",
                "Já começou a mugir baixinho... a dedicação está aumentando! 🐂",
                "Nível avançado! Já aceitou ser o 'motorista particular' por um sorriso. 🏎️",
                "Gado de respeito! Se a pessoa postar um ponto final, você comenta 'lindo(a)'. ✨",
                "O sistema identificou um coração de ouro que faz tudo por um @. 🎀",
                
                // Frases HUMILHANTES novas:
                "Gado nível hard! Já paga iFood pra crush mesmo sabendo que ela tá com outro. 🍔😂",
                "Mano... você é o tipo que manda 'bom dia' e recebe 'ksksksk' como resposta. 💀",
                "100% capacho certificado. Limpa o histórico toda vez que ela vai aparecer. 🧹",
                "Esse aí já virou tapete humano. Ela pisa e ele ainda agradece. 🐑",
                "Gado supremo! Já salvou o nome dela como '❤️ Minha Rainha 👑' no celular. 🤡",
                "Detectado: fornecedor oficial de atenção gratuita 24h. Sem salário, só humilhação. 😭",
                "Você não é mais homem... é modo 'entrega grátis' ativado permanentemente. 📦",
                "Já implorou 'me dá uma chance' com voz tremendo? O scanner diz que sim. 🥲",
                "Nível master: ela te trata como opção B e você ainda fica feliz. Patético. 😂",
                "Esse gado aqui já comprou presente sem nem ser aniversário dela. Tristeza pura. 🎁",
                "Muge mais que boi no pasto. Até a vaca vizinha tem vergonha alheia. 🐄",
                "Gado nível Deus: ela bloqueia, desbloqueia, some, volta... e ele continua lá. 🛐"
            ];

            let comentario;
            if (porcentagem <= 8) comentario = frases[0];
            else if (porcentagem <= 20) comentario = frases[1];
            else if (porcentagem <= 35) comentario = frases[2];
            else if (porcentagem <= 50) comentario = frases[3];
            else if (porcentagem <= 65) comentario = frases[4];
            else if (porcentagem <= 78) comentario = frases[5];
            else if (porcentagem <= 88) comentario = frases[6];
            else if (porcentagem <= 94) comentario = frases[Math.floor(Math.random() * 5) + 7]; // humilhantes leves
            else comentario = frases[Math.floor(Math.random() * (frases.length - 7)) + 7]; // humilhantes pesadas

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Nível:* " + porcentagem + "% Gado\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777557428/trindade-1777557427283.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[GADO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao escanear o berrante do alvo." });
        }
    }
};