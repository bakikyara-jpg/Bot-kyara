const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "sonhos",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Frases de "realidade" cruel
            const frases = [
                "A vida teve pena. Hoje os teus sonhos estão salvos (por enquanto). 🌈",
                "Só uma pequena rasteira, nada que um choro no banho não resolva. 💧",
                "O destino deu um soco nos teus planos. Vai doer amanhã. 🥊",
                "O sensor detectou que tu já nem tinhas sonhos, então tá de boa. 🤡",
                "A vida atropelou as tuas metas e nem parou pra prestar socorro. 🏎️",
                "A realidade deu um fatality nos teus sonhos. F total. 💀",
                "100% DESTRUIDO! A vida não só levou os teus sonhos, como deixou a conta pra tu pagares. 💸"
            ];

            let comentario;
            if (porcentagem <= 15) comentario = frases[0];
            else if (porcentagem <= 35) comentario = frases[1];
            else if (porcentagem <= 55) comentario = frases[2];
            else if (porcentagem <= 75) comentario = frases[3];
            else if (porcentagem <= 90) comentario = frases[4];
            else if (porcentagem < 100) comentario = frases[5];
            else comentario = frases[6];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Rᴇᴀʟɪᴅᴀᴅᴇ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Risco:* " + porcentagem + "%\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777556119/trindade-1777556117709.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[SONHOS-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao processar o destruidor de sonhos." });
        }
    }
};