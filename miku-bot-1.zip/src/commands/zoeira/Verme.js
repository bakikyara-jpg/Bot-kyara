const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "verme",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelInsignificancia = Math.floor(Math.random() * 101);

            // Frases para humilhar o verme do grupo
            const frases = [
                "O sensor nem detectou. Você é tão insignificante que até os parasitas te ignoram. 🧬",
                "Nível rastejante. Você só serve para ocupar espaço e gastar o oxigênio alheio. 🐛",
                "Já começou a se rastejar? O sensor detectou que sua utilidade aqui é zero. 🕳️",
                "Nível Parasita! Você não agrega nada, só suga a energia e a paciência de quem trabalha. 🦟",
                "O sensor detectou um organismo que vive de restos. Literalmente um peso morto na Terra. 🧟",
                "VERME NOJENTO! Se você sumisse hoje, o grupo ganharia 50 pontos de QI instantaneamente. 🤮",
                "Misericórdia! Você é tão baixo que precisa olhar pra cima pra ver o chão. Um verdadeiro lixo biológico. 🗑️",
                "100% VERME SUPREMO! O sistema sugere incineração imediata. Você é a prova de que a evolução às vezes falha feio. 💀🔥"
            ];

            let status;
            if (nivelInsignificancia <= 10) status = frases[0];
            else if (nivelInsignificancia <= 25) status = frases[1];
            else if (nivelInsignificancia <= 40) status = frases[2];
            else if (nivelInsignificancia <= 55) status = frases[3];
            else if (nivelInsignificancia <= 70) status = frases[4];
            else if (nivelInsignificancia <= 85) status = frases[5];
            else if (nivelInsignificancia <= 99) status = frases[6];
            else status = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Insignificância:* " + nivelInsignificancia + "%\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                image: { url: "https://res.cloudinary.com/dlmoujcpv/image/upload/v1777559452/trindade-1777559451875.jpg" },
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[VERME-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar analisar esse parasita." });
        }
    }
};