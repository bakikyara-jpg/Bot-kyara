const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "burro",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Frases para esculachar o QI do indivíduo
            const frases = [
                "O cérebro deu sinal de vida. Um milagre da medicina. 🧠✨",
                "Consegue amarrar os sapatos sem ajuda, mas não lhe peças para contar até dez. 👟",
                "O sensor detectou que tu tentas empurrar portas que dizem 'Puxe'. 🚪",
                "Nível perigoso! Se a tua burrice fosse energia, iluminavas uma cidade inteira. 💡",
                "Tu és o tipo de pessoa que olha para o lado antes de atravessar uma rua de sentido único e ainda é atropelada. 🚗",
                "QI de uma ameba em coma. O teu cérebro é só um peso de papel dentro do crânio. 🧬",
                "Misericórdia! Tu és tão burro que se fosses num concurso de burros, ficavas em segundo porque és demasiado burro para ganhar. 🥈",
                "100% ASNO! O sistema entrou em colapso. Tu não tens um cérebro, tens uma ervilha a saltar dentro de uma lata vazia. 💀"
            ];

            let comentario;
            if (porcentagem <= 10) comentario = frases[0];
            else if (porcentagem <= 25) comentario = frases[1];
            else if (porcentagem <= 40) comentario = frases[2];
            else if (porcentagem <= 55) comentario = frases[3];
            else if (porcentagem <= 70) comentario = frases[4];
            else if (porcentagem <= 85) comentario = frases[5];
            else if (porcentagem <= 99) comentario = frases[6];
            else comentario = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Burrice:* " + porcentagem + "%\n" +
                "⌬ *Diagnóstico:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777558367/trindade-1777558366019.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[BURRO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar medir o vácuo cerebral do alvo." });
        }
    }
};