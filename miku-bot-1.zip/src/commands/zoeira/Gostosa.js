const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "gostosa",
    aliases: ["gostoso", "beleza", "nivel"],
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Lista de frases para o Gostosômetro
            const frases = [
                "O sensor quebrou de tão feio(a). 🔥",
                "Beleza interior é o que importa, né? 🤡",
                "Dá pro gasto em dia de chuva. ☔",
                "O sensor detectou uma pessoa comum. 😐",
                "Olha, tem o seu charme... 🤔",
                "Opa, a beleza está florescendo! ✨",
                "Bonito(a) demais, chamou atenção! 👀",
                "Eita, que espetáculo de pessoa! 🔥",
                "Perfeição em forma de gente. 💎",
                "100% DEUSA(O)! O sistema entrou em colapso. 👑"
            ];

            let comentario;
            if (porcentagem <= 10) comentario = frases[0];
            else if (porcentagem <= 20) comentario = frases[1];
            else if (porcentagem <= 30) comentario = frases[2];
            else if (porcentagem <= 40) comentario = frases[3];
            else if (porcentagem <= 50) comentario = frases[4];
            else if (porcentagem <= 60) comentario = frases[5];
            else if (porcentagem <= 70) comentario = frases[6];
            else if (porcentagem <= 80) comentario = frases[7];
            else if (porcentagem <= 90) comentario = frases[8];
            else comentario = frases[9];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Resultado:* " + porcentagem + "%\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777466364/trindade-1777466363519.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[GOSTOSA-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao processar o scanner." });
        }
    }
};