const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "comunista",

    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const porcentagem = Math.floor(Math.random() * 101);

            // Lista de frases para o Comunômetro
            const frases = [
                "Capitalista safado. 💸",
                "Fã do Elon Musk detectado. 🚀",
                "Tem cara de quem gosta de juros altos. 📈",
                "O sensor nem balançou, camarada. ❄️",
                "Já começou a dividir o lanche? 🥪",
                "Lendo o manifesto em segredo... 📖",
                "Socialista de iPhone? 🤔",
                "Nossa porcentagem, camarada! 🛠️",
                "O hino da URSS começou a tocar ao fundo. 🎼",
                "100% Camarada! A propriedade agora é NOSSA. ☭"
            ];

            let comentario;
            if (porcentagem <= 10) comentario = frases[0];
            else if (porcentagem <= 20) comentario = frases[1];
            else if (porcentagem <= 30) comentario = frases[2];
            else if (porcentagem <= 40) comentario = frases[3];
            else if (porcentagem <= 50) comentario = frases[4];
            else if (porcentagem <= 60) comentario = frases[5];
            else if (porcentagem <= 70) comentario = frases[6];
            else if (porcentagem <= 80) comentario = frases[7];
            else if (porcentagem <= 90) comentario = frases[8];
            else comentario = frases[9];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Resultado:* " + porcentagem + "% Comunista\n" +
                "⌬ *Status:* " + comentario + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777464732/trindade-1777464730591.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[COMUNISTA-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao processar o scanner." });
        }
    }
};