const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "beijar",
    aliases: ["beijo", "kiss"],
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot avisa
            if (!targetJid) {
                return await sock.sendMessage(from, { text: "❌ Você precisa marcar ou responder alguém para dar um beijo!" }, { quoted: m });
            }

            // Impede de beijar a si mesmo (opcional, mas faz sentido)
            if (targetJid === sender) {
                return await sock.sendMessage(from, { text: "❌ Você não pode beijar a si mesmo... ou pode? Melhor marcar outra pessoa." }, { quoted: m });
            }
            
            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            const porcentagemTapa = Math.floor(Math.random() * 101);

            // Frases baseadas na chance de levar um tapa
            let status = "";
            if (porcentagemTapa < 20) status = "Beijo correspondido! Rolou um clima. ✨";
            else if (porcentagemTapa < 50) status = "Aceitou, mas ficou com vergonha. 😊";
            else if (porcentagemTapa < 80) status = "O tapa estalou, mas foi com carinho? 👋";
            else status = "CORRE! O tapa foi tão forte que virou a cara. 💀";

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Bᴇɪᴊᴏ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Risco de Tapa:* " + porcentagemTapa + "%\n" +
                "⌬ *Resultado:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777465354/trindade-1777465353691.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[BEIJAR-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar beijar." });
        }
    }
};