const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "abraçar",
    aliases: ["abraco", "hug"],
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica quem vai receber o abraço (Menção ou Resposta)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted;

            // Se não marcar ninguém, o bot avisa
            if (!targetJid) {
                return await sock.sendMessage(from, { 
                    text: "❌ Você precisa marcar ou responder a alguém para dar um abraço!" 
                }, { quoted: m });
            }

            const numeroTarget = extractNumber(targetJid);
            const numeroSender = extractNumber(sender);
            
            // Gera um nível de carinho aleatório
            const nivelCarinho = Math.floor(Math.random() * 101);

            // Frases baseadas no nível de carinho
            let status = "";
            if (nivelCarinho < 30) status = "Um abraço rápido e meio sem jeito. 😶";
            else if (nivelCarinho < 60) status = "Um abraço amigável e fofinho. 😊";
            else if (nivelCarinho < 90) status = "Aquele abraço apertado que estala as costas! ✨";
            else status = "Um abraço lendário! Não queriam mais soltar. ❤️";

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Aʙʀᴀçᴏ 』═᳀\n" +
                "⌬ *De:* @" + numeroSender + "\n" +
                "⌬ *Para:* @" + numeroTarget + "\n" +
                "⌬ *Carinho:* " + nivelCarinho + "%\n" +
                "⌬ *Nota:* " + status + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777465509/trindade-1777465508532.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [sender, targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[ABRACAR-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar abraçar." });
        }
    }
};