const path = require("path");
const { extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));

module.exports = {
    name: "corno",
    async execute(sock, m, options) {
        const { from, sender } = options;

        try {
            // Identifica o alvo (Menção > Resposta > Você)
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
            const targetJid = mentioned || quoted || sender;
            
            const numeroTarget = extractNumber(targetJid);
            const nomeSolicitante = m.pushName || "Usuário";
            const nivelChifre = Math.floor(Math.random() * 101);

            // Frases pesadas para o corno do grupo
            const frases = [
                "O sensor está limpo. Ou você é solteiro ou o Ricardão é muito discreto. 😇",
                "Tem um calo crescendo na testa... nada preocupante ainda. 🧐",
                "Já começou a sentir o peso? O sensor detectou uma leve inclinação pra frente. 🐂",
                "Nível Touro Bandido! Você já nem consegue mais entrar no carro sem abrir o teto solar. 🏎️",
                "O sensor detectou que sua casa é o único lugar do mundo onde o Wi-Fi pega no chifre. 📶",
                "CORNO MANSO! Você já aceitou que 'ele é só um amigo' e até paga a cerveja pra ele. 🍺🤡",
                "Misericórdia! Se o chifre fosse ouro, você seria o homem mais rico do mundo. 💰🤘",
                "100% CORNO SUPREMO! O sensor derreteu! Seu chifre é tão grande que dá sinal de rádio pirata e serve de varal. 📡💀"
            ];

            let status;
            if (nivelChifre <= 10) status = frases[0];
            else if (nivelChifre <= 25) status = frases[1];
            else if (nivelChifre <= 40) status = frases[2];
            else if (nivelChifre <= 55) status = frases[3];
            else if (nivelChifre <= 70) status = frases[4];
            else if (nivelChifre <= 85) status = frases[5];
            else if (nivelChifre <= 99) status = frases[6];
            else status = frases[7];

            const texto = 
                "╔━᳀『 Mɪᴋᴜ Sᴄᴀɴɴᴇʀ 』═᳀\n" +
                "⌬ *Alvo:* @" + numeroTarget + "\n" +
                "⌬ *Nível:* " + nivelChifre + "% Corno\n" +
                "⌬ *Diagnóstico:* " + status + "\n" +
                "⌬ *Solicitante:* " + nomeSolicitante + "\n" +
                "╚═━═━═━═━═━═━═━═━═᳀";

            await sock.sendMessage(from, {
                video: { url: "https://res.cloudinary.com/dlmoujcpv/video/upload/v1777559562/trindade-1777559561520.mp4" },
                gifPlayback: true,
                caption: texto,
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("[CORNO-COMMAND] Erro:", error.message);
            await sock.sendMessage(from, { text: "❌ Erro ao tentar medir a antena desse infeliz." });
        }
    }
};