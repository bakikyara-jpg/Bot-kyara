const path = require("path");
const { isUserAdmin, isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: "gp-f",
    aliases: ["fecharrgrupo", "fecharGrupo"],
    async execute(sock, m, options) {
        const { from, sender, config } = options;

        if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono ou admins podem usar este comando.']) }, { quoted: m });
                return;
            }

            await sock.sendMessage(from, { text: box('🚪 Fechando Grupo', ['Aguarde, o grupo está sendo travado...']) }, { quoted: m });

            await sock.groupSettingUpdate(from, 'announcement');

            await sock.sendMessage(from, { text: box('🔒 Grupo Fechado', ['Somente admins podem enviar mensagens agora.']) }, { quoted: m });

        } catch (error) {
            console.error('Erro ao fechar grupo:', error.message);
            await sock.sendMessage(from, { text: erro('Falha ao Fechar', ['Não consegui fechar o grupo.']) }, { quoted: m });
        }
    },
};
