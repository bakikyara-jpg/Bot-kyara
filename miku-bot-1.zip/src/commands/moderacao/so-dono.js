const path = require('path');
const { isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const { isSoDonoAtivo, ativarSoDono, desativarSoDono } = require(path.join(__dirname, '..', '..', 'lib', 'so-dono-state', 'so-dono-state.js'));

module.exports = {
    name: 'so-dono',
    aliases: ['sodono', 'onlydono', 'only-dono'],

    async execute(sock, m, options) {
        const { from, sender, config } = options;

        if (!from.endsWith('@g.us')) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
        if (!senderIsDono) {
            await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono do bot pode usar este comando.']) }, { quoted: m });
            return;
        }

        try {
            const ativo = isSoDonoAtivo(from);

            if (ativo) {
                desativarSoDono(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Dono Desativado', ['Todos podem usar os comandos do bot novamente neste grupo.']) }, { quoted: m });
            } else {
                ativarSoDono(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Dono Ativado', ['O bot vai responder apenas ao dono do bot neste grupo.']) }, { quoted: m });
            }

        } catch (error) {
            console.error('[SO-DONO] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao executar o comando so-dono.']) }, { quoted: m });
        }
    }
};
