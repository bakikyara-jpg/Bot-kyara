const path = require("path");
const { isUserAdmin, isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: "ban",
    aliases: [],
    async execute(sock, m, options) {
        const { from, sender, args, config } = options;

        if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas um administrador do grupo ou o dono do bot pode usar este comando.']) }, { quoted: m });
                return;
            }

            const botIsAdmin = await isUserAdmin(sock.user.id, groupMetadata, sock);
            if (!botIsAdmin) {
                await sock.sendMessage(from, { text: erro('Cadê Meu Cargo?', ['Eu não sou administrador deste grupo — me promova para usar esse comando.']) }, { quoted: m });
                return;
            }

            const contextInfo = m.message?.extendedTextMessage?.contextInfo;

            let targetJid = null;
            if (contextInfo?.mentionedJid?.length > 0) {
                targetJid = contextInfo.mentionedJid[0];
            } else if (contextInfo?.quotedMessage && contextInfo?.participant) {
                targetJid = contextInfo.participant;
            } else if (args[0]) {
                const numberArg = args[0].replace(/[^0-9]/g, "");
                targetJid = numberArg + "@s.whatsapp.net";
            }

            if (!targetJid) {
                await sock.sendMessage(from, { text: erro('Alvo Não Identificado', ['Mencione alguém, responda a mensagem da pessoa ou forneça um número.']) }, { quoted: m });
                return;
            }

            const targetName = targetJid.split('@')[0];

            await sock.sendMessage(from, {
                text: box('🏹 Alvo Encontrado', [`Removendo @${targetName} do grupo...`]),
                mentions: [targetJid]
            }, { quoted: m });

            await sock.groupParticipantsUpdate(from, [targetJid], "remove");

            await sock.sendMessage(from, {
                text: box('🔥 Alvo Removido', [`@${targetName} foi banido deste grupo com sucesso.`]),
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error("Erro ban:", error.message);
            await sock.sendMessage(from, { text: erro('Falha ao Banir', ['Não consegui remover essa pessoa do grupo.']) }, { quoted: m });
        }
    },
};
