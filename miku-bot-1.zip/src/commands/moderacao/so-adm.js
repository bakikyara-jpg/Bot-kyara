const path = require('path');
const { isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const {
    isSoAdmAtivo,
    ativarSoAdm,
    desativarSoAdm
} = require(path.join(__dirname, '..', '..', 'lib', 'so-adm-state', 'so-adm-state.js'));

module.exports = {
    name: 'so-adm',
    aliases: ['soadm', 'onlyadm'],

    async execute(sock, m, options) {
        const { from, sender, config } = options;

        if (!from.endsWith('@g.us')) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        try {
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);

            if (!senderIsDono) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono do bot pode usar este comando.']) }, { quoted: m });
                return;
            }

            const grupoAtivo = isSoAdmAtivo(from);

            if (grupoAtivo) {
                desativarSoAdm(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Adm Desativado', ['Todos os membros podem usar os comandos do bot novamente neste grupo.']) }, { quoted: m });
            } else {
                ativarSoAdm(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Adm Ativado', ['O bot vai responder apenas admins e o dono do bot neste grupo.']) }, { quoted: m });
            }

        } catch (error) {
            console.error('Erro so-adm:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao executar o comando so-adm.']) }, { quoted: m });
        }
    },
};
