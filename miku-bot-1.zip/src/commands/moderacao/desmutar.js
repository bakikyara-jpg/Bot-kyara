const path = require('path');
const { isUserAdmin, isOwner, extractNumber } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const { desmutar, isMutado } = require(path.join(__dirname, '..', '..', 'lib', 'mute-state', 'mute-state.js'));

module.exports = {
    name: 'desmutar',
    aliases: ['unmute'],
    description: 'Remove o mute de um membro no grupo',

    async execute(sock, m, options) {
        const { from, sender, args, config } = options;

        if (!from.endsWith('@g.us')) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas um administrador do grupo ou o dono do bot pode usar este comando.']) }, { quoted: m });
                return;
            }

            const contextInfo = m.message?.extendedTextMessage?.contextInfo;
            let targetJid = contextInfo?.mentionedJid?.[0] || contextInfo?.participant;
            if (!targetJid && args[0]) targetJid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';

            if (!targetJid) {
                await sock.sendMessage(from, { text: erro('Alvo Não Identificado', ['Mencione alguém ou responda a mensagem da pessoa que você quer desmutar.']) }, { quoted: m });
                return;
            }

            if (!isMutado(from, targetJid)) {
                await sock.sendMessage(from, { text: box('🔊 Não Está Mutado', [`@${extractNumber(targetJid)} não está mutado neste grupo.`]), mentions: [targetJid] }, { quoted: m });
                return;
            }

            desmutar(from, targetJid);
            await sock.sendMessage(from, {
                text: box('🔊 Membro Desmutado', [`@${extractNumber(targetJid)} pode enviar mensagens normalmente de novo.`]),
                mentions: [targetJid]
            }, { quoted: m });

        } catch (error) {
            console.error('[DESMUTAR] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao tentar desmutar esse membro.']) }, { quoted: m });
        }
    }
};
