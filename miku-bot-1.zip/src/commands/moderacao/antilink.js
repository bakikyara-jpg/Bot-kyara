// src/commands/moderacao/antilink.js
// Liga/desliga o anti-link do grupo. A checagem/remoção das mensagens
// com link acontece no index.js, em cada mensagem recebida.
const path = require('path');
const { isUserAdmin, isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const {
    isAntilinkAtivo,
    ativarAntilink,
    desativarAntilink
} = require(path.join(__dirname, '..', '..', 'lib', 'antilink-state', 'antilink-state.js'));

module.exports = {
    name: 'antilink',
    aliases: ['anti-link'],
    description: 'Ativa/desativa a remoção automática de links no grupo',
    usage: 'antilink on|off',

    async execute(sock, m, options) {
        const { from, sender, args, config } = options;

        if (!from.endsWith('@g.us')) {
            return sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                return sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono ou admins podem usar este comando.']) }, { quoted: m });
            }

            const opcao = (args[0] || '').toLowerCase();
            const ativoAtual = isAntilinkAtivo(from);

            if (!opcao) {
                return sock.sendMessage(from, {
                    text: box('🔗 Anti-Link', [
                        `Status atual: *${ativoAtual ? 'Ativado ✅' : 'Desativado ❌'}*`,
                        `Use: *${options.prefix}antilink on* ou *${options.prefix}antilink off*`,
                        'Admins e o dono do bot nunca são afetados.'
                    ])
                }, { quoted: m });
            }

            if (opcao === 'on' || opcao === 'ativar' || opcao === 'ligar') {
                ativarAntilink(from);
                return sock.sendMessage(from, { text: box('🔗 Anti-Link Ativado', ['Mensagens com link de grupo/convite serão apagadas automaticamente.', 'Após 3 avisos, o membro é removido do grupo.']) }, { quoted: m });
            }

            if (opcao === 'off' || opcao === 'desativar' || opcao === 'desligar') {
                desativarAntilink(from);
                return sock.sendMessage(from, { text: box('🔗 Anti-Link Desativado', ['Links não serão mais removidos automaticamente.']) }, { quoted: m });
            }

            return sock.sendMessage(from, { text: erro('Opção Inválida', [`Use: *${options.prefix}antilink on* ou *${options.prefix}antilink off*`]) }, { quoted: m });

        } catch (error) {
            console.error('[ANTILINK] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao configurar o anti-link.']) }, { quoted: m });
        }
    }
};
