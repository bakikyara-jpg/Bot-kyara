const path = require('path');
const { isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const {
    isSoMembroAtivo,
    ativarSoMembro,
    desativarSoMembro
} = require(path.join(__dirname, '..', '..', 'lib', 'so-membro-state', 'so-membro-state.js'));

module.exports = {
    name: 'so-membro',
    aliases: ['somembro', 'onlymembro', 'only-membro'],

    async execute(sock, m, options) {
        const { from, sender, config } = options;

        if (!from.endsWith('@g.us')) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
        if (!senderIsDono) {
            await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono do bot pode usar este comando.']) }, { quoted: m });
            return;
        }

        try {
            const ativo = isSoMembroAtivo(from);

            if (ativo) {
                desativarSoMembro(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Membro Desativado', ['Todos podem usar os comandos do bot novamente neste grupo.']) }, { quoted: m });
            } else {
                ativarSoMembro(from);
                await sock.sendMessage(from, { text: box('⚔️ Só-Membro Ativado', ['O bot vai responder apenas membros do grupo e o dono do bot.']) }, { quoted: m });
            }

        } catch (error) {
            console.error('[SO-MEMBRO] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao executar o comando so-membro.']) }, { quoted: m });
        }
    }
};
