const path = require('path');
const { isUserAdmin, isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito, aviso } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const { bloquear, isBloqueado } = require(path.join(__dirname, '..', '..', 'lib', 'blockcmd-state', 'blockcmd-state.js'));

module.exports = {
    name: 'blockcmd',
    aliases: ['bloquearcmd'],
    description: 'Bloqueia um comando específico dentro do grupo',
    usage: 'blockcmd <nome do comando>',

    async execute(sock, m, options) {
        const { from, sender, args, config, prefixoAtual } = options;

        if (!from.endsWith('@g.us')) {
            await sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
            return;
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas um administrador do grupo ou o dono do bot pode usar este comando.']) }, { quoted: m });
                return;
            }

            const alvo = (args[0] || '').toLowerCase();
            if (!alvo) {
                await sock.sendMessage(from, { text: aviso('Falta o Comando', [`Exemplo: *${prefixoAtual}blockcmd play*`]) }, { quoted: m });
                return;
            }

            if (alvo === 'blockcmd' || alvo === 'unblockcmd') {
                await sock.sendMessage(from, { text: erro('Não Permitido', ['Você não pode bloquear os comandos de bloqueio.']) }, { quoted: m });
                return;
            }

            if (isBloqueado(from, alvo)) {
                await sock.sendMessage(from, { text: box('🚫 Já Bloqueado', [`O comando *${alvo}* já está bloqueado neste grupo.`]) }, { quoted: m });
                return;
            }

            bloquear(from, alvo);
            await sock.sendMessage(from, { text: box('🚫 Comando Bloqueado', [`O comando *${alvo}* foi bloqueado neste grupo.`]) }, { quoted: m });

        } catch (error) {
            console.error('[BLOCKCMD] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao bloquear esse comando.']) }, { quoted: m });
        }
    }
};
