// src/commands/moderacao/bemvindo2.js
// Liga/desliga o bem-vindo em IMAGEM quando alguém entra no grupo.
// Independente do .bemvindo (vídeo) — pode ligar os dois juntos.
const path = require('path');
const { isUserAdmin, isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
const {
    isWelcome2Ativo,
    ativarWelcome2,
    desativarWelcome2
} = require(path.join(__dirname, '..', '..', 'lib', 'welcome2-state', 'welcome2-state.js'));

module.exports = {
    name: 'bemvindo2',
    aliases: ['welcome2', 'boasvindas2'],
    description: 'Ativa/desativa a imagem de bem-vindo para novos membros',
    usage: 'bemvindo2 on|off',

    async execute(sock, m, options) {
        const { from, sender, args, config } = options;

        if (!from.endsWith('@g.us')) {
            return sock.sendMessage(from, { text: erro('Somente em Grupos', ['Este comando só pode ser usado dentro de um grupo.']) }, { quoted: m });
        }

        try {
            const groupMetadata = await sock.groupMetadata(from);
            const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            const senderIsAdmin = await isUserAdmin(sender, groupMetadata, sock);

            if (!senderIsDono && !senderIsAdmin) {
                return sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono ou admins podem usar este comando.']) }, { quoted: m });
            }

            const opcao = (args[0] || '').toLowerCase();
            const ativoAtual = isWelcome2Ativo(from);

            if (!opcao) {
                return sock.sendMessage(from, {
                    text: box('🖼️ Bem-Vindo (Imagem)', [
                        `Status atual: *${ativoAtual ? 'Ativado ✅' : 'Desativado ❌'}*`,
                        `Use: *${options.prefix}bemvindo2 on* ou *${options.prefix}bemvindo2 off*`
                    ])
                }, { quoted: m });
            }

            if (opcao === 'on' || opcao === 'ativar' || opcao === 'ligar') {
                ativarWelcome2(from);
                return sock.sendMessage(from, { text: box('🖼️ Bem-Vindo Ativado', ['Novos membros vão receber uma imagem de boas-vindas neste grupo.']) }, { quoted: m });
            }

            if (opcao === 'off' || opcao === 'desativar' || opcao === 'desligar') {
                desativarWelcome2(from);
                return sock.sendMessage(from, { text: box('🖼️ Bem-Vindo Desativado', ['Novos membros não vão mais receber a imagem de boas-vindas.']) }, { quoted: m });
            }

            return sock.sendMessage(from, { text: erro('Opção Inválida', [`Use: *${options.prefix}bemvindo2 on* ou *${options.prefix}bemvindo2 off*`]) }, { quoted: m });

        } catch (error) {
            console.error('[BEMVINDO2] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha no Comando', ['Erro ao configurar o bem-vindo.']) }, { quoted: m });
        }
    }
};
