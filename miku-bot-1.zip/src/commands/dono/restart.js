const path = require('path');
const { isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'restart',
    aliases: ['reiniciar'],
    description: 'Reinicia o processo do bot (o painel/host reconecta automaticamente)',

    async execute(sock, m, options) {
        const { from, sender, config } = options;

        const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
        if (!senderIsDono) {
            await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono do bot pode reiniciar o processo.']) }, { quoted: m });
            return;
        }

        await sock.sendMessage(from, {
            text: box('🔄 Reiniciando', ['O bot vai reiniciar agora, aguarde alguns segundos e volte a usar os comandos.'])
        }, { quoted: m });

        setTimeout(() => process.exit(0), 1200);
    }
};
