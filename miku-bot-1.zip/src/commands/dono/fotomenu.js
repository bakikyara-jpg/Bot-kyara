const path = require('path');
const { config, saveConfig } = require(path.join(__dirname, '..', '..', '..', 'settings', 'config.js'));
const { isOwner } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, restrito, aviso } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'fotomenu',
    aliases: ['setbanner', 'setmenuimg'],
    description: 'Troca a imagem do banner do menu (responda uma imagem ou mande um link)',
    usage: 'fotomenu <link> (ou responda uma imagem com o comando)',

    async execute(sock, m, options) {
        const { from, sender, args } = options;

        const senderIsDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
        if (!senderIsDono) {
            await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Apenas o dono do bot pode trocar a imagem do menu.']) }, { quoted: m });
            return;
        }

        try {
            const quotedImage = m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            const directImage = m.message?.imageMessage;
            const linkArg = args[0];

            if (linkArg && /^https?:\/\//i.test(linkArg)) {
                config.imgBanner = linkArg;
                saveConfig();
                await sock.sendMessage(from, { text: box('🖼️ Banner Atualizado', ['A imagem do menu foi trocada com sucesso pelo link enviado.']) }, { quoted: m });
                return;
            }

            if (quotedImage || directImage) {
                const target = quotedImage || directImage;
                const stream = await sock.downloadMediaMessage
                    ? await sock.downloadMediaMessage({ message: { imageMessage: target } })
                    : null;

                if (!stream) {
                    await sock.sendMessage(from, { text: erro('Sem Suporte', ['Essa versão da lib não conseguiu baixar a imagem. Envie um link direto de imagem em vez disso.']) }, { quoted: m });
                    return;
                }

                const fs = require('fs');
                const pathImg = path.join(__dirname, '..', '..', '..', 'settings', 'menu-banner.jpg');
                fs.writeFileSync(pathImg, stream);
                config.imgBanner = pathImg;
                saveConfig();

                await sock.sendMessage(from, { text: box('🖼️ Banner Atualizado', ['A imagem do menu foi trocada com sucesso pela imagem enviada.']) }, { quoted: m });
                return;
            }

            await sock.sendMessage(from, { text: aviso('Faltou a Imagem', ['Responda uma imagem com este comando ou envie um link direto: *fotomenu https://.../imagem.jpg*']) }, { quoted: m });

        } catch (error) {
            console.error('[FOTOMENU] Erro:', error.message);
            await sock.sendMessage(from, { text: erro('Falha ao Trocar', ['Não consegui atualizar a imagem do menu.']) }, { quoted: m });
        }
    }
};
