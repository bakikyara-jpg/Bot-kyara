const path = require("path");
const { config, saveConfig } = require(path.join(__dirname, '..', '..', '..', 'settings', 'config.js'));
const { isOwner, isUserAdmin } = require(path.join(__dirname, '..', '..', 'utils.js'));
const { box, erro, aviso, restrito } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: "setprefix",
    aliases: [],
    async execute(sock, m, options) {
        const { from, sender, args, prefixoAtual } = options;

        try {
            const isDono = await isOwner(sender, config.ownerNumber, sock, config.ownerLid);
            if (!isDono) {
                await sock.sendMessage(from, { text: restrito('Acesso Restrito', ['Este comando só pode ser usado pelo dono do bot.']) }, { quoted: m });
                return;
            }

            if (!args[0]) {
                await sock.sendMessage(from, { text: aviso('Faltou o Prefixo', [`Exemplo: *${prefixoAtual}setprefix !*`]) }, { quoted: m });
                return;
            }

            const novoPrefixo = args[0];

            if (novoPrefixo.length > 1) {
                await sock.sendMessage(from, { text: erro('Prefixo Inválido', ['O prefixo deve conter apenas 1 caractere.', `Exemplo: *${prefixoAtual}setprefix #*`]) }, { quoted: m });
                return;
            }

            await sock.sendMessage(from, { text: box('👑 Alterando Prefixo', ['Aguarde um instante...']) }, { quoted: m });

            await new Promise(resolve => setTimeout(resolve, 1200));

            config.prefix = novoPrefixo;
            saveConfig();

            await sock.sendMessage(from, {
                text: box('✅ Prefixo Alterado', [
                    `Novo prefixo: *${novoPrefixo}*`,
                    `Use *${novoPrefixo}menu* para ver os comandos disponíveis.`,
                ])
            }, { quoted: m });

        } catch (error) {
            console.error('Erro setprefix:', error.message);
            await sock.sendMessage(from, { text: erro('Falha ao Alterar', ['Não consegui trocar o prefixo do bot.']) }, { quoted: m });
        }
    },
};
