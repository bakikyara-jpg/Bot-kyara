// src/commands/tools/upscale.js
// Melhora a qualidade de uma imagem usando IA (vyro.ai)
// Adaptado pro padrão do bot: module.exports + execute(sock, m, options)

const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { aviso, erro, sucesso } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'upscale',
    aliases: ['hd', 'remini'],
    description: 'Melhora a qualidade de uma imagem usando IA',
    usage: 'upscale (marque ou envie uma imagem)',

    async execute(sock, m, options) {
        const from = m.key.remoteJid;
        const prefix = options?.prefix || '.';

        try {
            const imagemBuffer = await baixarImagem(sock, m);
            if (!imagemBuffer) {
                return sock.sendMessage(from, {
                    text: aviso('Cadê a Imagem?', [
                        `Marque ou envie uma imagem com a legenda *${prefix}upscale*`,
                        'Formatos suportados: JPEG/PNG'
                    ])
                }, { quoted: m });
            }

            if (imagemBuffer.length > 5 * 1024 * 1024) {
                return sock.sendMessage(from, {
                    text: aviso('Imagem Muito Grande', ['O tamanho máximo permitido é 5MB.'])
                }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

            let resultado;
            try {
                resultado = await enhance(imagemBuffer, 'enhance');
            } catch (enhanceError) {
                resultado = await enhance(imagemBuffer, 'recolor');
            }

            await sock.sendMessage(from, {
                image: resultado,
                caption: sucesso('Imagem Melhorada', ['✨ Qualidade aumentada com sucesso!'])
            }, { quoted: m });

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[UPSCALE ERROR]', err?.message || err);
            try { await sock.sendMessage(from, { react: { text: '❌', key: m.key } }); } catch (_) {}
            await sock.sendMessage(from, {
                text: erro('Erro no Upscale', [`Não consegui melhorar a imagem: ${err.message}`])
            }, { quoted: m });
        }
    }
};

/**
 * Baixa a imagem marcada (quoted) ou enviada junto com o comando
 */
async function baixarImagem(sock, m) {
    const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const iMessage = m.message?.imageMessage || quoted?.imageMessage;
    if (!iMessage) return null;

    if (typeof sock.downloadMediaMessage === 'function') {
        const msgParaBaixar = quoted ? { message: quoted } : m;
        try {
            return await sock.downloadMediaMessage(msgParaBaixar);
        } catch (e) {
            console.log('[UPSCALE] Falha no download direto:', e.message);
            return null;
        }
    }
    return null;
}

function enhance(buffer, method) {
    return new Promise((resolve, reject) => {
        const validMethods = ['enhance', 'recolor', 'dehaze'];
        if (!validMethods.includes(method)) method = validMethods[0];

        const form = new FormData();
        const scheme = `https://inferenceengine.vyro.ai/${method}`;

        const headers = {
            'User-Agent': 'okhttp/4.9.3',
            Connection: 'Keep-Alive',
            'Accept-Encoding': 'gzip',
            'X-Requested-With': 'XMLHttpRequest',
            'Cache-Control': 'no-cache'
        };

        try {
            form.append('model_version', 1, {
                'Content-Transfer-Encoding': 'binary',
                contentType: 'multipart/form-data; charset=utf-8'
            });

            form.append('image', buffer, {
                filename: `enhance_image_${Date.now()}.jpg`,
                contentType: 'image/jpeg'
            });

            const timeout = 30000;

            form.submit({
                url: scheme,
                host: 'inferenceengine.vyro.ai',
                path: `/${method}`,
                protocol: 'https:',
                headers,
                timeout
            }, (err, res) => {
                if (err) return reject(new Error(`Falha ao enviar requisição: ${err.message}`));

                const chunks = [];
                res.on('data', chunk => chunks.push(chunk));
                res.on('end', () => {
                    const resultado = Buffer.concat(chunks);
                    if (resultado.length === 0) reject(new Error('Resultado do processamento veio vazio'));
                    else resolve(resultado);
                });
                res.on('error', e => reject(new Error(`Erro ao receber dados: ${e.message}`)));

                setTimeout(() => reject(new Error(`Timeout após ${timeout / 1000} segundos`)), timeout);
            });
        } catch (error) {
            reject(new Error(`Erro ao processar requisição: ${error.message}`));
        }
    });
}