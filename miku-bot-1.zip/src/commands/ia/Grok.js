// src/commands/ia/grok.js
// Pergunta direta pro Grok 4.5, com suporte a leitura de imagem por URL.
// Uso: grok <pergunta> | grok <pergunta> | <url da imagem>

const path = require('path');
const axios = require('axios');
const { aviso, erro } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
// Ajuste esse caminho se o seu settings/config.js estiver em outro lugar
const { config } = require(path.join(__dirname, '..', '..', '..', 'settings', 'config.js'));

module.exports = {
    name: 'grok',
    aliases: ['grok4', 'xai'],
    description: 'Conversa direta com o Grok 4.5 — aceita leitura de imagem por URL',
    usage: 'grok <pergunta> | grok <pergunta> | <url da imagem>',

    async execute(sock, m, options) {
        const from = m.key.remoteJid;
        const prefix = options?.prefix || '.';
        const args = options?.args || [];
        const textoCompleto = args.join(' ').trim();

        if (!textoCompleto) {
            return sock.sendMessage(from, {
                text: aviso('Cadê a Pergunta?', [
                    `Uso: *${prefix}grok <pergunta>*`,
                    `Com imagem: *${prefix}grok <pergunta> | <url da imagem>*`
                ])
            }, { quoted: m });
        }

        const pedacos = textoCompleto.split('|').map(p => p.trim());
        const pergunta = pedacos[0];
        const imagemUrl = pedacos[1] || null;

        if (!pergunta) {
            return sock.sendMessage(from, {
                text: aviso('Cadê a Pergunta?', [
                    `Uso: *${prefix}grok <pergunta>*`,
                    `Com imagem: *${prefix}grok <pergunta> | <url da imagem>*`
                ])
            }, { quoted: m });
        }

        try {
            await sock.sendMessage(from, { react: { text: '🤔', key: m.key } });

            const params = { apikey: config.apis.zoneApi, text: pergunta };
            if (imagemUrl) params.image = imagemUrl;

            const { data } = await axios.get('https://zone.api.br/api/ia/grok-4-5', {
                params,
                timeout: 60000
            });

            if (!data?.status || !data?.text) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: erro('Erro no Grok', ['A IA não devolveu uma resposta válida, tenta de novo.'])
                }, { quoted: m });
            }

            await sock.sendMessage(from, { text: data.text }, { quoted: m });
            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[GROK ERROR]', err?.response?.data || err?.message || err);
            try { await sock.sendMessage(from, { react: { text: '❌', key: m.key } }); } catch (_) {}
            await sock.sendMessage(from, {
                text: erro('Erro no Grok', ['Não consegui falar com o Grok agora, tenta de novo em instantes.'])
            }, { quoted: m });
        }
    }
};