// src/commands/ia/edit.js
// IA IMAGE EDITOR + MERGE DE ÁUDIO — adaptado pro padrão do bot (miku/grok)
// API: zone.api.br/api/v2/edit/deepai (Multipart Form)
//
// CORRIGIDO:
//  - rota systemzone.store trocada pela rota atual zone.api.br
//  - bugs de digitação (texto/palavra/obterComentarioDaIA/mensagemEnviada
//    estavam com nomes inconsistentes e quebravam o comando)

const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { aviso, erro } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
// Ajuste esse caminho se o seu settings/config.js estiver em outro lugar
const { config } = require(path.join(__dirname, '..', '..', '..', 'settings', 'config.js'));

const CHANNEL_JID  = '120363420045810596@newsletter';
const CHANNEL_NAME = 'Yuka-Bot 🤖';

const safe = async fn => { try { return await fn(); } catch { return null; } };
function isPV(jid) { return !jid.endsWith('@g.us'); }

/**
 * Divide o texto longo em blocos de até 99 caracteres respeitando os espaços,
 * sem limites no número máximo de blocos para processar textos grandes.
 */
function dividirTextoParaTTS(texto, maxChars = 99) {
    const palavras = texto.split(' ');
    const blocks = [];
    let blocoAtual = '';

    for (const palavra of palavras) {
        if ((blocoAtual + ' ' + palavra).trim().length <= maxChars) {
            blocoAtual = (blocoAtual + ' ' + palavra).trim();
        } else {
            if (blocoAtual) blocks.push(blocoAtual);
            blocoAtual = palavra;
        }
    }
    if (blocoAtual) blocks.push(blocoAtual);

    return blocks;
}

/**
 * Função auxiliar para baixar mídias de forma compatível com Baileys modificado
 */
async function baixarImagemModded(sock, m) {
    if (typeof sock.downloadMediaMessage === 'function') {
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const msgParaBaixar = quoted ? { message: quoted } : m;
        try {
            return await sock.downloadMediaMessage(msgParaBaixar);
        } catch (e) {
            console.log('[EDIT-BAILEYS] Falha no download direto, tentando fallback...');
        }
    }

    try {
        const baileysMod = require('@systemzero/baileys');
        const downloadFn = baileysMod.downloadContentFromMessage || baileysMod.default?.downloadContentFromMessage;

        if (!downloadFn) return null;

        const iMessage = m.message?.imageMessage ||
                        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;

        if (!iMessage) return null;

        const stream = await downloadFn(iMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    } catch (err) {
        console.error('[EDIT-BAILEYS] Erro ao baixar imagem:', err.message);
        return null;
    }
}

/**
 * Faz a Yuka comentar sobre a edição para alimentar o TTS
 */
async function obterComentarioDaIA(promptEdicao) {
    try {
        const promptDefinido =
            `Você é a Yuka-Bot, uma inteligência artificial viva, carismática e engraçada. ` +
            `O usuário pediu para editar uma foto com a seguinte instrução: "${promptEdicao}". ` +
            `Dê uma resposta curtíssima (máximo de 70 caracteres), engraçada ou irônica dando a sua opinião sobre o resultado dessa ideia na foto. Não use emojis, asteriscos, aspas ou pontuações estranhas, escreva apenas o texto corrido e simples para o áudio ser gerado perfeitamente.`;

        const res = await axios.get(`https://zone.api.br/api/ia/deepai`, {
            params: {
                apikey: config.apis.zoneApi,
                text: 'comente essa edicao de forma falada',
                prompt: promptDefinido
            },
            timeout: 15000
        });
        const textoResposta = res.data?.result || res.data?.response || res.data?.text || '';

        // Limpeza profunda de formatação para evitar quebra no TTS
        return textoResposta.replace(/[*_`~\n\r"']/g, '').trim();
    } catch {
        return 'Prontinho Ficou simplesmente perfeito';
    }
}

async function gerarAudioTTS(textoBloco) {
    console.log('[EDIT-TTS] Gerando TTS para:', textoBloco);
    const res = await axios.get('https://zone.api.br/api/tts', {
        params: { apikey: config.apis.zoneApi, text: textoBloco, model: 'nahida' },
        timeout: 25000
    });
    return res.data;
}

module.exports = {
    name: 'edit',
    aliases: ['editar', 'reedit', 'editaia'],
    description: 'Edite imagens usando IA e receba a reação da Yuka em áudio fluido unificado.',
    usage: 'edit <instruções da edição> (marque ou envie uma imagem)',

    async execute(sock, m, options) {
        const { from, args } = options;
        const prefix = options?.prefix || '.';

        try {
            // ── 1. Verifica as instruções do utilizador ───────────
            const promptEdicao = (args || []).join(' ').trim();
            if (!promptEdicao) {
                return sock.sendMessage(from, {
                    text: aviso('Editor de Imagens IA', [
                        'Responda a uma foto ou envie uma legenda usando:',
                        `*${prefix}edit adicione óculos escuros e cabelo azul*`
                    ])
                }, { quoted: m });
            }

            // ── 2. Baixa a mídia do WhatsApp ──────────────────────
            await sock.sendMessage(from, { react: { text: '🔍', key: m.key } });

            const imagemBuffer = await baixarImagemModded(sock, m);
            if (!imagemBuffer) {
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: aviso('Imagem Não Encontrada', ['Certifique-se de marcar uma foto válida com o comando.'])
                }, { quoted: m });
            }

            // Reação de processamento da IA
            await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

            // ── 3. Gera a Opinião da Yuka para o Áudio ─────────────
            const comentarioYuka = await obterComentarioDaIA(promptEdicao);
            console.log('[EDIT-TTS] Texto gerado para o áudio:', comentarioYuka);

            // ── 4. Monta o formulário Multipart/Form-Data para o Editor ──
            const form = new FormData();
            form.append('image', imagemBuffer, {
                filename: 'imagem.jpg',
                contentType: 'image/jpeg'
            });
            form.append('prompt', promptEdicao);
            form.append('apikey', config.apis.zoneApi);

            const endpoint = 'https://zone.api.br/api/v2/edit/deepai';
            console.log('[EDIT-IA] Enviando arquivo via FormData para o Editor...');

            const { data } = await axios.post(endpoint, form, {
                headers: { ...form.getHeaders() },
                timeout: 75000
            });

            const urlResultado = data?.imagem || data?.result || data?.download_url || data?.url;

            if (!urlResultado) {
                console.error('[EDIT-IA] Resposta sem URL válida:', JSON.stringify(data));
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(from, {
                    text: erro('Erro na Edição', ['A IA não devolveu um resultado válido para esta edição.'])
                }, { quoted: m });
            }

            // ── 5. Envia Primeiro a Imagem Editada ────────────────
            await sock.sendMessage(from, { react: { text: '📥', key: m.key } });

            const urlSegura = urlResultado.replace('http://', 'https://');
            const emPV = isPV(from);
            const legendaImagem = `✨ *Imagem editada com sucesso!*\n💡 *Prompt:* _${promptEdicao}_`;

            let mensagemEnviada;
            if (emPV) {
                mensagemEnviada = await sock.sendMessage(from, {
                    image: { url: urlSegura },
                    caption: legendaImagem,
                    mimetype: 'image/jpeg'
                }, { quoted: m });
            } else {
                mensagemEnviada = await sock.sendMessage(from, {
                    image: { url: urlSegura },
                    caption: legendaImagem,
                    mimetype: 'image/jpeg',
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: CHANNEL_JID,
                            newsletterName: CHANNEL_NAME,
                            serverMessageId: 1
                        }
                    }
                }, { quoted: m });
            }

            // ── 6. Gera e Envia o Áudio TTS (SISTEMA UNIFICADO IGUAL YUKA.JS) ──
            const blocosDeTexto = dividirTextoParaTTS(comentarioYuka, 99);
            let buffersAudio = [];

            for (let i = 0; i < blocosDeTexto.length; i++) {
                try {
                    const dadosTTS = await gerarAudioTTS(blocosDeTexto[i]);

                    if (dadosTTS && dadosTTS.download_url) {
                        const urlAudioSegura = dadosTTS.download_url.replace('http://', 'https://');

                        // Faz o download temporário de cada bloco em memória
                        const resAudio = await axios.get(urlAudioSegura, { responseType: 'arraybuffer', timeout: 15000 });
                        if (resAudio?.data) {
                            buffersAudio.push(Buffer.from(resAudio.data));
                        }
                    }
                } catch (ttsErr) {
                    console.error(`[EDIT-TTS] Falha ao baixar bloco TTS de índice ${i}:`, ttsErr.message);
                }
            }

            // Mescla tudo de forma nativa e envia um único arquivo igualzinho ao yuka.js
            if (buffersAudio.length > 0) {
                const audioUnificado = Buffer.concat(buffersAudio);

                if (emPV) {
                    await sock.sendMessage(from, {
                        audio: audioUnificado,
                        mimetype: 'audio/mpeg',
                        fileName: `Yuka_Completo.mp3`,
                        ptt: false
                    }, { quoted: mensagemEnviada || m });
                } else {
                    await sock.sendMessage(from, {
                        audio: audioUnificado,
                        mimetype: 'audio/mpeg',
                        fileName: `Yuka_Completo.mp3`,
                        ptt: false,
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: CHANNEL_JID,
                                newsletterName: CHANNEL_NAME,
                                serverMessageId: 1
                            }
                        }
                    }, { quoted: mensagemEnviada || m });
                }
            } else {
                // Fallback de texto caso a API de TTS caia inteira
                console.log('[EDIT-TTS] Enviando comentário em texto (Fallback)...');
                await sock.sendMessage(from, { text: `🔊 *Yuka:* ${comentarioYuka}` }, { quoted: mensagemEnviada || m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[EDIT-CMD] Erro no comando edit:', err.message);
            await safe(() => sock.sendMessage(from, { react: { text: '❌', key: m.key } }));

            const erroServidor = err.response?.data ? JSON.stringify(err.response.data) : err.message;
            await safe(() => sock.sendMessage(from, {
                text: erro('Erro na API do Editor', [erroServidor])
            }, { quoted: m }));
        }
    }
};