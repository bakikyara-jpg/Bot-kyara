// src/commands/ia/miku.js
// Conversa com a IA (Grok 4.5) — com memória por usuário ou por grupo.
// Funciona COM ou SEM prefixo: "miku qual a capital do Brasil?" ou
// "!miku qual a capital do Brasil?" (o index.js trata o gatilho sem prefixo).
//
// CORRIGIDO: a rota antiga (zone.api.br/api/copilot2) foi trocada pela
// rota atual da IA — zone.api.br/api/ia/grok-4-5 — que também aceita
// leitura de imagem por URL (miku <pergunta> | <url da imagem>).

const path = require('path');
const axios = require('axios');
const { box, sucesso, aviso, erro } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));
// Ajuste esse caminho se o seu settings/config.js estiver em outro lugar
const { config } = require(path.join(__dirname, '..', '..', '..', 'settings', 'config.js'));

module.exports = {
    name: 'miku',
    aliases: ['chatyk'],
    description: 'Conversa com a IA (Grok 4.5) — com memória por usuário ou por grupo',
    usage: 'miku <sua pergunta> | miku <pergunta> | <url da imagem> | miku grupos',
    semPrefixo: true, // sinaliza pro index.js que esse comando pode ser chamado sem o prefixo

    async execute(sock, m, options) {
        const from = m.key.remoteJid;
        const prefix = options?.prefix || '.';
        const isGroup = from.endsWith('@g.us');
        const args = options?.args || [];
        const textoCompleto = args.join(' ').trim();

        try {
            if (!global.mikuGrupos) global.mikuGrupos = new Set();

            // ── Toggle de memória compartilhada do grupo ──────────────
            if (textoCompleto.toLowerCase() === 'grupos') {
                if (!isGroup) {
                    return sock.sendMessage(from, {
                        text: aviso('Modo Grupos', ['Esse modo só funciona dentro de grupos.'])
                    }, { quoted: m });
                }
                if (global.mikuGrupos.has(from)) {
                    global.mikuGrupos.delete(from);
                    return sock.sendMessage(from, {
                        text: sucesso('Memória Compartilhada', ['Desativada — agora cada um tem a própria conversa com a Miku.'])
                    }, { quoted: m });
                } else {
                    global.mikuGrupos.add(from);
                    return sock.sendMessage(from, {
                        text: sucesso('Memória Compartilhada', ['Ativada — todo o grupo conversa na mesma linha com a Miku agora.'])
                    }, { quoted: m });
                }
            }

            if (!textoCompleto) {
                return sock.sendMessage(from, {
                    text: aviso('Cadê a Pergunta?', [
                        `Exemplo: *miku Qual a capital do Brasil?*`,
                        `Com imagem: *miku Descreva essa foto | <url da imagem>*`,
                        `Ou com prefixo: *${prefix}miku Qual a capital do Brasil?*`
                    ])
                }, { quoted: m });
            }

            // ── Suporte a leitura de imagem por URL (miku pergunta | url) ──
            const pedacos = textoCompleto.split('|').map(p => p.trim());
            const text = pedacos[0];
            const imagemUrl = pedacos[1] || null;

            const grupoAtivo = isGroup && global.mikuGrupos.has(from);
            const sender = m.key.participant || m.key.remoteJid;
            const session = grupoAtivo ? from : sender;

            await sock.sendMessage(from, { react: { text: '👀', key: m.key } });

            const params = { apikey: config.apis.zoneApi, text, session };
            if (imagemUrl) params.image = imagemUrl;

            const { data } = await axios.get('https://zone.api.br/api/ia/grok-4-5', {
                params,
                timeout: 60000
            });

            if (!data?.status || !data?.text) throw new Error('Sem resposta da IA');

            const respostaIA = data.text;
            const partes = [];
            const capabilities = [];
            const codeRegex = /```(\w+)?\s*\n([\s\S]*?)```/g;
            let lastIndex = 0;
            let match;
            let temCodigo = false;

            while ((match = codeRegex.exec(respostaIA)) !== null) {
                if (match.index > lastIndex) {
                    const textPart = respostaIA.substring(lastIndex, match.index).trim();
                    if (textPart) partes.push(sock.makeText(textPart));
                }
                const linguagem = match[1] || 'text';
                const codigoPuro = match[2].trim();
                partes.push(sock.makeCode(linguagem, codigoPuro));
                temCodigo = true;
                lastIndex = codeRegex.lastIndex;
            }

            if (lastIndex < respostaIA.length) {
                const textPart = respostaIA.substring(lastIndex).trim();
                if (textPart) partes.push(sock.makeText(textPart));
            }

            if (temCodigo) capabilities.push('RICH_RESPONSE_CODE');

            if (typeof sock.sendRich === 'function' && partes.length) {
                await sock.sendRich(from, partes, m, capabilities);
            } else {
                // Fallback caso o shim sendRich/makeText não exista nessa versão da lib
                await sock.sendMessage(from, { text: respostaIA }, { quoted: m });
            }

            await sock.sendMessage(from, { react: { text: '✅', key: m.key } });

        } catch (err) {
            console.error('[MIKU-IA ERROR]', err?.response?.data || err?.message || err);
            try { await sock.sendMessage(from, { react: { text: '💔', key: m.key } }); } catch (_) {}
            await sock.sendMessage(from, {
                text: erro('Erro na IA', ['Não consegui falar com a Miku agora, tenta de novo em instantes.'])
            }, { quoted: m });
        }
    }
};