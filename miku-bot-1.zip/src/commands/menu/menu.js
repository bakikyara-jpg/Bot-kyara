const path = require("path");
const fs = require("fs");
const { config } = require(path.join(__dirname, "..", "..", "..", "settings", "config.js"));
const { box, styledTitle, TOPO_ESQ, TOPO_DIR, RODAPE, BALA } = require(path.join(__dirname, "..", "..", "lib", "style.js"));

// Nomes bonitos pras categorias (pasta -> título exibido no menu)
const NOME_CATEGORIA = {
    menu: 'Menu',
    geral: 'Geral',
    moderacao: 'Moderação',
    ia: 'Inteligência Artificial',
    download: 'Download',
    zoeira: 'Zoeira',
    dono: 'Dono',
    debug: 'Debug',
};

function tituloCategoria(pasta) {
    return NOME_CATEGORIA[pasta] || styledTitle(pasta);
}

module.exports = {
    name: "menu",
    async execute(sock, m, options) {
        const { prefixoAtual, senderName, sender, from } = options;

        try {
            const botName = config.botName;
            const creatorName = config.creatorName;
            const imgBanner = config.imgBanner;
            const canalLink = config.canalLink;

            // Definição das rotas dentro do container VPS
            const pathComandos = path.join(__dirname, "..");
            const pastaDatabase = path.join(__dirname, "..", "..", "database", "cmds");
            const arquivoCacheJson = path.join(pastaDatabase, "mapeamento_menu.json");

            if (!fs.existsSync(pastaDatabase)) {
                fs.mkdirSync(pastaDatabase, { recursive: true });
            }

            // 1. MAPEAMENTO AUTOMÁTICO E CÁLCULO DE TOTAL DE COMANDOS
            let caminhosSubpastas = [];
            if (fs.existsSync(pathComandos)) {
                caminhosSubpastas = fs.readdirSync(pathComandos).filter(file => {
                    return fs.statSync(path.join(pathComandos, file)).isDirectory();
                });
            }

            let totalComandosBot = 0;
            const novoMapeamento = {};

            caminhosSubpastas.forEach((subpasta, index) => {
                const idNumerico = String(index + 1);
                const pastaCompleta = path.join(pathComandos, subpasta);

                const comandosDaPasta = fs.readdirSync(pastaCompleta)
                    .filter(file => file.endsWith(".js"))
                    .map(file => file.replace(".js", ""));

                totalComandosBot += comandosDaPasta.length;

                novoMapeamento[idNumerico] = {
                    categoria: subpasta,
                    titulo: tituloCategoria(subpasta),
                    comandos: comandosDaPasta
                };
            });

            // Grava o cache no JSON da database
            fs.writeFileSync(arquivoCacheJson, JSON.stringify(novoMapeamento, null, 4), "utf-8");
            const databaseMenu = JSON.parse(fs.readFileSync(arquivoCacheJson, "utf-8"));

            // 2. CAPTURA DO COMANDO (COMPATÍVEL COM ENTRADA DE TEXTO)
            const textoMensagem = m.message?.conversation || m.message?.extendedTextMessage?.text || m.body || "";
            const comandoLido = textoMensagem.toLowerCase().trim();

            let idDetectado = null;
            const partesDoTexto = comandoLido.split(" ");
            const possivelId = partesDoTexto[partesDoTexto.length - 1];

            if (databaseMenu[comandoLido]) {
                idDetectado = comandoLido;
            } else if (databaseMenu[possivelId]) {
                idDetectado = possivelId;
            }

            // ─── MODO 1: SE DIGITOU O ID DA CATEGORIA (Ex: !menu 1) -> EXIBE OS COMANDOS ───
            if (idDetectado && databaseMenu[idDetectado]) {
                const categoriaAlvo = databaseMenu[idDetectado];

                const linhasCmds = categoriaAlvo.comandos.length
                    ? categoriaAlvo.comandos.map(cmd => `${prefixoAtual}${cmd}`)
                    : ['_Nenhum comando nesta pasta._'];

                const menuTexto = box(categoriaAlvo.titulo, [
                    `Aba ID: [ ${idDetectado} ]`,
                    `Quantidade: ${categoriaAlvo.comandos.length} comandos`,
                    ...linhasCmds,
                ]);

                const menuFinal = `${menuTexto}\n\n*${botName} — Sistema de Ajuda*`;

                await sock.sendMessage(from, {
                    image: { url: imgBanner },
                    caption: menuFinal
                }, { quoted: m });

                try { await sock.sendMessage(from, { react: { text: "📥", key: m.key } }); } catch (e) {}
                return;
            }

            // ─── MODO 2: LAYOUT VISUAL DO PAINEL PRINCIPAL VIA TEXTO POR ID ───
            const linhasCategorias = Object.keys(databaseMenu).map(idKey => {
                const dados = databaseMenu[idKey];
                return `[ ${idKey} ] ${dados.titulo} _(${dados.comandos.length} cmds)_`;
            });

            const readMore = String.fromCharCode(8206).repeat(4000);

            const cardPrincipal = box('Menu', [
                `Bot: ${botName}`,
                `Prefixo: [ ${prefixoAtual} ]`,
                `Solicitante: ${senderName}`,
                `Criador: ${creatorName}`,
                `ID: ${sender.split('@')[0]}`,
                `Total Cmds: ${totalComandosBot}`,
                `Status: Online`,
            ]);

            const cardAbas = box('Abas do Sistema', linhasCategorias);

            const menuPrincipalTexto = `${cardPrincipal}${readMore}\n\n${cardAbas}\n\n🌀 _Para abrir uma aba, envie o comando com o ID correspondente (Ex: *${prefixoAtual}menu 1*)._`;

            // Prepara a mídia utilizando as ferramentas internas do seu hzxx
            const imagemProcessada = await sock.hzxx.utils.prepareWAMessageMedia(
                { image: { url: imgBanner } },
                { upload: sock.waUploadToServer }
            );

            // Montagem do Payload corrigido
            const dynamicMenuPayload = {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadataVersion: 2,
                            deviceListMetadata: {}
                        },
                        interactiveMessage: {
                            header: {
                                title: "",
                                hasSubtitle: false,
                                imageMessage: imagemProcessada.imageMessage,
                                hasMediaAttachment: true
                            },
                            body: {
                                text: menuPrincipalTexto
                            },
                            footer: {
                                text: `© ${botName} - Por ${creatorName}`
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: `Channel ${botName} 📢`,
                                            url: canalLink,
                                            merchant_url: canalLink
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "MINHA LID 🆔",
                                            id: `minha_lid_${sender}`
                                        })
                                    }
                                ]
                            },
                            contextInfo: {
                                stanzaId: m.key.id,
                                participant: m.sender || m.key.participant,
                                quotedMessage: m.message
                            }
                        }
                    }
                }
            };

            await sock.relayMessage(from, dynamicMenuPayload, {});

            try { await sock.sendMessage(from, { react: { text: "🌀", key: m.key } }); } catch (e) {}

        } catch (error) {
            console.error("Erro crítico na montagem do menu estruturado:", error);
        }
    },
};
