const os = require('os');
const crypto = require('crypto');
const { config, ownerJid } = require('../../../settings/config.js');

module.exports = {
    name: "debug",
    aliases: ["fullscan", "xray", "omniscan", "dna", "forense"],

    async execute(sock, m, options) {
        const { from } = options;
        const meuNumero = ownerJid();

        // ─── AUXILIARES DE FORMATAÇÃO ───
        const mb = n => `${(n / 1048576).toFixed(2)} MB`;
        const gb = n => `${(n / 1073741824).toFixed(2)} GB`;
        
        const deepScanner = (obj, level = 0) => {
            let out = '';
            const pad = ' '.repeat(level); // Espaço mínimo para evitar quebra de linha lateral
            for (const k in obj) {
                try {
                    const v = obj[k];
                    if (typeof v === 'function') continue;
                    let icon = '▸';
                    if (typeof v === 'boolean') icon = v ? '✅' : '❌';
                    if (/id|jid/i.test(k)) icon = '🆔';
                    
                    if (v && typeof v === 'object' && !Buffer.isBuffer(v)) {
                        out += `${pad}${icon} *${k}*:\n${deepScanner(v, level + 1)}`;
                    } else {
                        let display = v;
                        if (Buffer.isBuffer(v)) display = `[BUFFER ${v.length}B]`;
                        const safe = String(display ?? 'null').replace(/\n/g, ' ↵ ').slice(0, 100);
                        out += `${pad}${icon} *${k}*: \`${safe}\`\n`;
                    }
                } catch { continue; }
            }
            return out;
        };

        try {
            await sock.sendMessage(from, { react: { text: "👁️‍🗨️", key: m.key } });

            const inicio = Date.now();
            const mem = process.memoryUsage();
            const cpus = os.cpus();
            const runtime = process.uptime();
            
            // Formatação de Tempo (Runtime)
            const h = Math.floor(runtime / 3600);
            const min = Math.floor((runtime % 3600) / 60);
            const s = Math.floor(runtime % 60);

            // Coleta de JSON Bruto
            const jsonBruto = JSON.stringify(m, (k, v) => typeof v === 'bigint' ? v.toString() : v, 2);
            const jsonBuf = Buffer.from(jsonBruto, 'utf8');

            // ─── CONSTRUÇÃO DO RELATÓRIO VISUAL ───
            const corpo = [
                `╔━᳀『 📡  SISTEMA 』═᳀`,
                `⌬ *OS*: ${os.type()} ${os.arch()}`,
                `⌬ *Host*: ${os.hostname()}`,
                `⌬ *Node*: ${process.version}`,
                `⌬ *Runtime*: ${h}h ${min}m ${s}s`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                ``,
                `╔━᳀『 ⚙️  HARDWARE 』═᳀`,
                `⌬ *CPU*: ${cpus[0].model.split('@')[0].trim()}`,
                `⌬ *Núcleos*: ${cpus.length} Cores`,
                `⌬ *RAM*: ${gb(os.totalmem())}`,
                `⌬ *Uso Heap*: ${mb(mem.heapUsed)}`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                ``,
                `╔━᳀『 🆔  MENSAGEM 』═᳀`,
                `⌬ *ID*: \`${m.key.id}\``,
                `⌬ *PushName*: ${m.pushName || 'N/A'}`,
                `⌬ *Tipo*: ${Object.keys(m.message || {})[0] || 'Desconhecido'}`,
                `⌬ *De*: \`${m.key.remoteJid}\``,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                ``,
                `╔━᳀『 📊  FORENSE 』═᳀`,
                `⌬ *Tamanho JSON*: ${(jsonBuf.length / 1024).toFixed(2)} KB`,
                `⌬ *Latência*: ${Date.now() - inicio}ms`,
                `⌬ *Timestamp*: ${new Date().toLocaleString('pt-BR')}`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                `© Miku-Bot Debug`
            ].join('\n');

            // ─── ENVIO INTERATIVO ───
            await sock.relayMessage(meuNumero, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "🧬 DNA ANALYSIS FORENSE",
                                hasSubtitle: false,
                                documentMessage: {
                                    inlineFile: jsonBuf,
                                    fileName: `SCAN-${m.key.id}.json`,
                                    mimetype: 'application/json'
                                }
                            },
                            body: { text: corpo },
                            footer: { text: "Clique abaixo para copiar o código fonte" },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Copiar JSON Completo",
                                            id: "copy_json",
                                            copy_code: jsonBruto
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        } catch (error) {
            console.error(error);
            await sock.sendMessage(meuNumero, { text: "💀 *ERRO:* " + error.message });
        }
    }
};