const os = require('os');
const crypto = require('crypto');
const { config, ownerJid } = require('../../../settings/config.js');

module.exports = {
    name: "bly",
    aliases: ["baileysdump", "core", "sysdump", "matrix"],
    description: "Varredura extrema da Baileys, Sistema e Mensagem (com áudio)",

    async execute(sock, m, options) {
        const { from } = options;
        const meuNumero = ownerJid();

        // ─── AUXILIARES DE FORMATAÇÃO ───
        const mb = n => `${(n / 1048576).toFixed(2)} MB`;
        const gb = n => `${(n / 1073741824).toFixed(2)} GB`;

        try {
            await sock.sendMessage(from, { react: { text: "👁️‍🗨️", key: m.key } });
            const inicio = Date.now();

            // ─── 1. GERAR ÁUDIO DE SCANNER (OV/PTT) ───
            // Gera um áudio "beep" sintético nativamente na memória (estilo radar forense)
            try {
                const sampleRate = 16000;
                const duration = 0.5;
                const numSamples = Math.floor(sampleRate * duration);
                const freq = 950; // Frequência do beep
                const buffer = Buffer.alloc(44 + numSamples * 2);
                buffer.write('RIFF', 0);
                buffer.writeUInt32LE(36 + numSamples * 2, 4);
                buffer.write('WAVE', 8);
                buffer.write('fmt ', 12);
                buffer.writeUInt32LE(16, 16);
                buffer.writeUInt16LE(1, 20);
                buffer.writeUInt16LE(1, 22);
                buffer.writeUInt32LE(sampleRate, 24);
                buffer.writeUInt32LE(sampleRate * 2, 28);
                buffer.writeUInt16LE(2, 32);
                buffer.writeUInt16LE(16, 34);
                buffer.write('data', 36);
                buffer.writeUInt32LE(numSamples * 2, 40);
                for (let i = 0; i < numSamples; i++) {
                    const t = i / sampleRate;
                    const sample = Math.sin(2 * Math.PI * freq * t) * 0.5;
                    buffer.writeInt16LE(Math.floor(sample * 32767), 44 + i * 2);
                }
                // Envia como mensagem de voz (Audio OV) para o Dono
                await sock.sendMessage(meuNumero, {
                    audio: buffer,
                    mimetype: 'audio/wav',
                    ptt: true // Envia como Áudio Gravado na Hora
                });
            } catch (e) { console.error('Erro ao gerar áudio OV:', e); }

            // ─── 2. COLETA DE DADOS MASSIVA DA BAILEYS ───
            const mem = process.memoryUsage();
            const cpus = os.cpus();
            const runtime = process.uptime();
            
            // Tempo
            const h = Math.floor(runtime / 3600);
            const min = Math.floor((runtime % 3600) / 60);
            const s = Math.floor(runtime % 60);

            // Analisando a estrutura do SOCK (Baileys)
            const botMethods = Object.keys(sock).filter(k => typeof sock[k] === 'function');
            const botProps = Object.keys(sock).filter(k => typeof sock[k] !== 'function');
            const hzxxData = sock.hzxx ? Object.keys(sock.hzxx) : ['Nenhum módulo HZXX detectado'];

            // Objeto gigantesco com absolutamente TUDO
            const superDump = {
                metadata: {
                    timestamp: new Date().toISOString(),
                    latencia_ms: Date.now() - inicio
                },
                sistema: {
                    os: `${os.type()} ${os.release()} ${os.arch()}`,
                    hostname: os.hostname(),
                    node_version: process.version,
                    cpu: cpus[0].model,
                    ram_total: gb(os.totalmem()),
                    ram_livre: gb(os.freemem()),
                    uptime_segs: runtime
                },
                baileys_core: {
                    tipo_conexao: sock.type || 'Desconhecido',
                    bot_id: sock.user?.id || 'Desconectado',
                    bot_nome: sock.user?.name || 'N/A',
                    socket_properties: botProps,
                    socket_methods: botMethods,
                    custom_hzxx: hzxxData,
                    ws_state: sock.ws?.readyState === 1 ? 'OPEN' : 'CLOSED'
                },
                mensagem_bruta: m
            };

            // Conversão segura evitando falhas com BigInt
            const jsonBruto = JSON.stringify(superDump, (k, v) => typeof v === 'bigint' ? v.toString() : v, 2);
            const jsonBuf = Buffer.from(jsonBruto, 'utf8');

            // ─── 3. CONSTRUÇÃO DO RELATÓRIO VISUAL ───
            const corpo = [
                `╔━᳀『 📡 SISTEMA & HARDWARE 』═᳀`,
                `⌬ *OS*: ${os.type()} ${os.arch()}`,
                `⌬ *Node*: ${process.version}`,
                `⌬ *Runtime*: ${h}h ${min}m ${s}s`,
                `⌬ *CPU*: ${cpus[0].model.split('@')[0].trim()}`,
                `⌬ *RAM*: ${mb(mem.heapUsed)} / ${gb(os.totalmem())}`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                ``,
                `╔━᳀『 ⚙️ BAILEYS CORE (SOCK) 』═᳀`,
                `⌬ *Bot ID*: \`${sock.user?.id?.split(':')[0] || 'N/A'}\``,
                `⌬ *Métodos*: ${botMethods.length} detectados`,
                `⌬ *Propriedades*: ${botProps.length} detectadas`,
                `⌬ *Mod Hzxx*: ${hzxxData.length} funções`,
                `⌬ *Status WS*: ${sock.ws?.readyState === 1 ? '✅ Online' : '❌ Offline'}`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                ``,
                `╔━᳀『 🆔 MENSAGEM & FORENSE 』═᳀`,
                `⌬ *ID Msg*: \`${m.key.id}\``,
                `⌬ *De*: \`${m.key.remoteJid}\``,
                `⌬ *Tamanho JSON*: ${(jsonBuf.length / 1024).toFixed(2)} KB`,
                `⌬ *Latência*: ${Date.now() - inicio}ms`,
                `╚═━═━═━═━═━═━═━═━═᳀`,
                `© Miku-Bot Scanner`
            ].join('\n');

            // ─── 4. ENVIO INTERATIVO PARA O DONO ───
            await sock.relayMessage(meuNumero, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "🧬 BAILEYS DEEP SCAN FORENSE",
                                hasSubtitle: false,
                                documentMessage: {
                                    inlineFile: jsonBuf,
                                    fileName: `BAILEYS-DUMP-${m.key.id.slice(0,6)}.json`,
                                    mimetype: 'application/json'
                                }
                            },
                            body: { text: corpo },
                            footer: { text: "Clique abaixo para copiar o JSON completo" },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "📋 Copiar JSON Completo",
                                            id: "copy_json",
                                            copy_code: jsonBruto
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await sock.sendMessage(from, { react: { text: "✅", key: m.key } });

        } catch (error) {
            console.error('Falha no Scanner:', error);
            await sock.sendMessage(meuNumero, { text: "💀 *ERRO FATAL NO SCANNER:* " + error.message });
        }
    }
};
