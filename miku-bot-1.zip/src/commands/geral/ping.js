const path = require('path');
const { box } = require(path.join(__dirname, '..', '..', 'lib', 'style.js'));

module.exports = {
    name: 'ping',
    aliases: ['p'],
    description: 'Mostra a latência e o tempo online do bot',

    async execute(sock, m, options) {
        const { from } = options;
        const inicio = Date.now();

        await sock.sendMessage(from, { text: box('🏓 Pingando...', ['Aguarde um instante...']) }, { quoted: m });
        const latencia = Date.now() - inicio;

        const runtime = process.uptime();
        const h = Math.floor(runtime / 3600);
        const min = Math.floor((runtime % 3600) / 60);
        const s = Math.floor(runtime % 60);

        await sock.sendMessage(from, {
            text: box('🏓 Pong!', [
                `Latência: ${latencia}ms`,
                `Uptime: ${h}h ${min}m ${s}s`,
            ])
        }, { quoted: m });
    }
};
