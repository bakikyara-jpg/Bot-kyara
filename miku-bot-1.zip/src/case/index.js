// src/case/index.js
// ═══════════════════════════════════════════════════════════════
//  SISTEMA "CASE" DO BOT HÍBRIDO
//  Além dos comandos em plugin (src/commands/<categoria>/*.js),
//  o bot também aceita comandos declarados aqui num switch/case só.
//  Útil pra comandos rápidos que não precisam de arquivo próprio.
//
//  Pra adicionar um comando novo: crie mais um "case 'nome':" no
//  switch abaixo. O handler.js (plugins) sempre tem prioridade —
//  se o comando já existir como plugin, o case aqui é ignorado.
// ═══════════════════════════════════════════════════════════════

const axios = require('axios');
const FormData = require('form-data');
const { config } = require('../../settings/config.js');
const { box, erro, aviso } = require('../lib/style.js');

const API_KEY = config.apis.zoneApi;

// Baixa a mídia (imagem) citada na mensagem, compatível com o fork do Baileys usado.
async function baixarImagemCitada(sock, m) {
    const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const alvo = quotedMsg ? { message: quotedMsg } : m;

    if (typeof sock.downloadMediaMessage === 'function') {
        try {
            return await sock.downloadMediaMessage(alvo);
        } catch (_) { /* cai pro fallback abaixo */ }
    }

    try {
        const { downloadContentFromMessage } = await import('@systemzero/baileys');
        const imageMsg = m.message?.imageMessage || quotedMsg?.imageMessage;
        if (!imageMsg) return null;
        const stream = await downloadContentFromMessage(imageMsg, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
        return buffer;
    } catch (e) {
        console.error('[CASE-IMG] Falha ao baixar imagem:', e.message);
        return null;
    }
}

function temImagem(m) {
    const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    return !!(m.message?.imageMessage || quotedMsg?.imageMessage);
}

/**
 * Tenta resolver o comando via sistema de "case". Retorna true se tratou
 * o comando (mesmo em caso de erro interno), ou false se o comando não
 * existe aqui — nesse caso o index.js segue o fluxo normal.
 */
async function handleCase(sock, m, options, command) {
    const { from, args, prefix } = options;
    const text = (args || []).join(' ').trim();

    switch (command) {

        // ── IAs de texto (multi-modelo) ─────────────────────────
        case 'gpt':
        case 'claude':
        case 'deepseek':
        case 'qwen':
        case 'sonar': {
            if (!text) {
                await sock.sendMessage(from, { text: aviso(`IA — ${command}`, [`O que você gostaria de perguntar?`, `Uso: *${prefix}${command} <pergunta>*`]) }, { quoted: m });
                return true;
            }
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

                const modelos = {
                    gpt: 'gpt-4o-mini',
                    claude: 'claude-haiku',
                    deepseek: 'deepseek',
                    qwen: 'qwen',
                    sonar: 'sonar',
                };

                const { data } = await axios.get('https://zone.api.br/api/v2/multi', {
                    params: { apikey: API_KEY, text, model: modelos[command] },
                    timeout: 45000,
                });

                if (data?.status && data?.resultado) {
                    await sock.sendMessage(from, { text: data.resultado }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: '✅', key: m.key } });
                } else {
                    throw new Error('A API não retornou resultado.');
                }
            } catch (e) {
                console.error(`[CASE-${command.toUpperCase()}] Erro:`, e?.response?.data || e.message);
                await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                await sock.sendMessage(from, { text: erro(`Falha na IA (${command})`, ['Não consegui falar com o modelo agora, tente de novo em instantes.']) }, { quoted: m });
            }
            return true;
        }

        // ── Edição de imagem por IA (nano banana) ───────────────
        case 'nano': {
            if (!temImagem(m)) {
                await sock.sendMessage(from, { text: aviso('Nano Banana', ['Responda a uma imagem com o prompt desejado.']) }, { quoted: m });
                return true;
            }
            if (!text) {
                await sock.sendMessage(from, { text: aviso('Nano Banana', [`Forneça um prompt para a modificação!`, `Exemplo: *${prefix}nano coloque um mini carro bugatti*`]) }, { quoted: m });
                return true;
            }
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });

                const mediaBuffer = await baixarImagemCitada(sock, m);
                if (!mediaBuffer) {
                    await sock.sendMessage(from, { react: { text: '❌', key: m.key } });
                    await sock.sendMessage(from, { text: erro('Imagem Não Encontrada', ['Não consegui baixar a imagem marcada.']) }, { quoted: m });
                    return true;
                }

                const form = new FormData();
                form.append('image', mediaBuffer, 'image.png');
                form.append('prompt', text);
                form.append('output_format', 'png');

                const { data } = await axios.post(`https://zone.api.br/api/v2/nanolite?apikey=${API_KEY}`, form, {
                    headers: form.getHeaders(),
                    maxBodyLength: Infinity,
                    maxContentLength: Infinity,
                    timeout: 90000,
                });

                if (data?.status && data?.imagem) {
                    await sock.sendMessage(from, {
                        image: { url: data.imagem },
                        caption: box('🍌 Nano Banana', [`*Prompt:* ${data.prompt || text}`]),
                    }, { quoted: m });
                    await sock.sendMessage(from, { react: { text: '👍', key: m.key } });
                } else {
                    throw new Error('A API não retornou o resultado esperado.');
                }
            } catch (e) {
                console.error('[CASE-NANO] Erro:', e?.response?.data || e.message);
                await sock.sendMessage(from, { react: { text: '💔', key: m.key } });
                await sock.sendMessage(from, { text: erro('Erro ao Processar Imagem', ['A API de edição falhou, tente novamente.']) }, { quoted: m });
            }
            return true;
        }

        default:
            return false; // comando não existe no sistema case
    }
}

// Nomes tratados pelo case (usado pro handler decidir se checa aqui).
const CASE_COMMANDS = new Set(['gpt', 'claude', 'deepseek', 'qwen', 'sonar', 'nano']);

module.exports = { handleCase, CASE_COMMANDS };
