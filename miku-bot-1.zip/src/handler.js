// src/handler.js
// Varre src/commands/<subpasta>/*.js e monta o mapa de comandos.
// Cada arquivo de comando deve exportar { name, aliases?, execute(sock, m, options) }

const fs = require('fs');
const path = require('path');

const PASTA_COMANDOS = path.join(__dirname, 'commands');

function carregarComandos() {
    const comandosMap = new Map();
    let total = 0;
    let comErro = [];

    if (!fs.existsSync(PASTA_COMANDOS)) return { comandosMap, total, comErro };

    const subpastas = fs.readdirSync(PASTA_COMANDOS).filter(f =>
        fs.statSync(path.join(PASTA_COMANDOS, f)).isDirectory()
    );

    subpastas.forEach(subpasta => {
        const pastaCompleta = path.join(PASTA_COMANDOS, subpasta);
        const arquivos = fs.readdirSync(pastaCompleta).filter(f => f.endsWith('.js'));

        arquivos.forEach(arquivo => {
            const caminho = path.join(pastaCompleta, arquivo);
            try {
                delete require.cache[require.resolve(caminho)];
                const mod = require(caminho);
                if (mod && mod.name && typeof mod.execute === 'function') {
                    mod._categoria = subpasta;
                    comandosMap.set(mod.name.toLowerCase(), mod);
                    if (Array.isArray(mod.aliases)) {
                        mod.aliases.forEach(alias => comandosMap.set(alias.toLowerCase(), mod));
                    }
                    total++;
                }
            } catch (e) {
                comErro.push({ arquivo: `${subpasta}/${arquivo}`, erro: e.message });
            }
        });
    });

    return { comandosMap, total, comErro };
}

module.exports = { carregarComandos };
