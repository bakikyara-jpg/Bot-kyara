// src/utils.js
// Funções usadas por vários comandos — mantidas em um só lugar.

function extractNumber(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0];
}

async function isOwner(sender, ownerNumber, sock, ownerLid) {
    const numeroSender = extractNumber(sender);
    const numeroDono = extractNumber(ownerNumber);
    if (numeroSender === numeroDono) return true;

    // LID do dono (configurado manualmente em settings/config.js)
    if (ownerLid && sender.endsWith('@lid')) {
        if (extractNumber(sender) === extractNumber(ownerLid)) return true;
    }

    // Compatibilidade com LID (WhatsApp às vezes identifica o dono pelo LID)
    try {
        const botNumero = extractNumber(sock?.user?.id || '');
        if (numeroSender === botNumero) return true;
    } catch (_) {}

    return false;
}

async function isUserAdmin(userJid, groupMetadata, sock) {
    if (!groupMetadata || !Array.isArray(groupMetadata.participants)) return false;
    const numeroUser = extractNumber(userJid);

    const participante = groupMetadata.participants.find(p => {
        return extractNumber(p.id) === numeroUser || extractNumber(p.jid || '') === numeroUser;
    });

    if (!participante) return false;
    return participante.admin === 'admin' || participante.admin === 'superadmin';
}

module.exports = { isOwner, isUserAdmin, extractNumber };
