// src/console-ui.js
// Log de terminal do Miku-Bot — mesmo estilo visual (box-drawing) usado
// nas mensagens do bot, só que colorido e organizado pro painel/console.

// ── Cores ANSI (sem depender de nenhum pacote externo) ──────────
const C = {
    reset: '\x1b[0m',
    dim: '\x1b[2m',
    bold: '\x1b[1m',
    red: '\x1b[38;5;204m',
    green: '\x1b[38;5;121m',
    yellow: '\x1b[38;5;221m',
    cyan: '\x1b[38;5;117m',
    magenta: '\x1b[38;5;213m',
    blue: '\x1b[38;5;111m',
    gray: '\x1b[38;5;244m',
    white: '\x1b[38;5;255m',
};

const c = (cor, txt) => `${C[cor] || ''}${txt}${C.reset}`;

const LARGURA = 46;
const LINHA = '─'.repeat(LARGURA);

function limpar() {
    // Não usamos console.clear() pra não sumir com logs úteis do host.
}

function bannerInicio(config) {
    const nome = ` ${config.botName || 'Miku-Bot'} `;
    console.log('\n' + c('magenta', '┏' + LINHA + '┓'));
    console.log(c('magenta', '┃') + c('bold', c('white', centralizar(nome, LARGURA))) + c('magenta', '┃'));
    console.log(c('magenta', '┃') + centralizar('🤖  iniciando o sistema...', LARGURA) + c('magenta', '┃'));
    console.log(c('magenta', '┗' + LINHA + '┛'));
}

function centralizar(txt, largura) {
    const visLen = [...txt].length;
    const espacoTotal = Math.max(0, largura - visLen);
    const esq = Math.floor(espacoTotal / 2);
    const dir = espacoTotal - esq;
    return ' '.repeat(esq) + txt + ' '.repeat(dir);
}

// ── Card padrão usado no console (mesmo visual das msgs do bot) ──
function box(titulo, linhas = [], cor = 'cyan') {
    let out = `\n${c(cor, '╔━᳀『')} ${c('bold', c('white', titulo))} ${c(cor, '』═᳀')}\n`;
    linhas.forEach(l => { out += `${c(cor, '⌬')} ${l}\n`; });
    out += c(cor, '╚═━═━═━═━═━═━═━═━═᳀');
    console.log(out);
}

function statusConexao(status, extra = '') {
    const mapa = {
        online: { icone: '✅', cor: 'green' },
        offline: { icone: '🔌', cor: 'gray' },
        reconectando: { icone: '🔄', cor: 'yellow' },
        erro: { icone: '❌', cor: 'red' },
    };
    const { icone, cor } = mapa[status] || { icone: '➜', cor: 'white' };
    console.log(c(cor, `${icone} ${extra}`));
}

// ── Log de comando executado, com cor por categoria ──────────────
const CORES_CATEGORIA = {
    menu: 'blue',
    grupo: 'yellow',
    moderacao: 'yellow',
    dono: 'magenta',
    zoeira: 'green',
    diversao: 'green',
    download: 'cyan',
    geral: 'white',
    debug: 'red',
};

function logComando({ nome, sender, from, categoria }) {
    const local = from.endsWith('@g.us') ? 'grupo' : 'PV';
    const cor = CORES_CATEGORIA[categoria] || 'white';
    const numero = sender.split('@')[0];
    const tag = `[${(categoria || '??').toUpperCase()}]`;
    console.log(
        `${c('gray', '⌬')} ${c(cor, c('bold', tag))} ${c('white', nome)} ${c('gray', '→')} ${c('cyan', numero)} ${c('gray', `em ${local}`)}`
    );
}

// ── Tabela resumida de comandos carregados por categoria ─────────
function tabelaCategorias(categorias = {}) {
    const chaves = Object.keys(categorias);
    if (!chaves.length) return;
    console.log(c('gray', '\n┌' + '─'.repeat(30) + '┐'));
    chaves.forEach(cat => {
        const qtd = categorias[cat];
        const linha = `  ${cat.padEnd(18, ' ')} ${String(qtd).padStart(3, ' ')} cmd(s)`;
        console.log(c('gray', '│') + c('cyan', linha) + ' '.repeat(Math.max(0, 30 - linha.length)) + c('gray', '│'));
    });
    console.log(c('gray', '└' + '─'.repeat(30) + '┘'));
}

function erroCarregamento(lista = []) {
    if (!lista.length) return;
    console.log(c('red', `\n⚠️  ${lista.length} comando(s) com erro ao carregar:`));
    lista.forEach(e => console.log(c('red', `   ✗ ${e.arquivo}`) + c('gray', ` — ${e.erro}`)));
}

module.exports = {
    box,
    bannerInicio,
    statusConexao,
    logComando,
    tabelaCategorias,
    erroCarregamento,
    limpar,
    c,
};
