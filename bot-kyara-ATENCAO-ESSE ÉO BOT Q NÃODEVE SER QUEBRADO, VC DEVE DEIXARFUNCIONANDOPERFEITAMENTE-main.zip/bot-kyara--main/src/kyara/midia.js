/**
 * SISTEMA DE PROCESSAMENTO DE MÍDIA
 * Processa áudio, imagens e vídeos recebidos pela Kyara
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

/**
 * PROCESSAMENTO DE ÁUDIO
 * Recebe mensagens de voz e as processa
 */

async function processarAudio(buffer, nomeArquivo) {
  try {
    const caminhoAudio = path.join('./tmp', nomeArquivo);
    
    if (!fs.existsSync('./tmp')) {
      fs.mkdirSync('./tmp', { recursive: true });
    }
    
    fs.writeFileSync(caminhoAudio, buffer);
    
    return {
      sucesso: true,
      caminho: caminhoAudio,
      tamanho: buffer.length,
      tipo: 'audio'
    };
  } catch (erro) {
    return {
      sucesso: false,
      erro: erro.message
    };
  }
}

/**
 * GERAÇÃO DE ÁUDIO COM VOZ EXPRESSIVA
 * Cria áudios com a voz doce e fofinha da Kyara
 */

const vozesDisponiveis = {
  kyara: "pt-BR-FranciscaNeural",
  doce: "pt-BR-FranciscaNeural",
  fofinha: "pt-BR-FranciscaNeural",
  yara: "pt-BR-YaraNeural",
  leticia: "pt-BR-LeticiaNeural",
  manuela: "pt-BR-ManuelaNeural",
  giovanna: "pt-BR-GiovannaNeural"
};

function gerarAudio(texto, nomeArquivo, voz = 'kyara') {
  return new Promise((resolve, reject) => {
    try {
      const vozSelecionada = vozesDisponiveis[voz] || vozesDisponiveis.kyara;
      
      const textoSeguro = String(texto)
        .replace(/"/g, "'")
        .replace(/\n+/g, ' ')
        .trim();

      if (!textoSeguro) {
        return reject(new Error('Texto vazio para geração de áudio'));
      }

      const caminhoSaida = path.join('./tmp', nomeArquivo);
      
      if (!fs.existsSync('./tmp')) {
        fs.mkdirSync('./tmp', { recursive: true });
      }

      // Usa edge-tts para gerar áudio com qualidade
      const cmd = `python -m edge_tts --text "${textoSeguro}" --voice "${vozSelecionada}" --rate="+10%" --volume="+20%" --write-media "${caminhoSaida}"`;

      exec(cmd, (erro, stdout, stderr) => {
        if (erro) {
          console.log('Erro ao gerar áudio:', stderr || erro.message);
          return reject(new Error('Falha ao gerar áudio'));
        }

        // Verifica se arquivo foi criado
        setTimeout(() => {
          if (fs.existsSync(caminhoSaida)) {
            resolve({
              sucesso: true,
              caminho: caminhoSaida,
              voz: vozSelecionada
            });
          } else {
            reject(new Error('Arquivo de áudio não foi criado'));
          }
        }, 1000);
      });

    } catch (erro) {
      reject(erro);
    }
  });
}

/**
 * PROCESSAMENTO DE IMAGENS
 */

async function processarImagem(buffer, nomeArquivo) {
  try {
    const caminhoImagem = path.join('./tmp', nomeArquivo);
    
    if (!fs.existsSync('./tmp')) {
      fs.mkdirSync('./tmp', { recursive: true });
    }
    
    fs.writeFileSync(caminhoImagem, buffer);
    
    return {
      sucesso: true,
      caminho: caminhoImagem,
      tamanho: buffer.length,
      tipo: 'imagem'
    };
  } catch (erro) {
    return {
      sucesso: false,
      erro: erro.message
    };
  }
}

/**
 * PROCESSAMENTO DE VÍDEOS
 */

async function processarVideo(buffer, nomeArquivo) {
  try {
    const caminhoVideo = path.join('./tmp', nomeArquivo);
    
    if (!fs.existsSync('./tmp')) {
      fs.mkdirSync('./tmp', { recursive: true });
    }
    
    fs.writeFileSync(caminhoVideo, buffer);
    
    return {
      sucesso: true,
      caminho: caminhoVideo,
      tamanho: buffer.length,
      tipo: 'video'
    };
  } catch (erro) {
    return {
      sucesso: false,
      erro: erro.message
    };
  }
}

/**
 * LIMPEZA DE ARQUIVOS TEMPORÁRIOS
 */

function limparTemp() {
  try {
    const pastaTemp = './tmp';
    
    if (!fs.existsSync(pastaTemp)) return;
    
    const arquivos = fs.readdirSync(pastaTemp);
    
    arquivos.forEach(arquivo => {
      const caminho = path.join(pastaTemp, arquivo);
      const stats = fs.statSync(caminho);
      
      // Remove arquivos mais antigos que 1 hora
      if (Date.now() - stats.mtimeMs > 3600000) {
        fs.unlinkSync(caminho);
      }
    });
  } catch (erro) {
    console.log('Erro ao limpar temp:', erro.message);
  }
}

/**
 * Executa limpeza a cada 30 minutos
 */

setInterval(limparTemp, 30 * 60 * 1000);

module.exports = {
  processarAudio,
  gerarAudio,
  processarImagem,
  processarVideo,
  limparTemp,
  vozesDisponiveis
};
