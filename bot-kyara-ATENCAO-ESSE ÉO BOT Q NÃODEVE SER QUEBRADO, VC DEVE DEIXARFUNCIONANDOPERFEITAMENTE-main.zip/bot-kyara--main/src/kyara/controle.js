/**
 * SISTEMA DE CONTROLE (LIGAR/DESLIGAR KYARA)
 * Permite ativar/desativar a Kyara e gerenciar seu estado
 */

const fs = require('fs');
const path = require('path');

const statusPath = path.join(__dirname, '..', '..', 'database', 'kyara_status.json');

/**
 * Garante existência do arquivo de status
 */

function garantirStatusPath() {
  const pasta = path.dirname(statusPath);
  
  if (!fs.existsSync(pasta)) {
    fs.mkdirSync(pasta, { recursive: true });
  }
  
  if (!fs.existsSync(statusPath)) {
    fs.writeFileSync(
      statusPath,
      JSON.stringify({
        ativa: true,
        modo: 'normal',
        ultimaAtivacao: new Date().toISOString(),
        grupos: {},
        privados: {}
      }, null, 2)
    );
  }
}

/**
 * Carrega status da Kyara
 */

function carregarStatus() {
  garantirStatusPath();
  
  try {
    return JSON.parse(fs.readFileSync(statusPath, 'utf8'));
  } catch {
    return {
      ativa: true,
      modo: 'normal',
      ultimaAtivacao: new Date().toISOString(),
      grupos: {},
      privados: {}
    };
  }
}

/**
 * Salva status da Kyara
 */

function salvarStatus(status) {
  garantirStatusPath();
  
  try {
    fs.writeFileSync(statusPath, JSON.stringify(status, null, 2));
  } catch (erro) {
    console.log('Erro ao salvar status da Kyara:', erro);
  }
}

/**
 * Verifica se Kyara está ativa globalmente
 */

function kyaraEstaAtiva(status) {
  if (!status) status = carregarStatus();
  return status.ativa === true;
}

/**
 * Ativa a Kyara globalmente
 */

function ativarKyara() {
  const status = carregarStatus();
  status.ativa = true;
  status.ultimaAtivacao = new Date().toISOString();
  salvarStatus(status);
  return true;
}

/**
 * Desativa a Kyara globalmente
 */

function desativarKyara() {
  const status = carregarStatus();
  status.ativa = false;
  salvarStatus(status);
  return false;
}

/**
 * Ativa Kyara em um grupo específico
 */

function ativarEmGrupo(jidGrupo) {
  const status = carregarStatus();
  
  if (!status.grupos) status.grupos = {};
  
  status.grupos[jidGrupo] = {
    ativa: true,
    ativadoEm: new Date().toISOString()
  };
  
  salvarStatus(status);
}

/**
 * Desativa Kyara em um grupo específico
 */

function desativarEmGrupo(jidGrupo) {
  const status = carregarStatus();
  
  if (!status.grupos) status.grupos = {};
  
  status.grupos[jidGrupo] = {
    ativa: false,
    desativadoEm: new Date().toISOString()
  };
  
  salvarStatus(status);
}

/**
 * Verifica se Kyara está ativa em um grupo
 */

function kyaraAtivaEmGrupo(jidGrupo) {
  const status = carregarStatus();
  
  if (!kyaraEstaAtiva(status)) return false;
  
  if (!status.grupos) return true; // Se não tem config específica, segue global
  
  const configGrupo = status.grupos[jidGrupo];
  
  if (!configGrupo) return true; // Se não tem config, está ativa por padrão
  
  return configGrupo.ativa !== false;
}

/**
 * Ativa Kyara em um privado específico
 */

function ativarEmPrivado(jidPrivado) {
  const status = carregarStatus();
  
  if (!status.privados) status.privados = {};
  
  status.privados[jidPrivado] = {
    ativa: true,
    ativadoEm: new Date().toISOString()
  };
  
  salvarStatus(status);
}

/**
 * Desativa Kyara em um privado específico
 */

function desativarEmPrivado(jidPrivado) {
  const status = carregarStatus();
  
  if (!status.privados) status.privados = {};
  
  status.privados[jidPrivado] = {
    ativa: false,
    desativadoEm: new Date().toISOString()
  };
  
  salvarStatus(status);
}

/**
 * Verifica se Kyara está ativa em um privado
 */

function kyaraAtivaEmPrivado(jidPrivado) {
  const status = carregarStatus();
  
  if (!kyaraEstaAtiva(status)) return false;
  
  if (!status.privados) return true;
  
  const configPrivado = status.privados[jidPrivado];
  
  if (!configPrivado) return true;
  
  return configPrivado.ativa !== false;
}

/**
 * Altera modo de funcionamento
 */

function alterarModo(novoModo) {
  const status = carregarStatus();
  
  const modosValidos = ['normal', 'silencioso', 'super_expressivo', 'serio'];
  
  if (modosValidos.includes(novoModo)) {
    status.modo = novoModo;
    salvarStatus(status);
    return true;
  }
  
  return false;
}

/**
 * Obtém modo atual
 */

function obterModo() {
  const status = carregarStatus();
  return status.modo || 'normal';
}

module.exports = {
  carregarStatus,
  salvarStatus,
  kyaraEstaAtiva,
  ativarKyara,
  desativarKyara,
  ativarEmGrupo,
  desativarEmGrupo,
  kyaraAtivaEmGrupo,
  ativarEmPrivado,
  desativarEmPrivado,
  kyaraAtivaEmPrivado,
  alterarModo,
  obterModo
};
