/**
 * SISTEMA DE FIGURINHAS
 * A Kyara pode enviar figurinhas na conversa
 */

const fs = require('fs');
const path = require('path');

/**
 * Determina se deve enviar figurinha
 */

function deveSenderFigurinha(afinidade, intencoes) {
  // Só envia figurinha se afinidade for boa
  if (afinidade < 50) return false;
  
  // Mais chance em contextos divertidos
  if (intencoes.includes('brincadeira') || intencoes.includes('humor')) {
    return Math.random() < 0.6; // 60% de chance
  }
  
  // Chance menor em outros contextos
  return Math.random() < 0.2; // 20% de chance
}

/**
 * Seleciona figurinha apropriada
 */

function selecionarFigurinha(intencoes, estadoEmocional) {
  const categoriasFigurinha = {
    felicidade: [
      '😄', '😊', '😍', '🥰', '😂', '😃', 
      '✨', '🌟', '💫', '🎉', '🎊'
    ],
    tristeza: [
      '😢', '😔', '😞', '🥺', '💔'
    ],
    confusao: [
      '🤔', '😕', '🤨', '❓'
    ],
    raiva: [
      '😠', '😡', '🤬', '😤'
    ],
    surpresa: [
      '😲', '😱', '🤭', '😯'
    ],
    diversao: [
      '😜', '😝', '🤪', '😎', '🤠'
    ],
    padrao: [
      '✨', '💚', '🌸', '🦋', '🌺', '🌻',
      '💫', '⭐', '🎀', '🎈', '💕'
    ]
  };
  
  let categoria = 'padrao';
  
  const { humor, energia } = estadoEmocional;
  
  if (humor > 75) categoria = 'felicidade';
  else if (humor < 30) categoria = 'tristeza';
  else if (energia > 80) categoria = 'diversao';
  
  const figuras = categoriasFigurinha[categoria] || categoriasFigurinha.padrao;
  return figuras[Math.floor(Math.random() * figuras.length)];
}

/**
 * Carrega figurinhas do banco de dados local
 */

function carregarFigurinha() {
  try {
    const caminhoFigurinha = './database/figurinhas.json';
    
    if (fs.existsSync(caminhoFigurinha)) {
      const dados = JSON.parse(fs.readFileSync(caminhoFigurinha, 'utf8'));
      
      if (Array.isArray(dados) && dados.length > 0) {
        return dados[Math.floor(Math.random() * dados.length)];
      }
    }
  } catch (erro) {
    console.log('Erro ao carregar figurinhas:', erro.message);
  }
  
  return null;
}

module.exports = {
  deveSenderFigurinha,
  selecionarFigurinha,
  carregarFigurinha
};
