/**
 * SISTEMA DE COMPORTAMENTO CONVERSACIONAL - VERSÃO COMPLETA
 * Gera respostas dinâmicas baseadas em contexto, personalidade e afinidade
 */

const {
  obterAfinidade,
  obterEstadoEmocional,
  obterHistorico,
  obterInformacao,
  obterOpiniao,
  registrarInteracao,
  ehDono
} = require('./personalidade');

/**
 * Componentes de resposta que podem ser combinados
 */

const estilosResposta = {
  carinhoso: [
    'aaah que fofo',
    'adorei demais',
    'que legal mesmo',
    'gostei disso',
    'que lindooo'
  ],
  sarcasmo_leve: [
    'claro, claro',
    'uhhh, entendi',
    'tipo isso mesmo',
    'beleza então',
    'ok ok, deixa quieto'
  ],
  entusiasmo: [
    'CARACA QUE LEGAL',
    'mds que incrível',
    'sério??? KKKKK',
    'SERIO MESMO???',
    'que bacana demais'
  ],
  curiosidade: [
    'como assim?',
    'ué, fala mais',
    'explica melhor',
    'fala mais sobre isso aí',
    'qual é a história?'
  ],
  concordancia: [
    'verdade mesmo',
    'é sim',
    'com certeza',
    'concordo demais',
    'pois é, exato'
  ],
  discordancia: [
    'não sei não',
    'mas olha só',
    'discordo um pouco',
    'nem tanto assim',
    'acho que não é bem assim não'
  ],
  confusao: [
    'to confusa aqui',
    'ué?',
    'não entendi direito',
    'isso é estranho demais',
    'hã, como assim?'
  ],
  apoio: [
    'você vai conseguir',
    'confia em você',
    'você é forte',
    'vai dar certo sim',
    'força aí meu'
  ],
  diversao: [
    'kkkkk que funny',
    'KKKKKK mds',
    'que engraçado',
    'risos demais aqui',
    'KKKK to morrendo de rir'
  ]
};

const terminacoes = [
  '',
  ' kkk',
  ' kkkk',
  ' tá',
  ' sabe?',
  ' sério',
  ' mds',
  ' cara',
  ' mana',
  ' demais',
  ' crz',
  ' lindo'
];

const interjeicoesPositivas = [
  'aaaah',
  'eee',
  'ééé',
  'uuuh',
  'nossa',
  'caraca',
  'mds'
];

const interjeicoesNegativas = [
  'não',
  'ué',
  'hã',
  'quê',
  'poxa',
  'que isso'
];

/**
 * Detector de intenção da mensagem
 */

function detectarIntencao(texto) {
  const textoLimpo = texto.toLowerCase().trim();

  const intencoes = {
    saudacao: /^(oi|olá|e aí|fala|opa|hey|tá blz|tudo bem|tudo certo|e ai|opa)\b/i,
    despedida: /\b(até|tchau|falou|vou indo|preciso ir|bye|adeus|abraço|fuii)\b/i,
    pergunta: /\?$/,
    comando: /^[!/]|\b(faz|execute|lista|mostra|vê|pega|ativa|desativa|liga|desliga)\b/i,
    elogio: /\b(amei|adorei|perfeito|incrível|maravilhoso|sensacional|legal|top|melhor|show|lindo)\b/i,
    reclamacao: /\b(chato|ruim|pior|odeio|irritante|horrível|péssimo|fica ruim)\b/i,
    humor: /\b(kkk|kkkk|rsrs|haha|kk|kkkkk|KKKK)\b/i,
    apoio: /\b(você|kyara|te amo|amei você|gosto de você|respeito|você é top)\b/i,
    curiosidade: /^(como|por que|o que|qual|quem|quando|onde|pq)\b/i,
    confirmacao: /^(sim|yes|com certeza|claro|ok|beleza|blz|tá|tá bom|opa)\b/i,
    negacao: /^(não|nope|nah|nunca|de jeito nenhum)\b/i,
    tristeza: /\b(triste|chato|depressão|sozinho|sozinha|ruim demais|pior)\b/i,
    felicidade: /\b(feliz|muito bom|amei|adorei|perfeito|melhor)\b/i
  };

  const resultados = [];
  Object.entries(intencoes).forEach(([chave, regex]) => {
    if (regex.test(textoLimpo)) {
      resultados.push(chave);
    }
  });

  return resultados;
}

/**
 * Analisa tom e emoção da mensagem
 */

function analisarTom(texto) {
  const textoLimpo = texto.toLowerCase();

  const indicadores = {
    entusiasmado: /(!!|!!!|kkk|kkkk|mds|CARACA|serio|serio\?)/i.test(texto),
    triste: /\b(triste|chato|ruim|depressão|sozinho|sozinha|pior)\b/i.test(textoLimpo),
    bravo: /\b(raiva|furioso|magoado|odiei)\b/i.test(textoLimpo),
    calmo: /\b(tranquilo|tranquila|relaxado|peaceful)\b/i.test(textoLimpo),
    formal: /\b(senhor|senhora|prezado|estimado)\b/i.test(textoLimpo),
    informal: /\b(cara|mana|mds|ué|blz|kkk|kkkk)\b/i.test(textoLimpo)
  };

  return indicadores;
}

/**
 * Gera resposta básica conversacional
 */

function gerarRespostaConversacional(texto, contexto) {
  const intencoes = detectarIntencao(texto);
  const tom = analisarTom(texto);
  
  let resposta = '';
  
  if (intencoes.includes('saudacao')) {
    const saudacoes = [
      'eee, oi oi!',
      'opa, fala aí!',
      'oi oi ✨',
      'e aíí, beleza?',
      'opa, tudo bem sim?',
      'aê, que bom!'
    ];
    resposta = saudacoes[Math.floor(Math.random() * saudacoes.length)];
  }
  else if (intencoes.includes('despedida')) {
    const despedidas = [
      'até mais tarde!',
      'falou demais, abraço! 💚',
      'volta aqui depois tá',
      'abraço, querido!',
      'até depois sim!'
    ];
    resposta = despedidas[Math.floor(Math.random() * despedidas.length)];
  }
  else if (intencoes.includes('elogio')) {
    const respostasElogio = [
      'aaww, obrigada mesmo',
      'aaah, você é fofo demais',
      'que lindoooo esse elogio',
      'obrigada 💚 você também é top',
      'aaaah que legal, gostei'
    ];
    resposta = respostasElogio[Math.floor(Math.random() * respostasElogio.length)];
  }
  else if (intencoes.includes('reclamacao')) {
    const respostasReclamacao = [
      'ué, aconteceu algo ruim?',
      'relaxa que passa sim',
      'tá ruim mesmo né :/',
      'que pena, conta aí o que teve'
    ];
    resposta = respostasReclamacao[Math.floor(Math.random() * respostasReclamacao.length)];
  }
  else if (intencoes.includes('tristeza')) {
    const respostasTristeza = [
      'aaah, que pena 😢',
      'e aí, tudo bem com você?',
      'vem aqui, deixa eu dar um abraço',
      'não fica triste não, meu',
      'você vai ficar bem, confia'
    ];
    resposta = respostasTristeza[Math.floor(Math.random() * respostasTristeza.length)];
  }
  else if (intencoes.includes('felicidade')) {
    const respostasAlegria = [
      'AAAAAAAH QUE ALEGRIA',
      'mds que legal demais!!!',
      'KKKKK muito bom mesmo',
      'que legal, fico feliz com você',
      'CARACA QUE SHOW'
    ];
    resposta = respostasAlegria[Math.floor(Math.random() * respostasAlegria.length)];
  }
  else if (intencoes.includes('curiosidade') || intencoes.includes('pergunta')) {
    resposta = estilosResposta.curiosidade[Math.floor(Math.random() * estilosResposta.curiosidade.length)];
  }
  else if (intencoes.includes('confirmacao')) {
    const confirmacoes = [
      'blz então, confia',
      'pode ser, sem problema',
      'pode deixar sim',
      'pode confiar em mim'
    ];
    resposta = confirmacoes[Math.floor(Math.random() * confirmacoes.length)];
  }
  else if (intencoes.includes('negacao')) {
    const negacoes = [
      'realmente não mesmo',
      'nope, de jeito nenhum',
      'acho que não',
      'não mesmo não'
    ];
    resposta = negacoes[Math.floor(Math.random() * negacoes.length)];
  }
  
  return resposta;
}

/**
 * Gera resposta modificada pela afinidade
 */

function aplicarAfinidadeAoTom(resposta, afinidade) {
  if (afinidade < 30) {
    return resposta;
  }
  
  if (afinidade > 80) {
    const emojisCarinho = [' 💚', ' ✨', ' 💜', ' 🌸', ''];
    resposta += emojisCarinho[Math.floor(Math.random() * emojisCarinho.length)];
  }
  
  return resposta;
}

/**
 * Gera resposta com variação conforme estado emocional
 */

function modificarPorEstadoEmocional(resposta, estadoEmocional) {
  const { humor, energia, paciencia } = estadoEmocional;
  
  if (humor < 40) {
    resposta = resposta.split(' ').slice(0, 5).join(' ');
  }
  
  if (energia > 80) {
    if (Math.random() > 0.5) {
      resposta = resposta.toUpperCase();
    }
  }
  
  if (paciencia < 30) {
    resposta = resposta.replace(/[✨💚💜🌸]/g, '');
  }
  
  return resposta;
}

/**
 * Detector de quando deve responder
 */

function deveSilenciar(texto, intencoes, afinidade) {
  const palavrasVazias = ['kk', 'kkk', 'kkkk', 'rsrs', 'ok', 'blz', 'beleza', 'ok ok'];
  
  if (palavrasVazias.includes(texto.toLowerCase().trim())) {
    if (afinidade > 85) {
      return Math.random() > 0.5;
    }
    return true;
  }
  
  return false;
}

/**
 * Combina elementos para criar resposta final dinâmica
 */

function gerarRespostaDinamica(db, jid, texto, contexto = '') {
  const afinidade = obterAfinidade(db, jid);
  const estadoEmocional = obterEstadoEmocional(db);
  const intencoes = detectarIntencao(texto);
  const tom = analisarTom(texto);
  
  if (deveSilenciar(texto, intencoes, afinidade)) {
    return null;
  }
  
  let resposta = gerarRespostaConversacional(texto, contexto);
  
  if (!resposta) {
    return null;
  }
  
  resposta = aplicarAfinidadeAoTom(resposta, afinidade);
  resposta = modificarPorEstadoEmocional(resposta, estadoEmocional);
  
  registrarInteracao(db, jid, 'resposta_gerada', resposta, 0.6);
  
  return resposta;
}

/**
 * Decide se vai usar áudio para responder
 */

function deveResponderComAudio(db, afinidade, estadoEmocional) {
  if (afinidade < 60) return false;
  
  const energia = estadoEmocional.energia || 70;
  
  if (energia > 75 && afinidade > 75) {
    return Math.random() < 0.35;
  }
  
  if (energia > 60 && afinidade > 65) {
    return Math.random() < 0.15;
  }
  
  return false;
}

module.exports = {
  detectarIntencao,
  analisarTom,
  gerarRespostaConversacional,
  aplicarAfinidadeAoTom,
  modificarPorEstadoEmocional,
  deveSilenciar,
  gerarRespostaDinamica,
  deveResponderComAudio,
  estilosResposta,
  terminacoes,
  interjeicoesPositivas,
  interjeicoesNegativas
};
