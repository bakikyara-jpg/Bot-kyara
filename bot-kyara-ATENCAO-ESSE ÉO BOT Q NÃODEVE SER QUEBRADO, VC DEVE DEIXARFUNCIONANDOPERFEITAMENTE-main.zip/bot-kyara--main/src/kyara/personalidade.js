const fs = require('fs');
const path = require('path');

const memoriaPath = path.join(
  __dirname,
  '..',
  '..',
  'database',
  'kyara_memoria.json'
);

/**
 * SISTEMA DE PERSONALIDADE ADAPTATIVA DA KYARA
 * Armazena características dinâmicas e afinidade por usuário
 */

function garantirMemoria() {
  const pasta = path.dirname(memoriaPath);

  if (!fs.existsSync(pasta)) {
    fs.mkdirSync(pasta, { recursive: true });
  }

  if (!fs.existsSync(memoriaPath)) {
    fs.writeFileSync(
      memoriaPath,
      JSON.stringify({
        dono: "5584987480834",
        nome: "Kyara",
        afinidade: {},
        historico: {},
        memoriaLongo: {},
        opinioesFormadas: {},
        estadoEmocional: {
          humor: 50,
          energia: 70,
          paciencia: 60,
          disposicao: 65
        },
        preferenciasGlobais: {
          tendenciaAudio: false,
          frequenciaEmoji: 'moderada',
          nivelSarcasmo: 'moderado'
        }
      }, null, 2)
    );
  }
}

function carregarMemoria() {
  garantirMemoria();

  try {
    return JSON.parse(fs.readFileSync(memoriaPath, 'utf8'));
  } catch {
    return {
      dono: "5584987480834",
      nome: "Kyara",
      afinidade: {},
      historico: {},
      memoriaLongo: {},
      opinioesFormadas: {},
      estadoEmocional: {
        humor: 50,
        energia: 70,
        paciencia: 60,
        disposicao: 65
      },
      preferenciasGlobais: {
        tendenciaAudio: false,
        frequenciaEmoji: 'moderada',
        nivelSarcasmo: 'moderado'
      }
    };
  }
}

function salvarMemoria(db) {
  garantirMemoria();
  try {
    fs.writeFileSync(
      memoriaPath,
      JSON.stringify(db, null, 2)
    );
  } catch (erro) {
    console.log('Erro ao salvar memória da Kyara:', erro);
  }
}

/**
 * SISTEMA DE AFINIDADE POR USUÁRIO
 */

function obterAfinidade(db, jid) {
  if (!db.afinidade) db.afinidade = {};
  return db.afinidade[jid] || 50;
}

function aumentarAfinidade(db, jid, quanto = 5) {
  if (!db.afinidade) db.afinidade = {};
  const atual = obterAfinidade(db, jid);
  db.afinidade[jid] = Math.min(100, atual + quanto);
  salvarMemoria(db);
  return db.afinidade[jid];
}

function diminuirAfinidade(db, jid, quanto = 5) {
  if (!db.afinidade) db.afinidade = {};
  const atual = obterAfinidade(db, jid);
  db.afinidade[jid] = Math.max(0, atual - quanto);
  salvarMemoria(db);
  return db.afinidade[jid];
}

/**
 * IDENTIFICAÇÃO DO DONO
 * Normaliza JID para comparação com o número do dono
 */

function normalizarJID(jid) {
  if (!jid) return null;
  return String(jid).replace(/[@\s]/g, '').split(':')[0];
}

function ehDono(jid, db) {
  if (!jid || !db) return false;
  const numeroJid = normalizarJID(jid);
  const numeroDono = normalizarJID(db.dono || "5584987480834");
  return numeroJid === numeroDono;
}

/**
 * MEMÓRIA PERSISTENTE DE INFORMAÇÕES
 */

function salvarInformacao(db, jid, categoria, informacao, valor) {
  if (!db.memoriaLongo) db.memoriaLongo = {};
  if (!db.memoriaLongo[jid]) {
    db.memoriaLongo[jid] = {};
  }
  if (!db.memoriaLongo[jid][categoria]) {
    db.memoriaLongo[jid][categoria] = {};
  }

  db.memoriaLongo[jid][categoria][informacao] = {
    valor,
    dataSalva: new Date().toISOString(),
    relevancia: 1.0
  };

  salvarMemoria(db);
}

function obterInformacao(db, jid, categoria, informacao) {
  if (!db.memoriaLongo) return null;
  if (!db.memoriaLongo[jid]) return null;
  if (!db.memoriaLongo[jid][categoria]) return null;

  const dado = db.memoriaLongo[jid][categoria][informacao];
  return dado ? dado.valor : null;
}

function obterTodasInformacoes(db, jid, categoria) {
  if (!db.memoriaLongo) return {};
  if (!db.memoriaLongo[jid]) return {};
  if (!db.memoriaLongo[jid][categoria]) return {};

  const resultado = {};
  const dados = db.memoriaLongo[jid][categoria];

  Object.keys(dados).forEach(chave => {
    resultado[chave] = dados[chave].valor;
  });

  return resultado;
}

/**
 * ESTADO EMOCIONAL DINÂMICO
 * Afeta como a Kyara responde
 */

function atualizarEstadoEmocional(db, mudancas) {
  if (!db.estadoEmocional) {
    db.estadoEmocional = {
      humor: 50,
      energia: 70,
      paciencia: 60,
      disposicao: 65
    };
  }

  Object.keys(mudancas).forEach(chave => {
    if (db.estadoEmocional.hasOwnProperty(chave)) {
      db.estadoEmocional[chave] = Math.max(
        0,
        Math.min(100, db.estadoEmocional[chave] + mudancas[chave])
      );
    }
  });

  salvarMemoria(db);
  return db.estadoEmocional;
}

function obterEstadoEmocional(db) {
  if (!db.estadoEmocional) {
    db.estadoEmocional = {
      humor: 50,
      energia: 70,
      paciencia: 60,
      disposicao: 65
    };
  }
  return db.estadoEmocional;
}

/**
 * REGISTRO DE HISTÓRICO COM RELEVÂNCIA
 */

function registrarInteracao(db, jid, tipo, conteudo, relevancia = 0.5) {
  if (!db.historico) db.historico = {};
  if (!db.historico[jid]) db.historico[jid] = [];

  db.historico[jid].push({
    tipo,
    conteudo,
    data: new Date().toISOString(),
    relevancia
  });

  // Manter apenas os últimos 30 registros
  if (db.historico[jid].length > 30) {
    db.historico[jid] = db.historico[jid].slice(-30);
  }

  salvarMemoria(db);
}

function obterHistorico(db, jid, ultimas = 10) {
  if (!db.historico) return [];
  if (!db.historico[jid]) return [];

  return db.historico[jid].slice(-ultimas);
}

/**
 * OPINIÕES SOBRE ASSUNTOS
 */

function formarOpiniao(db, assunto, opiniao, forca = 0.5) {
  if (!db.opinioesFormadas) db.opinioesFormadas = {};

  db.opinioesFormadas[assunto] = {
    texto: opiniao,
    forca: Math.max(0, Math.min(1, forca)),
    dataFormada: new Date().toISOString()
  };

  salvarMemoria(db);
}

function obterOpiniao(db, assunto) {
  if (!db.opinioesFormadas) return null;
  return db.opinioesFormadas[assunto] || null;
}

/**
 * ANÁLISE DE COMPORTAMENTO DO USUÁRIO
 * Determina se ajustar afinidade e estado emocional
 */

function analisarComportamento(tipo, db, jid) {
  const fatoresPositivos = {
    respeito: { afinidade: 8, humor: 5 },
    gentileza: { afinidade: 6, humor: 8 },
    ajuda: { afinidade: 10, humor: 3 },
    brincadeira: { afinidade: 4, humor: 15 },
    pergunta_interesse: { afinidade: 3, humor: 2 },
    elogio: { afinidade: 7, humor: 10 }
  };

  const fatoresNegativos = {
    insulto: { afinidade: -15, humor: -20, paciencia: -10 },
    spamming: { afinidade: -5, humor: -8, paciencia: -15 },
    rudeza: { afinidade: -8, humor: -10, disposicao: -5 },
    tentativa_engano: { afinidade: -20, humor: -15, paciencia: -30 },
    ignorancia: { afinidade: -2, disposicao: -3 }
  };

  const fator = fatoresPositivos[tipo] || fatoresNegativos[tipo];

  if (!fator) return;

  if (tipo in fatoresPositivos) {
    Object.entries(fator).forEach(([chave, valor]) => {
      if (chave === 'afinidade') {
        aumentarAfinidade(db, jid, valor);
      } else {
        atualizarEstadoEmocional(db, { [chave]: valor });
      }
    });
  } else {
    Object.entries(fator).forEach(([chave, valor]) => {
      if (chave === 'afinidade') {
        diminuirAfinidade(db, jid, Math.abs(valor));
      } else {
        atualizarEstadoEmocional(db, { [chave]: valor });
      }
    });
  }
}

/**
 * DETERMINADOR DE TENDÊNCIA (texto vs áudio)
 */

function decidirSobreAudio(db, afinidade, tamanhoTexto = 0) {
  if (afinidade < 70) return false;
  const tendenciaGlobal = db.preferenciasGlobais?.tendenciaAudio || false;
  return tendenciaGlobal || Math.random() < 0.3;
}

module.exports = {
  carregarMemoria,
  salvarMemoria,
  normalizarJID,
  ehDono,
  obterAfinidade,
  aumentarAfinidade,
  diminuirAfinidade,
  salvarInformacao,
  obterInformacao,
  obterTodasInformacoes,
  atualizarEstadoEmocional,
  obterEstadoEmocional,
  registrarInteracao,
  obterHistorico,
  formarOpiniao,
  obterOpiniao,
  analisarComportamento,
  decidirSobreAudio
};
