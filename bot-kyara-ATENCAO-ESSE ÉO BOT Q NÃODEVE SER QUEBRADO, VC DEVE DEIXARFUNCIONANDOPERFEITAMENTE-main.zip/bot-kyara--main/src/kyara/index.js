/**
 * INTEGRAÇÃO COMPLETA DA KYARA
 * Conecta todos os sistemas: personalidade, comportamento, mídia e controle
 */

const {
  carregarMemoria,
  salvarMemoria,
  normalizarJID,
  ehDono,
  obterAfinidade,
  aumentarAfinidade,
  diminuirAfinidade,
  salvarInformacao,
  obterInformacao,
  atualizarEstadoEmocional,
  obterEstadoEmocional,
  registrarInteracao,
  obterHistorico,
  analisarComportamento
} = require('./personalidade');

const {
  detectarIntencao,
  analisarTom,
  gerarRespostaDinamica,
  deveResponderComAudio
} = require('./comportamento');

const {
  kyaraEstaAtiva,
  kyaraAtivaEmGrupo,
  kyaraAtivaEmPrivado,
  ativarKyara,
  desativarKyara,
  ativarEmGrupo,
  desativarEmGrupo,
  ativarEmPrivado,
  desativarEmPrivado
} = require('./controle');

const {
  deveSenderFigurinha,
  selecionarFigurinha
} = require('./figurinhas');

const {
  gerarAudio
} = require('./midia');

/**
 * PROCESSADOR PRINCIPAL DE MENSAGENS
 * Função que processa toda mensagem recebida
 */

async function processarMensagemKyara(conn, message, sender, from, isGroup, nomeUsuario, texto) {
  try {
    // Carrega memória
    const memoria = carregarMemoria();
    
    // Verifica se Kyara está ativa
    const ativa = kyaraEstaAtiva();
    if (!ativa) return null;
    
    if (isGroup) {
      if (!kyaraAtivaEmGrupo(from)) return null;
    } else {
      if (!kyaraAtivaEmPrivado(from)) return null;
    }
    
    // Normaliza JID do sender
    const jidNormalizado = normalizarJID(sender);
    
    // Verifica se é comando de controle
    const textoLimpo = texto.toLowerCase().trim();
    
    if (textoLimpo === 'kyara on' || textoLimpo === 'ativa kyara' || textoLimpo === '/ativa') {
      if (ehDono(sender, memoria)) {
        if (isGroup) {
          ativarEmGrupo(from);
        } else {
          ativarEmPrivado(from);
        }
        return 'Estou online agora! 💚 Pronta para conversar!';
      }
    }
    
    if (textoLimpo === 'kyara off' || textoLimpo === 'desativa kyara' || textoLimpo === '/desativa') {
      if (ehDono(sender, memoria)) {
        if (isGroup) {
          desativarEmGrupo(from);
        } else {
          desativarEmPrivado(from);
        }
        return 'Vou ficar quietinha agora... Tchau! 💤';
      }
    }
    
    // Detecta intenção e tom
    const intencoes = detectarIntencao(texto);
    const tom = analisarTom(texto);
    
    // Analisa comportamento para ajustar afinidade
    let tipoBehavior = 'ignorancia';
    
    if (intencoes.includes('elogio') || intencoes.includes('apoio')) {
      tipoBehavior = 'gentileza';
    } else if (intencoes.includes('reclamacao') || intencoes.includes('rudeza')) {
      tipoBehavior = 'rudeza';
    } else if (intencoes.includes('pergunta') || intencoes.includes('curiosidade')) {
      tipoBehavior = 'pergunta_interesse';
    } else if (intencoes.includes('humor')) {
      tipoBehavior = 'brincadeira';
    }
    
    analisarComportamento(tipoBehavior, memoria, jidNormalizado);
    
    // Obtém afinidade atual
    const afinidade = obterAfinidade(memoria, jidNormalizado);
    const estadoEmocional = obterEstadoEmocional(memoria);
    
    // Decide se deve responder (não se intromete em conversas alheias)
    const mencionouKyara = /kyara|ky/i.test(texto);
    const foiResposta = message.quoted?.participant === conn.user?.id;
    
    // Se ninguém mencionou e não foi resposta, não se intromete
    if (!mencionouKyara && !foiResposta && !ehDono(sender, memoria)) {
      // Apenas responde se afinidade for MUITO alta (90+) e mensagem for muito natural
      if (afinidade < 90 || Math.random() > 0.1) {
        return null;
      }
    }
    
    // Gera resposta dinâmica
    let resposta = gerarRespostaDinamica(memoria, jidNormalizado, texto, '');
    
    if (!resposta) {
      return null;
    }
    
    // Registra que respondeu
    registrarInteracao(memoria, jidNormalizado, 'resposta_enviada', resposta, 0.8);
    salvarMemoria(memoria);
    
    /**
     * ESTRUTURA DE RETORNO
     * Permite ao bot escolher como responder (texto, áudio ou figurinha)
     */
    
    const resultado = {
      texto: resposta,
      comAudio: false,
      comFigurinha: false
    };
    
    // Decide se envia áudio
    if (deveResponderComAudio(memoria, afinidade, estadoEmocional)) {
      resultado.comAudio = true;
      resultado.caminhoAudio = null; // Será gerado pela chamadora
    }
    
    // Decide se envia figurinha junto
    if (deveSenderFigurinha(afinidade, intencoes)) {
      resultado.comFigurinha = true;
      resultado.figurinha = selecionarFigurinha(intencoes, estadoEmocional);
    }
    
    return resultado;
    
  } catch (erro) {
    console.log('Erro ao processar mensagem Kyara:', erro);
    return null;
  }
}

/**
 * GERADOR DE ÁUDIO EXPRESSIVO
 * Cria áudio com voz expressiva e natural
 */

async function gerarAudioKyara(texto, nomeArquivo = null) {
  try {
    if (!nomeArquivo) {
      nomeArquivo = `kyara_audio_${Date.now()}.wav`;
    }
    
    const resultado = await gerarAudio(texto, nomeArquivo, 'kyara');
    
    if (resultado.sucesso) {
      return resultado.caminho;
    }
    
    return null;
  } catch (erro) {
    console.log('Erro ao gerar áudio:', erro);
    return null;
  }
}

/**
 * VERIFICADOR DE STATUS DA KYARA
 */

function statusKyara() {
  const memoria = carregarMemoria();
  const ativa = kyaraEstaAtiva();
  const estado = obterEstadoEmocional(memoria);
  
  return {
    ativa,
    nome: memoria.nome || 'Kyara',
    dono: memoria.dono,
    estadoEmocional: estado,
    mensagem: ativa ? '💚 Online e pronta!' : '💤 Offline no momento'
  };
}

/**
 * INFORMAÇÕES DA KYARA
 */

function infoKyara() {
  const status = statusKyara();
  
  const info = `
╔═══════════════════════════════╗
║         KYARA-AI STATUS       ║
╠═══════════════════════════════╣
║ Nome: ${status.nome}
║ Status: ${status.ativa ? '🟢 ONLINE' : '🔴 OFFLINE'}
║ Dono: ${status.dono}
║
║ ESTADO EMOCIONAL:
║ 😊 Humor: ${status.estadoEmocional.humor}%
║ ⚡ Energia: ${status.estadoEmocional.energia}%
║ 😤 Paciência: ${status.estadoEmocional.paciencia}%
║ 💪 Disposição: ${status.estadoEmocional.disposicao}%
╠═══════════════════════════════╣
║ COMANDOS:
║ kyara on / ativa kyara
║ kyara off / desativa kyara
║ kyara info / status kyara
╚═══════════════════════════════╝
  `;
  
  return info;
}

module.exports = {
  processarMensagemKyara,
  gerarAudioKyara,
  statusKyara,
  infoKyara,
  // Exporta sub-módulos para uso direto
  personalidade: {
    carregarMemoria,
    salvarMemoria,
    ehDono,
    obterAfinidade,
    aumentarAfinidade,
    atualizarEstadoEmocional
  },
  controle: {
    kyaraEstaAtiva,
    kyaraAtivaEmGrupo,
    kyaraAtivaEmPrivado,
    ativarKyara,
    desativarKyara
  }
};
