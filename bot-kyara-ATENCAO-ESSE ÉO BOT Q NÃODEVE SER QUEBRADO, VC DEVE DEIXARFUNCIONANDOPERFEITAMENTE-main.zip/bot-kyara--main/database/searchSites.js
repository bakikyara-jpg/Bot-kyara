module.exports = {
  sites: []
};