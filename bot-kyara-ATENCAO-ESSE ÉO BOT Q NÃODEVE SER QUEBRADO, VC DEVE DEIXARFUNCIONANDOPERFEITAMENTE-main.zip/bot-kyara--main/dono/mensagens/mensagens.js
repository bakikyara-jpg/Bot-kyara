

const msg = {
    SoAdm: "*_❗Você não é administrador, não tente usar esse comando!_*", 
    SoDono: "*_❗Somente meu dono ⓑ BAKI pode usar esse comando!_*",
    BotAdmin: "*_❕Eu preciso ser admin do grupo para esse comando funcionar!_*",
    SoEmGrupos: "*_❕Esse comando só funciona em grupos!_*",
    Download: "*_⌛ Realizando ação, aguarde.._*"
};

// TRANSFORMA EM FUNÇÃO
const Cmd = (command, NomeGrupo, prefix) => ({
    Ativado: `❕| *_O recurso "${command}" foi ativado com sucesso no grupo: "${NomeGrupo}"_*\n\n*_Para desativar use: ${prefix + command} 0_*`,
    Desativado: `❗| *_O recurso "${command}" foi desativado com sucesso no grupo: "${NomeGrupo}"_*\n\n*_Para ativar novamente use: ${prefix + command} 1_*`
});

module.exports = { msg, Cmd };
