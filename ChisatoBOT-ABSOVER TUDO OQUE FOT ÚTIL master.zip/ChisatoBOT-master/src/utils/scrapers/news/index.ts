export * from "./earthquake.scraper";
