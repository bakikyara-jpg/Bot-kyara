import { PrismaClient } from "@prisma/client";
import { cacheService } from "../../core/cache/cache.service";
import { logger } from "../../core/logger/logger.service";

// Prisma types
type PrismaUser = Awaited<ReturnType<PrismaClient["user"]["findUnique"]>>;
type PrismaGroup = Awaited<ReturnType<PrismaClient["group"]["findUnique"]>>;

// Baileys keeps adding fields to participants (username, ...) that the Prisma
// Participant composite type rejects. Keep only what the schema declares.
export const cleanParticipants = (participants: any): any[] =>
    (Array.isArray(participants) ? participants : []).map((p: any) => ({
        id: p?.id ?? null,
        admin: p?.admin ?? null,
        lid: p?.lid ?? null,
        phoneNumber: p?.phoneNumber ?? null,
        username: p?.username ?? null,
    }));

class DatabaseService {
    private static instance: DatabaseService;
    private prisma: PrismaClient;
    private readonly CACHE_TTL = {
        USER: 5 * 60 * 1000, // 5 minutes
        GROUP: 10 * 60 * 1000, // 10 minutes
        SETTINGS: 15 * 60 * 1000, // 15 minutes
    };

    private constructor() {
        this.prisma = new PrismaClient({
            log: ["error"],
        });
        this.initializeConnection();
    }

    public static getInstance(): DatabaseService {
        if (!DatabaseService.instance) {
            DatabaseService.instance = new DatabaseService();
        }
        return DatabaseService.instance;
    }

    private async initializeConnection(): Promise<void> {
        try {
            await this.prisma.$connect();
            logger.info("Database connected successfully");
        } catch (error) {
            logger.error(
                `Database connection failed: ${
                    error instanceof Error ? error.message : String(error)
                }`
            );
            throw error;
        }
    }

    public getPrismaClient(): PrismaClient {
        return this.prisma;
    }

    /**
     * User Operations
     */
    public async getUser(userId: string): Promise<PrismaUser | null> {
        const cacheKey = `user:${userId}`;

        const user = await cacheService.getOrSet(
            cacheKey,
            () => this.prisma.user.findUnique({ where: { userId } }),
            this.CACHE_TTL.USER
        );

        // Ensure level and stats are initialized
        if (user && (!user.level || !user.stats)) {
            return await this.initializeUserLevelAndStats(userId);
        }

        return user;
    }

    private async initializeUserLevelAndStats(userId: string): Promise<PrismaUser> {
        const cacheKey = `user:${userId}`;
        
        const user = await this.prisma.user.update({
            where: { userId },
            data: {
                level: {
                    level: 1,
                    xp: 0,
                    totalXp: 0,
                },
                stats: {
                    totalCommands: 0,
                    commandsUsed: [],
                    lastCommandTime: 0,
                    joinedAt: Math.floor(Date.now() / 1000),
                },
            },
        });

        cacheService.set(cacheKey, user, this.CACHE_TTL.USER);
        return user;
    }

    public async upsertUser(
        userId: string,
        name?: string
    ): Promise<PrismaUser> {
        const cacheKey = `user:${userId}`;

        const user = await this.prisma.user.upsert({
            where: { userId },
            create: {
                userId,
                name: name || null,
                limit: 30,
                role: "free",
                expired: 0,
                afk: {
                    status: false,
                    reason: null,
                    since: 0,
                },
                level: {
                    level: 1,
                    xp: 0,
                    totalXp: 0,
                },
                stats: {
                    totalCommands: 0,
                    commandsUsed: [],
                    lastCommandTime: 0,
                    joinedAt: Math.floor(Date.now() / 1000),
                },
            },
            update: {
                name: name || undefined,
            },
        });

        cacheService.set(cacheKey, user, this.CACHE_TTL.USER);
        return user;
    }

    public async updateUser(userId: string, data: any): Promise<PrismaUser> {
        const cacheKey = `user:${userId}`;

        const user = await this.prisma.user.upsert({
            where: { userId },
            create: {
                userId,
                name: data.name || null,
                limit: data.limit || 30,
                role: data.role || "free",
                expired: data.expired || 0,
                afk: data.afk || {
                    status: false,
                    reason: null,
                    since: 0,
                },
                level: data.level || {
                    level: 1,
                    xp: 0,
                    totalXp: 0,
                },
                stats: data.stats || {
                    totalCommands: 0,
                    commandsUsed: [],
                    lastCommandTime: 0,
                    joinedAt: Math.floor(Date.now() / 1000),
                },
            },
            update: data,
        });

        cacheService.set(cacheKey, user, this.CACHE_TTL.USER);
        return user;
    }

    public async getUserCount(): Promise<number> {
        return this.prisma.user.count();
    }

    /**
     * Leveling Operations
     */
    public async addUserXP(
        userId: string,
        xpToAdd: number,
        commandName: string
    ): Promise<{ user: PrismaUser; leveledUp: boolean; newLevel?: number }> {
        const cacheKey = `user:${userId}`;
        
        const user = await this.getUser(userId);
        if (!user) {
            throw new Error("User not found");
        }

        // Initialize level and stats if null
        const currentLevel = user.level?.level || 1;
        const currentXp = user.level?.xp || 0;
        const totalXp = user.level?.totalXp || 0;
        
        // Calculate new XP and level
        const { addXP } = await import("../../utils/leveling");
        const result = addXP(currentLevel, currentXp, totalXp, xpToAdd);
        
        // Update command usage stats
        const commandsUsed = user.stats?.commandsUsed || [];
        const commandIndex = commandsUsed.findIndex((c: any) => c.command === commandName);
        
        if (commandIndex >= 0) {
            commandsUsed[commandIndex].count++;
        } else {
            commandsUsed.push({ command: commandName, count: 1 });
        }
        
        // Update user
        const updatedUser = await this.prisma.user.update({
            where: { userId },
            data: {
                level: {
                    level: result.newLevel,
                    xp: result.newXp,
                    totalXp: result.newTotalXp,
                },
                stats: {
                    totalCommands: (user.stats?.totalCommands || 0) + 1,
                    commandsUsed,
                    lastCommandTime: Math.floor(Date.now() / 1000),
                    joinedAt: user.stats?.joinedAt || Math.floor(Date.now() / 1000),
                },
            },
        });
        
        cacheService.delete(cacheKey);
        
        return {
            user: updatedUser,
            leveledUp: result.leveledUp,
            newLevel: result.leveledUp ? result.newLevel : undefined,
        };
    }

    public async getAllUsers(): Promise<PrismaUser[]> {
        return this.prisma.user.findMany();
    }

    /**
     * Group Operations
     */
    public async getGroup(groupId: string): Promise<PrismaGroup | null> {
        const cacheKey = `group:${groupId}`;

        return cacheService.getOrSet(
            cacheKey,
            () => this.prisma.group.findUnique({ where: { groupId } }),
            this.CACHE_TTL.GROUP
        );
    }

    public async upsertGroup(
        groupId: string,
        groupData: any
    ): Promise<PrismaGroup> {
        const cacheKey = `group:${groupId}`;

        const settings = groupData.settings || {};
        settings.antilink = settings.antilink || {};
        
        const validData: any = {
            subject: groupData.subject || "",
            subjectOwnerPn: groupData.subjectOwnerPn || null,
            addressingMode: groupData.addressingMode || null,
            size: groupData.size || groupData.participants?.length || 0,
            creation: groupData.creation || 0,
            owner: groupData.owner || null,
            ownerPn: groupData.ownerPn || null,
            owner_country_code: groupData.owner_country_code || null,
            desc: groupData.desc || null,
            descOwner: groupData.descOwner || null,
            descOwnerPn: groupData.descOwnerPn || null,
            descTime: groupData.descTime || null,
            linkedParent: groupData.linkedParent || null,
            joinApprovalMode: groupData.joinApprovalMode || false,
            restrict: groupData.restrict || false,
            announce: groupData.announce || false,
            isCommunity: groupData.isCommunity || false,
            isCommunityAnnounce: groupData.isCommunityAnnounce || false,
            memberAddMode: groupData.memberAddMode ?? true,
            participants: cleanParticipants(groupData.participants),
            ephemeralDuration: groupData.ephemeralDuration || 0,
            settings: {
                notify: settings.notify ?? false,
                welcome: settings.welcome ?? true,
                leave: settings.leave ?? true,
                mute: settings.mute ?? false,
                antilink: {
                    status: settings.antilink.status ?? false,
                    mode: settings.antilink.mode || "kick",
                    list: settings.antilink.list || ["whatsapp"]
                },
                antibot: settings.antibot ?? false,
                banned: settings.banned || []
            }
        };

        const group = await this.prisma.group.upsert({
            where: { groupId },
            create: { groupId, ...validData },
            update: validData,
        });

        cacheService.set(cacheKey, group, this.CACHE_TTL.GROUP);
        return group;
    }

    public async updateGroup(groupId: string, data: any): Promise<PrismaGroup> {
        const cacheKey = `group:${groupId}`;

        if (data?.groupMetadata) {
            const group = await this.upsertGroup(groupId, data.groupMetadata);
            cacheService.set(cacheKey, group, this.CACHE_TTL.GROUP);
            return group;
        }

        const cleanData: any = {};
        for (const key in data) {
            if (data[key] !== undefined) {
                cleanData[key] =
                    key === "participants"
                        ? cleanParticipants(data[key])
                        : data[key];
            }
        }

        const group = await this.prisma.group.update({
            where: { groupId },
            data: cleanData,
        });

        cacheService.delete(cacheKey);
        return group;
    }

    public async updateGroupSettings(
        groupId: string,
        settings: any
    ): Promise<PrismaGroup> {
        const cacheKey = `group:${groupId}`;

        const group = await this.prisma.group.update({
            where: { groupId },
            data: {
                settings: {
                    update: settings,
                },
            },
        });

        cacheService.delete(cacheKey);
        return group;
    }

    public async deleteGroup(groupId: string): Promise<{ count: number }> {
        const cacheKey = `group:${groupId}`;

        const result = await this.prisma.group.deleteMany({
            where: { groupId },
        });

        cacheService.delete(cacheKey);
        return result;
    }

    public async getGroupCount(): Promise<number> {
        return this.prisma.group.count();
    }

    public async getAllGroups(): Promise<PrismaGroup[]> {
        return this.prisma.group.findMany();
    }

    /**
     * Batch Operations for Performance
     */
    public async batchUpdateUsers(
        updates: Array<{ userId: string; data: any }>
    ): Promise<void> {
        for (const { userId, data } of updates) {
            const cacheKey = `user:${userId}`;
            cacheService.delete(cacheKey);
            await this.prisma.user.update({ where: { userId }, data });
        }
    }

    /**
     * Reset daily limits
     */
    public async resetUserLimits(limit: number): Promise<void> {
        await this.prisma.user.updateMany({
            where: {
                userId: {
                    contains: "@s.whatsapp.net",
                },
                role: {
                    in: ["free"],
                },
            },
            data: {
                limit,
            },
        });

        logger.info("User limits reset, clearing user cache");
    }

    /**
     * Cleanup and disconnect
     */
    public async disconnect(): Promise<void> {
        await this.prisma.$disconnect();
        logger.info("Database disconnected");
    }
}

export const databaseService = DatabaseService.getInstance();
export const Database = databaseService.getPrismaClient();
