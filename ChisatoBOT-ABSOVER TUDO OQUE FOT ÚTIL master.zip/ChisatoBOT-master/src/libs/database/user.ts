import { Client, Database } from "..";
import { User as UserType } from "@prisma/client";
import { configService } from "../../core/config/config.service";

export class User {
    get config(): Config { return configService.getConfig() as unknown as Config; }
    /**
     * Add User Data to Database
     * @param Chisato
     * @param userId
     * @returns {Promise<UserType>}
     */
    public upsert = (
        Chisato: Client,
        userId: string,
        pushName: string
    ): Promise<UserType> =>
        new Promise(async (resolve, reject) => {
            try {
                if (await this.get(userId, pushName)) return;
                const isTeam = this.config.teamNumber.includes(
                    userId.split("@")[0]
                );
                if (!userId) return;
                const metadata = await Database.user.upsert({
                    where: { userId },
                    create: {
                        userId,
                        limit: isTeam ? 0 : this.config.limit.command,
                        role: isTeam ? "premium" : "free",
                        afk: {
                            status: false,
                            reason: "",
                            since: 0,
                        },
                        level: {
                            level: 1,
                            xp: 0,
                            totalXp: 0,
                        },
                        stats: {
                            totalCommands: 0,
                            commandsUsed: [],
                            lastCommandTime: 0,
                            joinedAt: Math.floor(Date.now() / 1000),
                        },
                    },
                    update: {
                        userId,
                        limit: isTeam ? 0 : this.config.limit.command,
                        role: isTeam ? "premium" : "free",
                        afk: {
                            status: false,
                            reason: "",
                            since: 0,
                        },
                    },
                });
                Chisato.logger.info(`Added New User ${userId}`);
                resolve(metadata);
            } catch (err) {
                reject(err);
            }
        });

    /**
     * Get User Data from Database
     * @param userId
     * @returns {Promise<UserType>}
     */
    public get = (
        userId: string,
        pushName?: string
    ): Promise<UserType | null> =>
        new Promise(async (resolve, reject) => {
            try {
                const metadata = await Database.user.findUnique({
                    where: { userId },
                });
                // Fire-and-forget name update 
                if (metadata?.name !== pushName && pushName) {
                    this.update(userId, { name: pushName }).catch(() => {});
                }
                resolve(metadata);
            } catch (err) {
                resolve(null);
            }
        });

    /**
     * Get All User Data from Database
     * @returns {Promise<UserType[]>}
     */
    public getAll = (): Promise<UserType[]> =>
        new Promise(async (resolve, reject) => {
            try {
                const metadata = await Database.user.findMany();
                resolve(metadata);
            } catch (err) {
                resolve([]);
            }
        });

    /**
     * Update User Data from Database
     * @param userId
     * @param data
     * @returns {Promise<UserType>}
     */
    public update = (userId: string, data: any): Promise<UserType> =>
        new Promise(async (resolve, reject) => {
            try {
                const metadata = await Database.user.update({
                    where: { userId },
                    data: { ...data },
                });
                resolve(metadata);
            } catch (err) {
                reject(err);
            }
        });

    /**
     * Delete User Data from Database
     * @param userId
     * @returns
     */
    public delete = (userId: string) =>
        new Promise(async (resolve, reject) => {
            try {
                const metadata = await Database.user.delete({
                    where: { userId },
                });
                resolve(metadata);
            } catch (err) {
                reject(err);
            }
        });

    /**
     * View the count of Database
     * @returns {number}
     */
    public size = (): Promise<number> =>
        new Promise(async (resolve, reject) => {
            try {
                const user = await Database.user.count();
                resolve(user);
            } catch (err) {
                reject(err);
            }
        });
}
